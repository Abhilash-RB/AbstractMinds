"""
FastAPI application entry-point.

Sets up:
    - All API routers under /api/v1/
    - Startup events (DB tables, ML models, cache warm-up, demo seeding)
    - CORS, exception handlers, request logging middleware
    - Health check endpoint with AI model status
"""

import json
import logging
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.db.database import create_tables, AsyncSessionLocal

settings = get_settings()

# ── Logging ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.DEBUG if settings.ENVIRONMENT == "dev" else logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("energy_optimizer")


# ── Demo data seeder ───────────────────────────────────────────────────

async def seed_demo_data() -> None:
    """
    Seed demo user, appliances, and anomaly alerts on first run.
    Gated by ENVIRONMENT=dev. Skips if demo user already exists.
    """
    seed_path = Path(__file__).resolve().parent.parent / "data" / "demo_seed.json"
    if not seed_path.exists():
        logger.warning("⚠️ demo_seed.json not found at %s — skipping seed.", seed_path)
        return

    with open(seed_path, "r", encoding="utf-8") as f:
        seed = json.load(f)

    async with AsyncSessionLocal() as db:
        try:
            from sqlalchemy import select
            from app.db.models.user import User
            from app.db.models.appliance import Appliance

            # Check if demo user exists
            demo_cfg = seed.get("demo_user", {})
            existing = (await db.execute(
                select(User).where(User.email == demo_cfg.get("email", "demo@thundervolts.in"))
            )).scalar_one_or_none()

            if existing:
                logger.info("✅ Demo user already exists — skipping seed.")
                return

            # Create demo user
            from app.api.auth import get_password_hash
            user = User(
                email=demo_cfg["email"],
                hashed_password=get_password_hash(demo_cfg["password"]),
                full_name=demo_cfg.get("full_name", "Demo User"),
                city=demo_cfg.get("city", "Bangalore"),
                state=demo_cfg.get("state", "Karnataka"),
                discom_name=demo_cfg.get("discom_name", "BESCOM"),
                is_rural=demo_cfg.get("is_rural", False),
            )
            db.add(user)
            await db.flush()  # get user.id

            # Create demo appliances
            for appl in seed.get("demo_appliances", []):
                db.add(Appliance(
                    user_id=user.id,
                    name=appl["name"],
                    category=appl.get("category", "other"),
                    wattage_watts=appl.get("wattage_watts", 100),
                    avg_daily_usage_hours=appl.get("avg_daily_usage_hours", 1),
                    is_schedulable=appl.get("is_schedulable", False),
                    preferred_start_hour=appl.get("preferred_start_hour", 0),
                    preferred_end_hour=appl.get("preferred_end_hour", 23),
                ))

            # Create demo anomaly alerts
            try:
                from app.db.models.alert import Alert
                for anom in seed.get("demo_anomalies", []):
                    db.add(Alert(
                        user_id=user.id,
                        severity=anom.get("severity", "medium"),
                        title=f"{anom.get('type', 'anomaly').replace('_', ' ').title()} — {anom.get('appliance', '?')}",
                        message=(
                            f"{anom.get('appliance', 'Appliance')} anomaly detected at "
                            f"{anom.get('detected_at', '?')}. {anom.get('action', '')}"
                        ),
                        appliance_name=anom.get("appliance"),
                        is_read=False,
                        anomaly_type=anom.get("type"),
                    ))
            except ImportError:
                logger.debug("Alert model not available — skipping anomaly seed.")

            await db.commit()
            logger.info("✅ Demo data seeded: user=%s, %d appliances, %d anomalies",
                         demo_cfg["email"],
                         len(seed.get("demo_appliances", [])),
                         len(seed.get("demo_anomalies", [])))

        except Exception as exc:
            await db.rollback()
            logger.warning("⚠️ Demo seed failed: %s", exc)


# ── Lifespan (startup / shutdown) ──────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: startup and shutdown hooks."""

    # ── Startup ─────────────────────────────────────────────────────────
    logger.info("🚀 Starting %s v%s [%s]", settings.APP_NAME, settings.APP_VERSION, settings.ENVIRONMENT)

    # 1. Create DB tables (dev only — use Alembic in prod)
    try:
        await create_tables()
        logger.info("✅ Database tables created / verified.")
    except Exception as exc:
        logger.error("❌ Database setup failed: %s", exc)

    # 2. Seed demo data (dev only)
    if settings.ENVIRONMENT == "dev":
        try:
            await seed_demo_data()
        except Exception as exc:
            logger.warning("⚠️ Demo seeding failed: %s", exc)

    # 3. Load ML models (if saved models exist)
    ml_dir = Path(settings.ML_MODELS_DIR)
    try:
        from app.ml.models.bill_predictor import BillPredictorModel
        from app.ml.models.demand_forecaster import DemandForecasterModel

        bill_model_path = ml_dir / "bill_predictor.json"
        demand_model_path = ml_dir / "demand_forecaster.h5"

        bp = BillPredictorModel()
        if bill_model_path.exists():
            bp.load_model(str(bill_model_path))

        df = DemandForecasterModel()
        if demand_model_path.exists():
            df.load_model(str(demand_model_path))

        logger.info("✅ ML models loaded (or fallback mode active).")
    except Exception as exc:
        logger.warning("⚠️ ML model loading skipped: %s", exc)

    # 4. Warm up Redis cache with tariff data
    try:
        from app.services.tariff_service import load_tariff
        for discom in ("BESCOM", "Tata Power Mumbai", "GENERIC_RURAL"):
            await load_tariff(discom)
        logger.info("✅ Tariff cache warmed up.")
    except Exception as exc:
        logger.warning("⚠️ Redis tariff warm-up failed: %s", exc)

    yield  # Application runs here

    # ── Shutdown ────────────────────────────────────────────────────────
    logger.info("🛑 Shutting down %s.", settings.APP_NAME)


# ── App Instance ────────────────────────────────────────────────────────

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "AI-powered home energy optimizer for Indian households. "
        "Predicts electricity bills, identifies peak hours, and "
        "recommends optimal appliance schedules."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ── CORS Middleware ─────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.ENVIRONMENT == "dev" else [],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request Logging Middleware ──────────────────────────────────────────

@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """Log every incoming request with timing."""
    request_id = str(uuid.uuid4())[:8]
    start = time.monotonic()
    logger.info(
        "[%s] → %s %s",
        request_id, request.method, request.url.path,
    )
    response = await call_next(request)
    elapsed = (time.monotonic() - start) * 1000
    logger.info(
        "[%s] ← %d (%.0fms)",
        request_id, response.status_code, elapsed,
    )
    response.headers["X-Request-ID"] = request_id
    return response


# ── Exception Handlers ──────────────────────────────────────────────────

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Custom HTTP exception handler with consistent JSON format."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": True,
            "status_code": exc.status_code,
            "detail": exc.detail,
        },
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    """Catch-all for unhandled exceptions."""
    logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": True,
            "status_code": 500,
            "detail": "Internal server error." if settings.ENVIRONMENT == "prod" else str(exc),
        },
    )


# ── Routers ─────────────────────────────────────────────────────────────

from app.api.routes.predictions import router as predictions_router
from app.api.routes.ai_chat import router as ai_chat_router
from app.api.routes.auth_routes import router as auth_router
from app.api.routes.appliance_routes import router as appliance_router
from app.api.routes.tariff_routes import router as tariff_router
from app.api.routes.alerts import router as alerts_router

app.include_router(predictions_router, prefix=settings.API_V1_PREFIX)
app.include_router(ai_chat_router, prefix=settings.API_V1_PREFIX)
app.include_router(auth_router, prefix=settings.API_V1_PREFIX)
app.include_router(appliance_router, prefix=settings.API_V1_PREFIX)
app.include_router(tariff_router, prefix=settings.API_V1_PREFIX)
app.include_router(alerts_router, prefix=settings.API_V1_PREFIX)


# ── Health Check ────────────────────────────────────────────────────────

@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint with AI provider status."""
    result = {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
    }
    # Add AI model status if available
    try:
        from app.ai.model_router import get_model_router
        router = get_model_router()
        result["ai_providers"] = await router.get_model_status()
    except Exception as exc:
        result["ai_providers"] = {"error": str(exc)}

    return result
