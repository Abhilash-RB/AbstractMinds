"""
Application configuration module.

Loads settings from environment variables and .env file using pydantic-settings.
Provides a cached get_settings() function for dependency injection.
"""

from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables and .env file.

    All configuration for the Energy Bill Predictor application is centralized
    here, including database connections, API keys, JWT configuration, and
    runtime environment.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Database ─────────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/energy_optimizer"

    # ── Redis ────────────────────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"

    # ── JWT Authentication ───────────────────────────────────────────────
    SECRET_KEY: str = "change-me-to-a-secure-random-string-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # ── External API Keys ────────────────────────────────────────────────
    OPENWEATHER_API_KEY: str = ""
    POSOCO_API_KEY: str = ""

    # ── AI Provider Keys (all free-tier) ─────────────────────────────────
    GROQ_API_KEY: str = ""
    GEMINI_API_KEY: str = ""
    CEREBRAS_API_KEY: str = ""
    OPENROUTER_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""  # legacy — kept for claude_agent compat

    # ── Runtime Environment ──────────────────────────────────────────────
    ENVIRONMENT: Literal["dev", "prod"] = "dev"

    # ── Application Metadata ─────────────────────────────────────────────
    APP_NAME: str = "Energy Bill Predictor & Appliance Scheduler"
    APP_VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api/v1"

    # ── ML Model Paths ───────────────────────────────────────────────────
    ML_MODELS_DIR: str = "ml_models"

    # ── Celery ───────────────────────────────────────────────────────────
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"


@lru_cache()
def get_settings() -> Settings:
    """
    Return a cached Settings instance.

    Uses functools.lru_cache so that the .env file is read only once
    and the same Settings object is reused for the lifetime of the process.
    """
    return Settings()
