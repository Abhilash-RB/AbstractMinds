# Energy Bill Predictor & Appliance Scheduler — backend application package.
