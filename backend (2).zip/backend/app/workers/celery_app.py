"""
Celery application and task definitions.

Tasks:
    - retrain_anomaly_detector: weekly retraining of anomaly models
    - retrain_bill_predictor: periodic retraining of bill predictor
"""

import logging

from celery import Celery

from app.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

celery_app = Celery(
    "energy_optimizer",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Kolkata",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=600,
    worker_max_tasks_per_child=50,
)


@celery_app.task(name="retrain_anomaly_detector")
def retrain_anomaly_detector(user_id: str) -> dict:
    """
    Retrain the anomaly detector for a specific user.

    Fetches the last 30 days of usage logs and fits a new
    Isolation Forest model.
    """
    logger.info("Retraining anomaly detector for user %s", user_id)

    # NOTE: Celery tasks run synchronously. For DB access we use
    # a synchronous session here (or run_in_executor for async).
    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session
    from app.db.models.usage_log import UsageLog
    from app.db.models.appliance import Appliance
    from app.ml.models.usage_anomaly import UsageAnomalyDetector
    import uuid

    sync_url = settings.DATABASE_URL.replace("+asyncpg", "")
    engine = create_engine(sync_url)

    with Session(engine) as session:
        uid = uuid.UUID(user_id)
        appliances = session.query(Appliance).filter(Appliance.user_id == uid).all()

        for appl in appliances:
            logs = (
                session.query(UsageLog)
                .filter(UsageLog.appliance_id == appl.id)
                .order_by(UsageLog.recorded_at.desc())
                .limit(720)  # 30 days × 24h
                .all()
            )
            log_dicts = [
                {
                    "hour_of_day": l.hour_of_day,
                    "units_consumed_kwh": l.units_consumed_kwh,
                    "usage_date": l.usage_date.isoformat() if l.usage_date else "",
                }
                for l in logs
            ]

            detector = UsageAnomalyDetector()
            detector.train(log_dicts)
            logger.info(
                "Anomaly detector retrained for appliance %s (%d logs)",
                appl.name, len(log_dicts),
            )

    return {"status": "completed", "user_id": user_id}


@celery_app.task(name="retrain_bill_predictor")
def retrain_bill_predictor() -> dict:
    """
    Retrain the global bill predictor model on all user data.

    This is a stub — in production, it would:
    1. Query all prediction_logs with actual vs predicted values
    2. Build a training dataset
    3. Retrain XGBoost
    4. Save the new model
    """
    logger.info("Bill predictor retraining started.")

    # Placeholder — actual implementation needs labelled data
    from app.ml.models.bill_predictor import BillPredictorModel
    model = BillPredictorModel()
    logger.info("Bill predictor retraining complete (stub).")
    return {"status": "completed", "note": "No labelled data — stub run."}


# ── Periodic schedule (Celery Beat) ─────────────────────────────────────
celery_app.conf.beat_schedule = {
    "retrain-bill-predictor-weekly": {
        "task": "retrain_bill_predictor",
        "schedule": 604800.0,  # 7 days in seconds
    },
}
