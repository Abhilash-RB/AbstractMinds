"""
Weather service — fetches current and forecast weather data from
the OpenWeatherMap API.

Provides:
    - get_current_weather(city)
    - get_forecast_48h(city)
    - estimate_ac_load_factor(temp, humidity)

Caches results in Redis with a 1-hour TTL.
"""

import logging
from datetime import datetime
from typing import Optional

import httpx
import redis.asyncio as aioredis
from pydantic import BaseModel

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

_REDIS_TTL_SECONDS = 3_600  # 1 hour
_OWM_BASE = "https://api.openweathermap.org/data/2.5"

# ── Redis Client (lazy singleton) ──────────────────────────────────────

_redis_client: Optional[aioredis.Redis] = None


async def _get_redis() -> aioredis.Redis:
    """Return a cached async Redis connection."""
    global _redis_client
    if _redis_client is None:
        _redis_client = aioredis.from_url(
            settings.REDIS_URL, decode_responses=True
        )
    return _redis_client


# ── Schemas ─────────────────────────────────────────────────────────────

class WeatherData(BaseModel):
    """Current weather snapshot."""
    temp_celsius: float
    humidity_percent: float
    feels_like: float
    condition: str
    wind_speed: float


class HourlyForecast(BaseModel):
    """A single hour in a 48-hour forecast."""
    datetime: str  # ISO 8601
    temp_celsius: float
    humidity_percent: float
    condition: str


# ── Fallback data ───────────────────────────────────────────────────────

_FALLBACK_WEATHER = WeatherData(
    temp_celsius=32.0,
    humidity_percent=55.0,
    feels_like=35.0,
    condition="Haze",
    wind_speed=3.5,
)


def _generate_fallback_forecast() -> list[HourlyForecast]:
    """
    Generate a synthetic 48-hour forecast when the API is unavailable.

    Uses a simple sinusoidal temperature curve that peaks at 14:00
    and troughs at 04:00, representative of Indian summer conditions.
    """
    import math
    from datetime import timedelta, timezone

    now = datetime.now(timezone.utc)
    forecasts: list[HourlyForecast] = []
    for h in range(48):
        t = now + timedelta(hours=h)
        hour_of_day = t.hour
        # Sinusoidal temp: base 30, amplitude 6, peak at 14:00
        temp = 30.0 + 6.0 * math.sin(math.pi * (hour_of_day - 8) / 12)
        temp = round(max(24.0, min(42.0, temp)), 1)
        humidity = round(60 - 15 * math.sin(math.pi * (hour_of_day - 8) / 12), 1)
        condition = "Clear" if 6 <= hour_of_day < 18 else "Clear Night"
        forecasts.append(
            HourlyForecast(
                datetime=t.isoformat(),
                temp_celsius=temp,
                humidity_percent=humidity,
                condition=condition,
            )
        )
    return forecasts


# ── API Functions ───────────────────────────────────────────────────────

async def get_current_weather(city: str) -> WeatherData:
    """
    Fetch current weather for a city from OpenWeatherMap.

    Falls back to cached data or hardcoded defaults when the API
    key is missing or the request fails.

    Args:
        city: City name (e.g. ``"Bengaluru"``).

    Returns:
        ``WeatherData`` instance.
    """
    cache_key = f"weather:current:{city.lower()}"

    # Try Redis cache
    try:
        redis = await _get_redis()
        cached = await redis.get(cache_key)
        if cached is not None:
            return WeatherData.model_validate_json(cached)
    except Exception as exc:
        logger.warning("Redis read failed for weather: %s", exc)

    # Guard: no API key
    if not settings.OPENWEATHER_API_KEY:
        logger.info("No OpenWeather API key configured — using fallback weather.")
        return _FALLBACK_WEATHER

    # Fetch from API
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{_OWM_BASE}/weather",
                params={
                    "q": city,
                    "appid": settings.OPENWEATHER_API_KEY,
                    "units": "metric",
                },
            )
            resp.raise_for_status()
            data = resp.json()

            weather = WeatherData(
                temp_celsius=data["main"]["temp"],
                humidity_percent=data["main"]["humidity"],
                feels_like=data["main"]["feels_like"],
                condition=data["weather"][0]["main"],
                wind_speed=data["wind"]["speed"],
            )

            # Cache result
            try:
                redis = await _get_redis()
                await redis.set(cache_key, weather.model_dump_json(), ex=_REDIS_TTL_SECONDS)
            except Exception as exc:
                logger.warning("Redis write failed for weather: %s", exc)

            return weather

    except Exception as exc:
        logger.error("Weather API request failed for %s: %s", city, exc)
        return _FALLBACK_WEATHER


async def get_forecast_48h(city: str) -> list[HourlyForecast]:
    """
    Fetch a 48-hour hourly forecast for a city from OpenWeatherMap.

    Uses the ``/forecast`` endpoint (3-hour intervals on free tier)
    and interpolates to approximate hourly data.

    Falls back to a synthetic sinusoidal forecast when the API is
    unavailable.

    Args:
        city: City name.

    Returns:
        List of ``HourlyForecast`` entries.
    """
    cache_key = f"weather:forecast48:{city.lower()}"

    # Try Redis cache
    try:
        redis = await _get_redis()
        cached = await redis.get(cache_key)
        if cached is not None:
            import json as _json
            raw_list = _json.loads(cached)
            return [HourlyForecast(**item) for item in raw_list]
    except Exception as exc:
        logger.warning("Redis read failed for forecast: %s", exc)

    if not settings.OPENWEATHER_API_KEY:
        logger.info("No OpenWeather API key — using fallback forecast.")
        return _generate_fallback_forecast()

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{_OWM_BASE}/forecast",
                params={
                    "q": city,
                    "appid": settings.OPENWEATHER_API_KEY,
                    "units": "metric",
                    "cnt": 16,  # 16 × 3h = 48h
                },
            )
            resp.raise_for_status()
            data = resp.json()

            forecasts: list[HourlyForecast] = []
            for entry in data.get("list", []):
                dt_txt = entry.get("dt_txt", "")
                main = entry.get("main", {})
                weather_arr = entry.get("weather", [{}])
                forecasts.append(
                    HourlyForecast(
                        datetime=dt_txt,
                        temp_celsius=main.get("temp", 30.0),
                        humidity_percent=main.get("humidity", 50),
                        condition=weather_arr[0].get("main", "Clear"),
                    )
                )

            # Interpolate 3-hour entries to hourly
            hourly: list[HourlyForecast] = []
            for i, fc in enumerate(forecasts):
                hourly.append(fc)
                # Insert 2 interpolated entries between consecutive 3-hour points
                if i + 1 < len(forecasts):
                    next_fc = forecasts[i + 1]
                    for step in (1, 2):
                        frac = step / 3.0
                        interp_temp = round(
                            fc.temp_celsius + frac * (next_fc.temp_celsius - fc.temp_celsius), 1
                        )
                        interp_hum = round(
                            fc.humidity_percent + frac * (next_fc.humidity_percent - fc.humidity_percent), 1
                        )
                        hourly.append(
                            HourlyForecast(
                                datetime=fc.datetime,  # approximate
                                temp_celsius=interp_temp,
                                humidity_percent=interp_hum,
                                condition=fc.condition,
                            )
                        )

            # Trim to 48
            hourly = hourly[:48]

            # Cache
            try:
                import json as _json
                redis = await _get_redis()
                serialized = _json.dumps([f.model_dump() for f in hourly])
                await redis.set(cache_key, serialized, ex=_REDIS_TTL_SECONDS)
            except Exception as exc:
                logger.warning("Redis write failed for forecast: %s", exc)

            return hourly

    except Exception as exc:
        logger.error("Forecast API request failed for %s: %s", city, exc)
        return _generate_fallback_forecast()


def estimate_ac_load_factor(temp_celsius: float, humidity_percent: float) -> float:
    """
    Estimate air-conditioning load factor based on weather conditions.

    Returns a multiplier between 0.0 and 1.0 indicating how
    intensively an AC unit needs to run:
        - 0.0 = AC not needed at all
        - 1.0 = AC at full load

    The formula accounts for both temperature and humidity, since
    high humidity makes the same temperature feel much worse.

    Args:
        temp_celsius: Current temperature in °C.
        humidity_percent: Current relative humidity (0-100).

    Returns:
        Load factor between 0.0 and 1.0.
    """
    # Below 24 °C — no AC needed
    if temp_celsius <= 24.0:
        return 0.0

    # Temperature component (linear ramp from 24 → 42 °C)
    temp_factor = min((temp_celsius - 24.0) / (42.0 - 24.0), 1.0)

    # Humidity adds up to 20% extra load
    humidity_factor = max(0.0, (humidity_percent - 40.0) / 60.0) * 0.20

    load = min(temp_factor + humidity_factor, 1.0)
    return round(load, 2)
