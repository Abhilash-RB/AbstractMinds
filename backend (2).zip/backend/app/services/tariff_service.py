"""
Tariff service — loads DISCOM tariff data, computes hourly rates,
and calculates session costs.

Caches tariff data in Redis with a 24-hour TTL to avoid repeated
disk reads.
"""

import json
import logging
from pathlib import Path
from typing import Any, Optional

import redis.asyncio as aioredis
from pydantic import BaseModel

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# ── Path to tariff JSON files ───────────────────────────────────────────
_TARIFF_DIR = Path(__file__).resolve().parents[2] / "data" / "discom_tariffs"
_RURAL_TEMPLATE = "rural_generic_template"
_REDIS_TTL_SECONDS = 86_400  # 24 hours


# ── Pydantic Schemas ────────────────────────────────────────────────────

class SlabEntry(BaseModel):
    """A single slab in a tiered tariff structure."""
    min_units: float
    max_units: float
    rate_per_unit: float
    description: str = ""


class PeakHourEntry(BaseModel):
    """Peak hour window with its rate multiplier."""
    start_hour: int
    end_hour: int
    multiplier: float
    label: str = ""


class TariffSchema(BaseModel):
    """Parsed tariff data for a DISCOM."""
    discom: str
    state: str
    zone: str
    effective_from: str
    slab_data: list[SlabEntry]
    peak_hours: list[PeakHourEntry]
    off_peak_discount: float = 0.0
    fixed_charges_per_month: float = 0.0
    taxes_percentage: float = 0.0
    is_flat_rate: bool = False
    average_flat_rate_per_unit: float = 0.0


class SessionCostResult(BaseModel):
    """Result of a single-session cost calculation."""
    units_consumed: float
    cost_inr: float
    avg_rate: float
    peak_hours_used: int


# ── Redis Client (lazy singleton) ──────────────────────────────────────

_redis_client: Optional[aioredis.Redis] = None


async def _get_redis() -> aioredis.Redis:
    """Return a cached async Redis connection."""
    global _redis_client
    if _redis_client is None:
        _redis_client = aioredis.from_url(
            settings.REDIS_URL,
            decode_responses=True,
        )
    return _redis_client


# ── File-name resolution ────────────────────────────────────────────────

def _resolve_tariff_filename(discom_name: str) -> Path:
    """
    Map a DISCOM name to a JSON file path.

    Uses a simple slug: lowercase, spaces → underscores.
    Falls back to the rural generic template when no file is found.
    """
    slug = discom_name.strip().lower().replace(" ", "_")
    candidates = [
        _TARIFF_DIR / f"{slug}.json",
    ]
    # Also try common suffixed patterns
    for suffix in ("_karnataka", "_mumbai", "_delhi", "_maharashtra",
                   "_tamil_nadu", "_telangana", "_gujarat", "_rajasthan"):
        candidates.append(_TARIFF_DIR / f"{slug}{suffix}.json")

    for path in candidates:
        if path.exists():
            return path

    # Search all files for a matching discom field
    for json_file in _TARIFF_DIR.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
            if data.get("discom", "").lower() == discom_name.lower():
                return json_file
        except (json.JSONDecodeError, OSError):
            continue

    # Fallback
    fallback = _TARIFF_DIR / f"{_RURAL_TEMPLATE}.json"
    logger.warning(
        "No tariff file found for DISCOM '%s'. Using rural generic template.",
        discom_name,
    )
    return fallback


# ── Core Functions ──────────────────────────────────────────────────────

def _parse_fixed_charges(raw: Any) -> float:
    """Extract a numeric fixed-charge value from dict or float."""
    if isinstance(raw, (int, float)):
        return float(raw)
    if isinstance(raw, dict):
        return float(raw.get("default", 0))
    return 0.0


def _parse_tariff_json(data: dict) -> TariffSchema:
    """Convert raw JSON dict into a validated TariffSchema."""
    slabs = [SlabEntry(**s) for s in data.get("slab_data", [])]
    peaks = [PeakHourEntry(**p) for p in data.get("peak_hours", [])]
    taxes = data.get("taxes", {})
    taxes_pct = float(taxes.get("total_taxes_percentage", 0)) if isinstance(taxes, dict) else 0.0

    return TariffSchema(
        discom=data.get("discom", "UNKNOWN"),
        state=data.get("state", ""),
        zone=data.get("zone", "rural"),
        effective_from=data.get("effective_from", ""),
        slab_data=slabs,
        peak_hours=peaks,
        off_peak_discount=float(data.get("off_peak_discount", 0)),
        fixed_charges_per_month=_parse_fixed_charges(data.get("fixed_charges_per_month", 0)),
        taxes_percentage=taxes_pct,
        is_flat_rate=data.get("is_flat_rate", False),
        average_flat_rate_per_unit=float(data.get("average_flat_rate_per_unit", 0)),
    )


async def load_tariff(discom_name: str) -> TariffSchema:
    """
    Load tariff data for a DISCOM, using Redis cache if available.

    Args:
        discom_name: Name of the DISCOM (e.g. ``"BESCOM"``).

    Returns:
        Parsed ``TariffSchema`` instance.
    """
    cache_key = f"tariff:{discom_name.lower().replace(' ', '_')}"

    # Try Redis cache first
    try:
        redis = await _get_redis()
        cached = await redis.get(cache_key)
        if cached is not None:
            logger.debug("Tariff cache hit for %s", discom_name)
            return TariffSchema.model_validate_json(cached)
    except Exception as exc:
        logger.warning("Redis cache read failed: %s", exc)

    # Load from disk
    filepath = _resolve_tariff_filename(discom_name)
    raw = json.loads(filepath.read_text(encoding="utf-8"))
    tariff = _parse_tariff_json(raw)

    # Write to cache
    try:
        redis = await _get_redis()
        await redis.set(cache_key, tariff.model_dump_json(), ex=_REDIS_TTL_SECONDS)
        logger.debug("Tariff cached for %s (TTL %ds)", discom_name, _REDIS_TTL_SECONDS)
    except Exception as exc:
        logger.warning("Redis cache write failed: %s", exc)

    return tariff


def _get_slab_rate(slabs: list[SlabEntry], monthly_units_so_far: float) -> float:
    """
    Determine the marginal slab rate based on cumulative monthly units.

    Args:
        slabs: Ordered list of slab entries.
        monthly_units_so_far: Total units consumed this month *before*
            the current session.

    Returns:
        Rate in INR per unit for the applicable slab.
    """
    for slab in slabs:
        if slab.min_units <= monthly_units_so_far <= slab.max_units:
            return slab.rate_per_unit
    # If beyond all slabs, return the highest slab rate
    if slabs:
        return slabs[-1].rate_per_unit
    return 5.0  # Absolute fallback


def _is_peak_hour(peak_hours: list[PeakHourEntry], hour: int) -> tuple[bool, float]:
    """
    Check whether an hour falls within any peak window.

    Returns:
        Tuple of (is_peak, multiplier).  If not peak, multiplier is 1.0.
    """
    for peak in peak_hours:
        if peak.start_hour <= hour < peak.end_hour:
            return True, peak.multiplier
    return False, 1.0


def _is_off_peak_hour(peak_hours: list[PeakHourEntry], hour: int) -> bool:
    """
    Simple heuristic: if not in any peak window and hour is 22-6,
    it's off-peak.
    """
    is_peak, _ = _is_peak_hour(peak_hours, hour)
    if is_peak:
        return False
    return hour >= 22 or hour < 6


async def get_hourly_rate(
    discom: str, hour: int, monthly_units_so_far: float
) -> float:
    """
    Return the effective INR/unit rate for a given hour.

    Takes into account:
        1. Which tariff slab the user is currently in
        2. Whether the hour is a peak hour (higher multiplier)
        3. Whether the hour is an off-peak hour (discount)

    Args:
        discom: DISCOM name.
        hour: Hour of the day (0-23).
        monthly_units_so_far: Cumulative units consumed this month.

    Returns:
        Effective rate in INR per kWh.
    """
    tariff = await load_tariff(discom)

    # Flat-rate tariff (rural) — no hourly variation
    if tariff.is_flat_rate:
        return tariff.average_flat_rate_per_unit or _get_slab_rate(
            tariff.slab_data, monthly_units_so_far
        )

    base_rate = _get_slab_rate(tariff.slab_data, monthly_units_so_far)

    # Peak multiplier
    is_peak, multiplier = _is_peak_hour(tariff.peak_hours, hour)
    if is_peak:
        return round(base_rate * multiplier, 2)

    # Off-peak discount
    if _is_off_peak_hour(tariff.peak_hours, hour) and tariff.off_peak_discount > 0:
        discounted = base_rate * (1 - tariff.off_peak_discount)
        return round(discounted, 2)

    return round(base_rate, 2)


async def calculate_session_cost(
    discom: str,
    wattage_watts: float,
    duration_hours: float,
    start_hour: int,
    monthly_units_so_far: float,
) -> dict:
    """
    Calculate the cost of running an appliance for a given duration.

    The session may span multiple hours, each potentially having
    different rates (peak vs. off-peak).

    Args:
        discom: DISCOM name.
        wattage_watts: Appliance wattage in watts.
        duration_hours: How long the appliance runs (hours, can be fractional).
        start_hour: Hour when the appliance starts (0-23).
        monthly_units_so_far: Units already consumed this month.

    Returns:
        Dict with ``units_consumed``, ``cost_inr``, ``avg_rate``,
        and ``peak_hours_used``.
    """
    units_per_hour = wattage_watts / 1000.0  # Convert watts → kW
    total_units = 0.0
    total_cost = 0.0
    peak_count = 0
    cumulative = monthly_units_so_far

    remaining = duration_hours
    current_hour = start_hour

    while remaining > 0:
        # Duration for this hour-slot (up to 1 hour or the remainder)
        slot_duration = min(remaining, 1.0)
        slot_units = units_per_hour * slot_duration

        rate = await get_hourly_rate(discom, current_hour % 24, cumulative)
        slot_cost = slot_units * rate

        # Check peak
        tariff = await load_tariff(discom)
        is_peak, _ = _is_peak_hour(tariff.peak_hours, current_hour % 24)
        if is_peak:
            peak_count += 1

        total_units += slot_units
        total_cost += slot_cost
        cumulative += slot_units
        remaining -= slot_duration
        current_hour += 1

    avg_rate = total_cost / total_units if total_units > 0 else 0.0

    result = SessionCostResult(
        units_consumed=round(total_units, 4),
        cost_inr=round(total_cost, 2),
        avg_rate=round(avg_rate, 2),
        peak_hours_used=peak_count,
    )
    return result.model_dump()
