"""
Authentication routes — register, login, and user profile.
"""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import (
    create_access_token,
    get_current_user,
    hash_password,
    verify_password,
)
from app.db.database import get_db
from app.db.models.user import User
from app.utils.discom_mapper import get_discom, get_tariff_zone

router = APIRouter(prefix="/auth", tags=["Authentication"])


class RegisterRequest(BaseModel):
    """Registration request body."""
    email: str
    password: str
    full_name: str
    city: str
    state: str


class LoginRequest(BaseModel):
    """Login request body."""
    email: str
    password: str


class TokenResponse(BaseModel):
    """JWT token response."""
    access_token: str
    token_type: str = "bearer"
    user_id: str


class UserProfile(BaseModel):
    """Public user profile."""
    id: str
    email: str
    full_name: str
    city: str
    state: str
    discom_name: str | None
    is_rural: bool


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(body: RegisterRequest, db: AsyncSession = Depends(get_db)):
    """Register a new user account."""
    # Check duplicate email
    existing = await db.execute(select(User).where(User.email == body.email))
    if existing.scalar_one_or_none() is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already registered")

    discom = get_discom(body.city, body.state)
    zone = get_tariff_zone(body.city)

    user = User(
        email=body.email,
        hashed_password=hash_password(body.password),
        full_name=body.full_name,
        city=body.city,
        state=body.state,
        discom_name=discom,
        is_rural=(zone == "rural"),
    )
    db.add(user)
    await db.flush()

    token = create_access_token(user.id, user.email)
    return TokenResponse(access_token=token, user_id=str(user.id))


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    """Authenticate and return a JWT."""
    result = await db.execute(select(User).where(User.email == body.email))
    user = result.scalar_one_or_none()
    if user is None or not verify_password(body.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    token = create_access_token(user.id, user.email)
    return TokenResponse(access_token=token, user_id=str(user.id))


@router.get("/me", response_model=UserProfile)
async def get_me(user: User = Depends(get_current_user)):
    """Get the authenticated user's profile."""
    return UserProfile(
        id=str(user.id),
        email=user.email,
        full_name=user.full_name,
        city=user.city,
        state=user.state,
        discom_name=user.discom_name,
        is_rural=user.is_rural,
    )
