"""
Prediction API routes.

POST /predictions/bill       — predict monthly bill
POST /predictions/schedule   — get optimized appliance schedule
GET  /predictions/peak-hours — today's peak/off-peak hours & rates
GET  /predictions/anomalies  — recent anomalies for the user

All routes require JWT authentication and log predictions.
"""

import logging
import uuid
from datetime import date, datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import get_current_user
from app.db.database import get_db
from app.db.models.user import User
from app.db.models.prediction_log import PredictionLog, PredictionType
from app.ml.models.bill_predictor import BillPredictorModel, BillPrediction
from app.ml.models.demand_forecaster import DemandForecasterModel
from app.ml.models.schedule_optimizer import (
    ApplianceInput,
    DaySchedule,
    HourlyDemand,
    ScheduleOptimizer,
    TariffProfile,
    UserPreferences,
)
from app.ml.models.usage_anomaly import UsageAnomalyDetector
from app.services.tariff_service import get_hourly_rate, load_tariff
from app.services.weather_service import get_current_weather
from app.ai.claude_agent import EnergyAdvisorAgent
from app.ai.context_builder import ContextBuilder

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/predictions", tags=["Predictions"])

# ── Singleton model instances (loaded at startup) ───────────────────────
_bill_model = BillPredictorModel()
_demand_model = DemandForecasterModel()
_optimizer = ScheduleOptimizer()
_anomaly_detector = UsageAnomalyDetector()
_advisor = EnergyAdvisorAgent()


# ── Request / Response Schemas ──────────────────────────────────────────

class ApplianceItem(BaseModel):
    """Appliance input for prediction requests."""
    name: str
    wattage_watts: float
    avg_daily_usage_hours: float = 4.0
    category: str = "other"
    is_schedulable: bool = True
    preferred_start_hour: int = 0
    preferred_end_hour: int = 23


class BillPredictRequest(BaseModel):
    """Request body for bill prediction."""
    appliances: list[ApplianceItem]
    city: str
    month: int = 0  # 0 = current month
    household_size: int = 4
    previous_month_units: float = 250.0


class BillPredictResponse(BaseModel):
    """Response for bill prediction."""
    prediction: dict
    ai_explanation: str


class ScheduleRequest(BaseModel):
    """Request body for schedule optimization."""
    date: str = ""  # ISO date, default today
    appliances: list[ApplianceItem]
    avoid_hours: list[int] = []
    prefer_hours: list[int] = []


class ScheduleResponse(BaseModel):
    """Response for schedule optimization."""
    schedule: dict
    ai_reasoning: str


class PeakHoursResponse(BaseModel):
    """Response for peak hours query."""
    peak_hours: list[int]
    off_peak_hours: list[int]
    hourly_rates: list[dict]


class AnomalyResponse(BaseModel):
    """Response for anomaly detection."""
    anomalies: list[dict]


# ── Helper: log prediction ──────────────────────────────────────────────

async def _log_prediction(
    db: AsyncSession,
    user_id: uuid.UUID,
    pred_type: PredictionType,
    input_features: dict,
    predicted_value: dict,
    confidence: float | None = None,
    model_version: str = "",
) -> None:
    """Write a prediction record to the database."""
    log = PredictionLog(
        user_id=user_id,
        prediction_type=pred_type,
        input_features=input_features,
        predicted_value=predicted_value,
        confidence_score=confidence,
        model_version=model_version,
    )
    db.add(log)
    try:
        await db.flush()
    except Exception as exc:
        logger.warning("Failed to log prediction: %s", exc)


# ── Routes ──────────────────────────────────────────────────────────────

@router.post("/bill", response_model=BillPredictResponse)
async def predict_bill(
    body: BillPredictRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> BillPredictResponse:
    """Predict the user's monthly electricity bill."""
    month = body.month or datetime.now().month

    # Get weather for load factor
    weather = await get_current_weather(body.city or user.city)

    # Load tariff
    tariff = await load_tariff(user.discom_name or "GENERIC_RURAL")

    # Build features
    features = {
        "city": body.city or user.city,
        "month": month,
        "avg_daily_temp": weather.temp_celsius,
        "appliances": [a.model_dump() for a in body.appliances],
        "household_size": body.household_size,
        "previous_month_units": body.previous_month_units,
        "discom": user.discom_name or "",
        "tariff_rate": tariff.slab_data[2].rate_per_unit if len(tariff.slab_data) > 2 else 6.5,
        "fixed_charges": tariff.fixed_charges_per_month,
        "taxes_percentage": tariff.taxes_percentage,
        "days_in_month": 30,
    }

    prediction = _bill_model.predict_monthly_bill(features)
    pred_dict = prediction.model_dump()

    # AI explanation
    user_data = {
        "city": user.city,
        "discom": user.discom_name,
        "full_name": user.full_name,
    }
    try:
        explanation = await _advisor.explain_bill(user_data, pred_dict)
    except Exception:
        explanation = (
            f"Your estimated bill for this month is ₹{prediction.predicted_cost_inr:.0f} "
            f"({prediction.predicted_units_kwh:.0f} units)."
        )

    # Log
    await _log_prediction(
        db, user.id, PredictionType.BILL,
        features, pred_dict,
        confidence=None,
        model_version=prediction.model_version,
    )

    return BillPredictResponse(prediction=pred_dict, ai_explanation=explanation)


@router.post("/schedule", response_model=ScheduleResponse)
async def predict_schedule(
    body: ScheduleRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> ScheduleResponse:
    """Get an AI-optimized appliance schedule for a day."""
    schedule_date = body.date or date.today().isoformat()
    tariff = await load_tariff(user.discom_name or "GENERIC_RURAL")
    weather = await get_current_weather(user.city)

    # Build 24-hour rate profile
    rates = []
    for h in range(24):
        r = await get_hourly_rate(
            user.discom_name or "GENERIC_RURAL", h, 200.0
        )
        rates.append(r)

    tariff_profile = TariffProfile(hourly_rates=rates)

    # Demand forecast
    demand_forecast_raw = _demand_model.predict_next_24h({
        "temperature": weather.temp_celsius,
        "humidity": weather.humidity_percent,
        "current_hour": datetime.now().hour,
    })
    demand_forecast = [
        HourlyDemand(
            hour=f.hour, demand_mw=f.demand_mw, is_likely_peak=f.is_likely_peak
        )
        for f in demand_forecast_raw
    ]

    # Build appliance inputs
    appliance_inputs = [
        ApplianceInput(
            name=a.name,
            wattage_watts=a.wattage_watts,
            duration_hours=a.avg_daily_usage_hours,
            is_schedulable=a.is_schedulable,
            preferred_start_hour=a.preferred_start_hour,
            preferred_end_hour=a.preferred_end_hour,
            category=a.category,
        )
        for a in body.appliances
    ]

    prefs = UserPreferences(
        avoid_hours=body.avoid_hours,
        prefer_hours=body.prefer_hours,
    )

    schedule = _optimizer.optimize_day_schedule(
        appliance_inputs, tariff_profile, demand_forecast, prefs, schedule_date
    )
    schedule_dict = schedule.model_dump()

    # AI reasoning
    try:
        reasoning = await _advisor.recommend_schedule(
            schedule_dict, weather.model_dump()
        )
    except Exception:
        reasoning = "Schedule optimized to minimize electricity cost."

    # Log
    await _log_prediction(
        db, user.id, PredictionType.SCHEDULE,
        {"appliances": [a.model_dump() for a in body.appliances], "date": schedule_date},
        schedule_dict,
        model_version=_optimizer.__class__.__name__,
    )

    return ScheduleResponse(schedule=schedule_dict, ai_reasoning=reasoning)


@router.get("/peak-hours", response_model=PeakHoursResponse)
async def get_peak_hours(
    user: User = Depends(get_current_user),
) -> PeakHoursResponse:
    """Get today's peak/off-peak hours and hourly rates."""
    tariff = await load_tariff(user.discom_name or "GENERIC_RURAL")
    weather = await get_current_weather(user.city)

    # Demand forecast
    forecast = _demand_model.predict_next_24h({
        "temperature": weather.temp_celsius,
        "humidity": weather.humidity_percent,
        "current_hour": datetime.now().hour,
    })
    peak_hours = DemandForecasterModel.classify_peak_hours(forecast)
    off_peak = [h for h in range(24) if h not in peak_hours]

    # Hourly rates
    hourly_rates = []
    for h in range(24):
        rate = await get_hourly_rate(user.discom_name or "GENERIC_RURAL", h, 200.0)
        hourly_rates.append({"hour": h, "rate_inr_per_unit": rate})

    return PeakHoursResponse(
        peak_hours=peak_hours,
        off_peak_hours=off_peak,
        hourly_rates=hourly_rates,
    )


@router.get("/anomalies", response_model=AnomalyResponse)
async def get_anomalies(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AnomalyResponse:
    """Get recent anomalies detected for the user's appliances."""
    from sqlalchemy import select
    from app.db.models.usage_log import UsageLog
    from app.db.models.appliance import Appliance

    # Fetch appliances
    result = await db.execute(
        select(Appliance).where(Appliance.user_id == user.id)
    )
    appliances = result.scalars().all()

    all_anomalies: list[dict] = []
    for appl in appliances:
        # Fetch recent usage logs
        log_result = await db.execute(
            select(UsageLog)
            .where(UsageLog.appliance_id == appl.id)
            .order_by(UsageLog.recorded_at.desc())
            .limit(168)  # 7 days
        )
        logs = log_result.scalars().all()
        log_dicts = [
            {
                "hour_of_day": l.hour_of_day,
                "units_consumed_kwh": l.units_consumed_kwh,
                "usage_date": l.usage_date.isoformat() if l.usage_date else "",
            }
            for l in logs
        ]

        appl_dict = {
            "name": appl.name,
            "wattage_watts": appl.wattage_watts,
            "category": appl.category.value if appl.category else "other",
            "preferred_start_hour": appl.preferred_start_hour,
            "preferred_end_hour": appl.preferred_end_hour,
        }

        anomalies = _anomaly_detector.detect_anomalies(log_dicts, appl_dict)
        all_anomalies.extend([a.model_dump() for a in anomalies])

    # Log
    if all_anomalies:
        await _log_prediction(
            db, user.id, PredictionType.ANOMALY,
            {"appliance_count": len(appliances)},
            {"anomalies": all_anomalies},
        )

    return AnomalyResponse(anomalies=all_anomalies)
