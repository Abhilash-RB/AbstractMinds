"""
Appliances API routes — list, add, update, delete, defaults, bulk.
"""
from __future__ import annotations
import json, logging, uuid
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.auth import get_current_user
from app.db.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/appliances", tags=["Appliances"])

DATA_DIR = Path(__file__).resolve().parents[4] / "data"
APPLIANCE_DEFAULTS_PATH = DATA_DIR / "appliance_defaults.json"

WATTAGE_RANGES: dict[str, tuple[int, int]] = {
    "cooling": (500, 5000), "heating": (500, 3000), "washing": (300, 2500),
    "ev": (3000, 22000), "lighting": (5, 200), "cooking": (500, 3000),
    "entertainment": (10, 500), "other": (10, 5000),
}

def _check_wattage(wattage: int, category: str) -> None:
    lo, hi = WATTAGE_RANGES.get(category.lower(), (10, 5000))
    if not (lo <= wattage <= hi):
        raise HTTPException(422, f"Wattage {wattage}W out of range for '{category}' ({lo}–{hi}W).")

class ApplianceCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    category: str = "other"
    wattage_watts: int = Field(ge=1, le=25000)
    avg_daily_usage_hours: float = Field(ge=0.0, le=24.0)
    is_schedulable: bool = True
    preferred_start_hour: int = Field(default=0, ge=0, le=23)
    preferred_end_hour: int = Field(default=23, ge=0, le=23)

    @field_validator("category")
    @classmethod
    def _norm(cls, v: str) -> str:
        return v.lower().strip()

class ApplianceUpdate(BaseModel):
    name: str | None = None
    category: str | None = None
    wattage_watts: int | None = Field(default=None, ge=1, le=25000)
    avg_daily_usage_hours: float | None = Field(default=None, ge=0.0, le=24.0)
    is_schedulable: bool | None = None
    preferred_start_hour: int | None = Field(default=None, ge=0, le=23)
    preferred_end_hour: int | None = Field(default=None, ge=0, le=23)

class ApplianceOut(BaseModel):
    id: str; name: str; category: str; wattage_watts: int
    avg_daily_usage_hours: float; is_schedulable: bool
    preferred_start_hour: int; preferred_end_hour: int; user_id: str

class BulkRequest(BaseModel):
    appliances: list[ApplianceCreate] = Field(min_length=1, max_length=30)

def _mock_out(body: ApplianceCreate, user_id: str, aid: str) -> ApplianceOut:
    return ApplianceOut(id=aid, name=body.name, category=body.category,
        wattage_watts=body.wattage_watts, avg_daily_usage_hours=body.avg_daily_usage_hours,
        is_schedulable=body.is_schedulable, preferred_start_hour=body.preferred_start_hour,
        preferred_end_hour=body.preferred_end_hour, user_id=user_id)

@router.get("", response_model=list[ApplianceOut])
async def list_appliances(cu: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """List all appliances for the authenticated user."""
    user_id = cu["sub"]
    try:
        from sqlalchemy import select
        from app.db.models.appliance import Appliance  # type: ignore
        rows = (await db.execute(select(Appliance).where(Appliance.user_id == user_id))).scalars().all()
        return [ApplianceOut(id=str(r.id), name=r.name, category=r.category,
            wattage_watts=r.wattage_watts, avg_daily_usage_hours=r.avg_daily_usage_hours,
            is_schedulable=r.is_schedulable, preferred_start_hour=r.preferred_start_hour,
            preferred_end_hour=r.preferred_end_hour, user_id=str(r.user_id)) for r in rows]
    except ImportError:
        return []

@router.post("", response_model=ApplianceOut, status_code=201)
async def add_appliance(body: ApplianceCreate, cu: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """Add a new appliance; validates wattage range per category."""
    _check_wattage(body.wattage_watts, body.category)
    user_id = cu["sub"]
    try:
        from app.db.models.appliance import Appliance  # type: ignore
        a = Appliance(user_id=user_id, **body.model_dump())
        db.add(a); await db.commit(); await db.refresh(a)
        return ApplianceOut(id=str(a.id), name=a.name, category=a.category,
            wattage_watts=a.wattage_watts, avg_daily_usage_hours=a.avg_daily_usage_hours,
            is_schedulable=a.is_schedulable, preferred_start_hour=a.preferred_start_hour,
            preferred_end_hour=a.preferred_end_hour, user_id=str(a.user_id))
    except ImportError:
        return _mock_out(body, user_id, str(uuid.uuid4()))

@router.put("/{appliance_id}", response_model=ApplianceOut)
async def update_appliance(appliance_id: str, body: ApplianceUpdate, cu: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """Update an appliance owned by the authenticated user."""
    if body.wattage_watts and body.category:
        _check_wattage(body.wattage_watts, body.category)
    user_id = cu["sub"]
    try:
        from sqlalchemy import select
        from app.db.models.appliance import Appliance  # type: ignore
        a = (await db.execute(select(Appliance).where(Appliance.id == appliance_id, Appliance.user_id == user_id))).scalar_one_or_none()
        if a is None: raise HTTPException(404, "Appliance not found.")
        for k, v in body.model_dump(exclude_none=True).items(): setattr(a, k, v)
        await db.commit(); await db.refresh(a)
        return ApplianceOut(id=str(a.id), name=a.name, category=a.category,
            wattage_watts=a.wattage_watts, avg_daily_usage_hours=a.avg_daily_usage_hours,
            is_schedulable=a.is_schedulable, preferred_start_hour=a.preferred_start_hour,
            preferred_end_hour=a.preferred_end_hour, user_id=str(a.user_id))
    except ImportError:
        raise HTTPException(503, "Database not available.")

@router.delete("/{appliance_id}", status_code=204)
async def delete_appliance(appliance_id: str, cu: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """Delete an appliance owned by the authenticated user."""
    user_id = cu["sub"]
    try:
        from sqlalchemy import select
        from app.db.models.appliance import Appliance  # type: ignore
        a = (await db.execute(select(Appliance).where(Appliance.id == appliance_id, Appliance.user_id == user_id))).scalar_one_or_none()
        if a is None: raise HTTPException(404, "Appliance not found.")
        await db.delete(a); await db.commit()
    except ImportError:
        pass

@router.get("/defaults", response_model=list[dict])
async def get_defaults():
    """Return curated list of common Indian household appliances as onboarding suggestions."""
    if APPLIANCE_DEFAULTS_PATH.exists():
        return json.loads(APPLIANCE_DEFAULTS_PATH.read_text())
    return [
        {"name": "Split AC 1.5 Ton", "typical_wattage_watts": 1500, "category": "cooling", "icon_emoji": "❄️", "is_schedulable": True},
        {"name": "Ceiling Fan", "typical_wattage_watts": 75, "category": "other", "icon_emoji": "🌀", "is_schedulable": True},
        {"name": "Refrigerator", "typical_wattage_watts": 150, "category": "other", "icon_emoji": "🧊", "is_schedulable": False},
        {"name": "Geyser 15L", "typical_wattage_watts": 2000, "category": "heating", "icon_emoji": "🚿", "is_schedulable": True},
        {"name": "Washing Machine", "typical_wattage_watts": 500, "category": "washing", "icon_emoji": "🫧", "is_schedulable": True},
    ]

@router.post("/bulk", response_model=list[ApplianceOut], status_code=201)
async def bulk_add(body: BulkRequest, cu: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """Add multiple appliances in one request (used during onboarding)."""
    user_id = cu["sub"]
    results: list[ApplianceOut] = []
    for item in body.appliances:
        _check_wattage(item.wattage_watts, item.category)
        try:
            from app.db.models.appliance import Appliance  # type: ignore
            a = Appliance(user_id=user_id, **item.model_dump())
            db.add(a); await db.flush()
            results.append(ApplianceOut(id=str(a.id), name=a.name, category=a.category,
                wattage_watts=a.wattage_watts, avg_daily_usage_hours=a.avg_daily_usage_hours,
                is_schedulable=a.is_schedulable, preferred_start_hour=a.preferred_start_hour,
                preferred_end_hour=a.preferred_end_hour, user_id=user_id))
        except ImportError:
            results.append(_mock_out(item, user_id, str(uuid.uuid4())))
    try: await db.commit()
    except Exception: pass
    return results
