"""
Appliance CRUD routes.
"""

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import get_current_user
from app.db.database import get_db
from app.db.models.appliance import Appliance, ApplianceCategory
from app.db.models.user import User

router = APIRouter(prefix="/appliances", tags=["Appliances"])


class ApplianceCreate(BaseModel):
    """Request body to create an appliance."""
    name: str
    category: str = "other"
    wattage_watts: float
    avg_daily_usage_hours: float = 2.0
    is_schedulable: bool = True
    preferred_start_hour: int = 0
    preferred_end_hour: int = 23


class ApplianceOut(BaseModel):
    """Appliance response schema."""
    id: str
    name: str
    category: str
    wattage_watts: float
    avg_daily_usage_hours: float
    is_schedulable: bool
    preferred_start_hour: int
    preferred_end_hour: int


@router.post("/", response_model=ApplianceOut, status_code=status.HTTP_201_CREATED)
async def create_appliance(
    body: ApplianceCreate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Add a new appliance for the authenticated user."""
    try:
        cat = ApplianceCategory(body.category)
    except ValueError:
        cat = ApplianceCategory.OTHER

    appl = Appliance(
        user_id=user.id,
        name=body.name,
        category=cat,
        wattage_watts=body.wattage_watts,
        avg_daily_usage_hours=body.avg_daily_usage_hours,
        is_schedulable=body.is_schedulable,
        preferred_start_hour=body.preferred_start_hour,
        preferred_end_hour=body.preferred_end_hour,
    )
    db.add(appl)
    await db.flush()
    return ApplianceOut(
        id=str(appl.id), name=appl.name, category=appl.category.value,
        wattage_watts=appl.wattage_watts,
        avg_daily_usage_hours=appl.avg_daily_usage_hours,
        is_schedulable=appl.is_schedulable,
        preferred_start_hour=appl.preferred_start_hour,
        preferred_end_hour=appl.preferred_end_hour,
    )


@router.get("/", response_model=list[ApplianceOut])
async def list_appliances(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all appliances for the authenticated user."""
    result = await db.execute(
        select(Appliance).where(Appliance.user_id == user.id)
    )
    appliances = result.scalars().all()
    return [
        ApplianceOut(
            id=str(a.id), name=a.name, category=a.category.value,
            wattage_watts=a.wattage_watts,
            avg_daily_usage_hours=a.avg_daily_usage_hours,
            is_schedulable=a.is_schedulable,
            preferred_start_hour=a.preferred_start_hour,
            preferred_end_hour=a.preferred_end_hour,
        )
        for a in appliances
    ]


@router.delete("/{appliance_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_appliance(
    appliance_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete an appliance by ID."""
    result = await db.execute(
        select(Appliance).where(
            Appliance.id == uuid.UUID(appliance_id),
            Appliance.user_id == user.id,
        )
    )
    appl = result.scalar_one_or_none()
    if appl is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Appliance not found")
    await db.delete(appl)
