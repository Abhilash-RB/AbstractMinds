"""
Authentication API routes for ThunderVolts.

Routes:
  POST /auth/register  — Create account and return JWT
  POST /auth/login     — Authenticate and return JWT
  GET  /auth/me        — Return current user profile (JWT required)
  PUT  /auth/me        — Update profile fields (JWT required)
  POST /auth/refresh   — Refresh expiring JWT token
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

import bcrypt
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings

settings = get_settings()
from app.db.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Authentication"])
bearer_scheme = HTTPBearer()

# ---------------------------------------------------------------------------
# DISCOM auto-detection map (city → DISCOM name)
# ---------------------------------------------------------------------------

CITY_DISCOM_MAP: dict[str, str] = {
    "bengaluru": "BESCOM", "bangalore": "BESCOM",
    "mumbai": "Tata Power Mumbai", "thane": "MSEDCL",
    "pune": "MSEDCL", "nagpur": "MSEDCL",
    "delhi": "BSES Rajdhani", "new delhi": "BSES Rajdhani",
    "gurgaon": "DHBVN", "gurugram": "DHBVN",
    "chennai": "TNEB", "coimbatore": "TNEB", "madurai": "TNEB",
    "hyderabad": "APEPDCL", "visakhapatnam": "APEPDCL",
    "kolkata": "CESC", "howrah": "CESC",
    "ahmedabad": "MGVCL", "surat": "DGVCL", "vadodara": "MGVCL",
    "jaipur": "JVVNL", "jodhpur": "JdVVNL",
    "lucknow": "UPPCL", "kanpur": "UPPCL", "noida": "UPPCL",
    "bhopal": "MPEZ", "indore": "MPEZ",
    "patna": "SBPDCL",
    "kochi": "KSEB", "thiruvananthapuram": "KSEB",
    "chandigarh": "DHBVN",
    "bhubaneswar": "CESU",
}


def _auto_detect_discom(city: str, state: str) -> str:
    """Return the likely DISCOM for a city, falling back to state-based lookup."""
    city_lower = city.lower().strip()
    if city_lower in CITY_DISCOM_MAP:
        return CITY_DISCOM_MAP[city_lower]

    state_lower = state.lower().strip()
    state_map = {
        "karnataka": "BESCOM", "maharashtra": "MSEDCL",
        "delhi": "BSES Rajdhani", "tamil nadu": "TNEB",
        "telangana": "APEPDCL", "andhra pradesh": "APEPDCL",
        "west bengal": "CESC", "gujarat": "MGVCL",
        "rajasthan": "JVVNL", "uttar pradesh": "UPPCL",
        "madhya pradesh": "MPEZ", "bihar": "SBPDCL",
        "kerala": "KSEB", "punjab": "PSPCL",
        "haryana": "DHBVN", "odisha": "CESU",
    }
    return state_map.get(state_lower, "GENERIC_RURAL")


# ---------------------------------------------------------------------------
# JWT helpers
# ---------------------------------------------------------------------------

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours


def _create_access_token(payload: dict[str, Any]) -> str:
    """Create a signed JWT access token with a 24-hour expiry."""
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {**payload, "exp": expire, "iat": datetime.utcnow()}
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=ALGORITHM)


def _decode_token(token: str) -> dict[str, Any]:
    """Decode and validate a JWT token, raising 401 on failure."""
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    """FastAPI dependency — validates JWT and returns the decoded payload."""
    return _decode_token(credentials.credentials)


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: str = Field(min_length=2, max_length=120)
    city: str = Field(min_length=2, max_length=80)
    state: str = Field(default="Karnataka", max_length=80)
    discom_name: str | None = Field(default=None, max_length=80)
    is_rural: bool = False
    household_size: int = Field(default=3, ge=1, le=20)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UpdateProfileRequest(BaseModel):
    full_name: str | None = None
    city: str | None = None
    state: str | None = None
    discom_name: str | None = None
    is_rural: bool | None = None
    household_size: int | None = Field(default=None, ge=1, le=20)


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict[str, Any]


class UserProfile(BaseModel):
    id: str
    email: str
    full_name: str
    city: str
    state: str
    discom_name: str
    is_rural: bool
    household_size: int
    created_at: datetime | None = None


# ---------------------------------------------------------------------------
# Route implementations
# ---------------------------------------------------------------------------


@router.post("/register", response_model=AuthResponse, status_code=status.HTTP_201_CREATED)
async def register(
    body: RegisterRequest,
    db: AsyncSession = Depends(get_db),
) -> AuthResponse:
    """
    Create a new user account.

    - Hashes password with bcrypt (rounds=12).
    - Auto-detects DISCOM from city + state if not provided.
    - Returns JWT access token and user profile.
    """
    from sqlalchemy import select, text

    # Check duplicate email (best-effort — handle DB model if present)
    try:
        from app.db.models.user import User  # type: ignore

        existing = await db.execute(
            select(User).where(User.email == str(body.email))
        )
        if existing.scalar_one_or_none() is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An account with this email already exists.",
            )

        pw_hash = bcrypt.hashpw(body.password.encode(), bcrypt.gensalt(rounds=12)).decode()
        discom = body.discom_name or _auto_detect_discom(body.city, body.state)

        user = User(
            email=str(body.email),
            hashed_password=pw_hash,
            full_name=body.full_name,
            city=body.city,
            state=body.state,
            discom_name=discom,
            is_rural=body.is_rural,
            household_size=body.household_size,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

        user_id = str(user.id)
        user_dict = {
            "id": user_id, "email": str(body.email),
            "full_name": body.full_name, "city": body.city,
            "state": body.state, "discom_name": discom,
            "is_rural": body.is_rural, "household_size": body.household_size,
        }
    except ImportError:
        # Fallback for environments where the ORM model is not yet migrated
        logger.warning("User ORM model not available — returning mock token")
        discom = body.discom_name or _auto_detect_discom(body.city, body.state)
        user_id = f"mock_{abs(hash(str(body.email))) % 100000}"
        user_dict = {
            "id": user_id, "email": str(body.email),
            "full_name": body.full_name, "city": body.city,
            "state": body.state, "discom_name": discom,
            "is_rural": body.is_rural, "household_size": body.household_size,
        }

    token = _create_access_token({
        "sub": user_id,
        "email": str(body.email),
        "discom": discom,
    })
    logger.info("New user registered: %s (DISCOM: %s)", body.email, discom)
    return AuthResponse(access_token=token, user=user_dict)


@router.post("/login", response_model=AuthResponse)
async def login(
    body: LoginRequest,
    db: AsyncSession = Depends(get_db),
) -> AuthResponse:
    """
    Authenticate a user and return a JWT token.

    - Verifies bcrypt password hash.
    - JWT payload includes: ``user_id``, ``email``, ``discom``.
    """
    try:
        from sqlalchemy import select
        from app.db.models.user import User  # type: ignore

        result = await db.execute(
            select(User).where(User.email == str(body.email))
        )
        user = result.scalar_one_or_none()

        if user is None or not bcrypt.checkpw(
            body.password.encode(), user.hashed_password.encode()
        ):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password.",
                headers={"WWW-Authenticate": "Bearer"},
            )

        user_id = str(user.id)
        discom = user.discom_name
        user_dict = {
            "id": user_id, "email": user.email,
            "full_name": user.full_name, "city": user.city,
            "state": user.state, "discom_name": discom,
            "is_rural": user.is_rural, "household_size": user.household_size,
        }
    except ImportError:
        logger.warning("User ORM model not available — returning mock login")
        user_id = f"mock_{abs(hash(str(body.email))) % 100000}"
        discom = "BESCOM"
        user_dict = {
            "id": user_id, "email": str(body.email),
            "full_name": "Demo User", "city": "Bengaluru",
            "state": "Karnataka", "discom_name": discom,
            "is_rural": False, "household_size": 3,
        }

    token = _create_access_token({"sub": user_id, "email": str(body.email), "discom": discom})
    logger.info("User logged in: %s", body.email)
    return AuthResponse(access_token=token, user=user_dict)


@router.get("/me", response_model=UserProfile)
async def get_me(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UserProfile:
    """Return the profile of the currently authenticated user."""
    try:
        from sqlalchemy import select
        from app.db.models.user import User  # type: ignore

        result = await db.execute(
            select(User).where(User.id == current_user["sub"])
        )
        user = result.scalar_one_or_none()
        if user is None:
            raise HTTPException(status_code=404, detail="User not found.")
        return UserProfile(
            id=str(user.id), email=user.email, full_name=user.full_name,
            city=user.city, state=user.state, discom_name=user.discom_name,
            is_rural=user.is_rural, household_size=user.household_size,
            created_at=getattr(user, "created_at", None),
        )
    except ImportError:
        return UserProfile(
            id=current_user.get("sub", ""), email=current_user.get("email", ""),
            full_name="Demo User", city="Bengaluru", state="Karnataka",
            discom_name=current_user.get("discom", "BESCOM"),
            is_rural=False, household_size=3,
        )


@router.put("/me", response_model=UserProfile)
async def update_me(
    body: UpdateProfileRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UserProfile:
    """Update the current user's profile fields."""
    try:
        from sqlalchemy import select
        from app.db.models.user import User  # type: ignore

        result = await db.execute(
            select(User).where(User.id == current_user["sub"])
        )
        user = result.scalar_one_or_none()
        if user is None:
            raise HTTPException(status_code=404, detail="User not found.")

        for field, value in body.model_dump(exclude_none=True).items():
            setattr(user, field, value)

        # Re-detect DISCOM if city or state changed
        if body.city or body.state:
            user.discom_name = body.discom_name or _auto_detect_discom(
                user.city, user.state
            )

        await db.commit()
        await db.refresh(user)

        return UserProfile(
            id=str(user.id), email=user.email, full_name=user.full_name,
            city=user.city, state=user.state, discom_name=user.discom_name,
            is_rural=user.is_rural, household_size=user.household_size,
        )
    except ImportError:
        raise HTTPException(status_code=503, detail="Database not available.")


@router.post("/refresh", response_model=dict)
async def refresh_token(
    current_user: dict = Depends(get_current_user),
) -> dict:
    """
    Issue a fresh JWT token for an authenticated user.

    The caller should present their current (not-yet-expired) token.
    """
    new_token = _create_access_token({
        "sub": current_user["sub"],
        "email": current_user.get("email", ""),
        "discom": current_user.get("discom", ""),
    })
    return {"access_token": new_token, "token_type": "bearer"}
