"""
Tariff lookup routes.
"""

from fastapi import APIRouter, Depends, Query

from app.api.auth import get_current_user
from app.db.models.user import User
from app.services.tariff_service import load_tariff, get_hourly_rate
from app.utils.discom_mapper import list_all_discoms, get_discom, get_tariff_zone

router = APIRouter(prefix="/tariffs", tags=["Tariffs"])


@router.get("/my-tariff")
async def get_my_tariff(user: User = Depends(get_current_user)):
    """Get the tariff structure for the authenticated user's DISCOM."""
    tariff = await load_tariff(user.discom_name or "GENERIC_RURAL")
    return tariff.model_dump()


@router.get("/hourly-rates")
async def get_hourly_rates(
    user: User = Depends(get_current_user),
    monthly_units: float = Query(200.0, description="Units consumed so far this month"),
):
    """Get 24-hour rate schedule for the user."""
    rates = []
    for h in range(24):
        rate = await get_hourly_rate(user.discom_name or "GENERIC_RURAL", h, monthly_units)
        rates.append({"hour": h, "rate_inr_per_unit": rate})
    return {"hourly_rates": rates}


@router.get("/discoms")
async def list_discoms():
    """List all supported DISCOMs."""
    return {"discoms": list_all_discoms()}


@router.get("/lookup")
async def lookup_discom(city: str = Query(...), state: str = Query(...)):
    """Look up the DISCOM and tariff zone for a city/state."""
    discom = get_discom(city, state)
    zone = get_tariff_zone(city)
    return {"discom": discom, "zone": zone, "city": city, "state": state}
