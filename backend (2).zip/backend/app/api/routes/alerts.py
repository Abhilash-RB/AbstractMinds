"""
Alerts API routes for ThunderVolts.

Routes:
  GET    /alerts              — List user alerts (filtered)
  PUT    /alerts/{id}/read    — Mark single alert as read
  PUT    /alerts/read-all     — Mark all alerts as read
  DELETE /alerts/{id}         — Dismiss an alert
  GET    /alerts/count        — Unread alert count (for UI badge)
  POST   /alerts/test         — Create a test alert (dev mode only)
"""

from __future__ import annotations

import logging
import os
import uuid
from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import get_current_user
from app.db.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/alerts", tags=["Alerts"])

ENVIRONMENT = os.getenv("ENVIRONMENT", "production")


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------


class AlertResponse(BaseModel):
    id: str
    user_id: str
    severity: Literal["low", "medium", "high"]
    title: str
    message: str
    appliance_name: str | None = None
    is_read: bool
    created_at: datetime
    anomaly_type: str | None = None


class AlertCountResponse(BaseModel):
    unread_count: int


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("", response_model=list[AlertResponse])
async def list_alerts(
    severity: str | None = Query(default=None, description="Filter: low | medium | high"),
    is_read: bool | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    cu: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[AlertResponse]:
    """
    Return a paginated, filtered list of alerts for the authenticated user.

    Query parameters:
    - ``severity``: filter by severity level (low / medium / high)
    - ``is_read``: filter by read status (true / false)
    - ``limit`` / ``offset``: pagination
    """
    user_id = cu["sub"]
    try:
        from sqlalchemy import select
        from app.db.models.alert import Alert  # type: ignore

        q = select(Alert).where(Alert.user_id == user_id)
        if severity:
            q = q.where(Alert.severity == severity)
        if is_read is not None:
            q = q.where(Alert.is_read == is_read)
        q = q.order_by(Alert.created_at.desc()).limit(limit).offset(offset)

        rows = (await db.execute(q)).scalars().all()
        return [
            AlertResponse(
                id=str(r.id), user_id=str(r.user_id),
                severity=r.severity, title=r.title, message=r.message,
                appliance_name=getattr(r, "appliance_name", None),
                is_read=r.is_read, created_at=r.created_at,
                anomaly_type=getattr(r, "anomaly_type", None),
            )
            for r in rows
        ]
    except ImportError:
        # Mock: return sample unread alerts in dev mode
        return [
            AlertResponse(
                id=str(uuid.uuid4()), user_id=user_id,
                severity="medium", title="Unusual AC Usage",
                message="Your AC ran continuously for 6 hours between 2–8 AM.",
                appliance_name="Split AC 1.5T", is_read=False,
                created_at=datetime.utcnow(), anomaly_type="Type B",
            )
        ]


@router.put("/{alert_id}/read", response_model=AlertResponse)
async def mark_read(
    alert_id: str,
    cu: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AlertResponse:
    """Mark a single alert as read."""
    user_id = cu["sub"]
    try:
        from sqlalchemy import select
        from app.db.models.alert import Alert  # type: ignore

        a = (await db.execute(
            select(Alert).where(Alert.id == alert_id, Alert.user_id == user_id)
        )).scalar_one_or_none()
        if a is None:
            raise HTTPException(404, "Alert not found.")
        a.is_read = True
        await db.commit(); await db.refresh(a)
        return AlertResponse(
            id=str(a.id), user_id=str(a.user_id), severity=a.severity,
            title=a.title, message=a.message,
            appliance_name=getattr(a, "appliance_name", None),
            is_read=a.is_read, created_at=a.created_at,
            anomaly_type=getattr(a, "anomaly_type", None),
        )
    except ImportError:
        raise HTTPException(503, "Database not available.")


@router.put("/read-all", response_model=dict)
async def mark_all_read(
    cu: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Mark all unread alerts for the authenticated user as read."""
    user_id = cu["sub"]
    try:
        from sqlalchemy import update
        from app.db.models.alert import Alert  # type: ignore

        await db.execute(
            update(Alert)
            .where(Alert.user_id == user_id, Alert.is_read.is_(False))
            .values(is_read=True)
        )
        await db.commit()
        return {"status": "ok", "message": "All alerts marked as read."}
    except ImportError:
        return {"status": "ok", "message": "All alerts marked as read."}


@router.delete("/{alert_id}", status_code=status.HTTP_204_NO_CONTENT)
async def dismiss_alert(
    alert_id: str,
    cu: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    """Permanently dismiss (delete) a specific alert."""
    user_id = cu["sub"]
    try:
        from sqlalchemy import select
        from app.db.models.alert import Alert  # type: ignore

        a = (await db.execute(
            select(Alert).where(Alert.id == alert_id, Alert.user_id == user_id)
        )).scalar_one_or_none()
        if a is None:
            raise HTTPException(404, "Alert not found.")
        await db.delete(a); await db.commit()
    except ImportError:
        pass


@router.get("/count", response_model=AlertCountResponse)
async def unread_count(
    cu: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AlertCountResponse:
    """Return the number of unread alerts for the authenticated user (UI badge)."""
    user_id = cu["sub"]
    try:
        from sqlalchemy import func, select
        from app.db.models.alert import Alert  # type: ignore

        result = await db.execute(
            select(func.count()).select_from(Alert).where(
                Alert.user_id == user_id, Alert.is_read.is_(False)
            )
        )
        count = result.scalar() or 0
        return AlertCountResponse(unread_count=int(count))
    except ImportError:
        return AlertCountResponse(unread_count=1)


@router.post("/test", response_model=AlertResponse, status_code=status.HTTP_201_CREATED)
async def create_test_alert(
    cu: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AlertResponse:
    """
    Create a synthetic test alert.

    **Dev / demo mode only** — gated by ``ENVIRONMENT=dev``.
    Returns HTTP 403 in production.
    """
    if ENVIRONMENT != "dev":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Test alerts are only available in development mode.",
        )

    user_id = cu["sub"]
    test_alert = AlertResponse(
        id=str(uuid.uuid4()),
        user_id=user_id,
        severity="high",
        title="[TEST] Water Heater Anomaly",
        message="Your water heater consumed 3× its normal usage in the last hour. "
                "Check if it was left on accidentally.",
        appliance_name="Geyser 15L",
        is_read=False,
        created_at=datetime.utcnow(),
        anomaly_type="Type C",
    )

    # Persist to DB if available
    try:
        from app.db.models.alert import Alert  # type: ignore

        a = Alert(
            user_id=user_id,
            severity=test_alert.severity,
            title=test_alert.title,
            message=test_alert.message,
            appliance_name=test_alert.appliance_name,
            is_read=False,
            anomaly_type=test_alert.anomaly_type,
        )
        db.add(a); await db.commit(); await db.refresh(a)
        test_alert.id = str(a.id)
        test_alert.created_at = a.created_at
    except ImportError:
        pass

    logger.info("Test alert created for user %s", user_id)
    return test_alert
