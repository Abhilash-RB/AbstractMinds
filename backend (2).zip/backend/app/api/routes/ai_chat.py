"""
AI Chat route — conversational endpoint with context injection,
session history in Redis, and TRUE SSE streaming via Groq.

POST /ai/chat
    - Maintains conversation history per session_id (max 20 turns, TTL 2h)
    - Injects user's energy context into every turn
    - Real token-by-token streaming via Groq stream=True
    - Falls back to Cerebras → OpenRouter → rule-based
    - Rate limited: 20 messages per user per hour
"""

import json
import logging
import time
from typing import AsyncGenerator, Optional

import redis.asyncio as aioredis
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import get_current_user
from app.config import get_settings
from app.db.database import get_db
from app.db.models.user import User
from app.db.models.appliance import Appliance

logger = logging.getLogger(__name__)
settings = get_settings()
router = APIRouter(prefix="/ai", tags=["AI Chat"])

_HISTORY_TTL = 7200       # 2 hours
_MAX_TURNS = 20
_RATE_LIMIT_MAX = 20      # messages per hour
_RATE_LIMIT_WINDOW = 3600 # 1 hour

_redis_client: Optional[aioredis.Redis] = None

# ── Provider clients (lazy init) ───────────────────────────────────────

_groq: AsyncOpenAI | None = None
_cerebras: AsyncOpenAI | None = None
_openrouter: AsyncOpenAI | None = None


def _get_groq() -> AsyncOpenAI:
    global _groq
    if _groq is None:
        _groq = AsyncOpenAI(
            base_url="https://api.groq.com/openai/v1",
            api_key=getattr(settings, "GROQ_API_KEY", "") or "noop",
        )
    return _groq


def _get_cerebras() -> AsyncOpenAI:
    global _cerebras
    if _cerebras is None:
        _cerebras = AsyncOpenAI(
            base_url="https://api.cerebras.ai/v1",
            api_key=getattr(settings, "CEREBRAS_API_KEY", "") or "noop",
        )
    return _cerebras


def _get_openrouter() -> AsyncOpenAI:
    global _openrouter
    if _openrouter is None:
        _openrouter = AsyncOpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=getattr(settings, "OPENROUTER_API_KEY", "") or "noop",
        )
    return _openrouter


async def _get_redis() -> aioredis.Redis:
    global _redis_client
    if _redis_client is None:
        _redis_client = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    return _redis_client


# ── Request / Response ──────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: str


class ChatResponse(BaseModel):
    response: str
    session_id: str


# ── Rate Limiter ────────────────────────────────────────────────────────

async def _check_rate_limit(user_id: str) -> None:
    redis = await _get_redis()
    key = f"ratelimit:chat:{user_id}"
    count = await redis.get(key)
    if count is not None and int(count) >= _RATE_LIMIT_MAX:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Rate limit exceeded. Max {_RATE_LIMIT_MAX} messages per hour.",
        )
    pipe = redis.pipeline()
    pipe.incr(key)
    pipe.expire(key, _RATE_LIMIT_WINDOW)
    await pipe.execute()


# ── Conversation History ────────────────────────────────────────────────

async def _get_history(session_id: str) -> list[dict]:
    redis = await _get_redis()
    raw = await redis.get(f"chat:history:{session_id}")
    return json.loads(raw) if raw else []


async def _save_history(session_id: str, history: list[dict]) -> None:
    trimmed = history[-(_MAX_TURNS * 2):]
    redis = await _get_redis()
    await redis.set(f"chat:history:{session_id}", json.dumps(trimmed), ex=_HISTORY_TTL)


# ── User Context ────────────────────────────────────────────────────────

async def _build_user_context(user: User, db: AsyncSession) -> dict:
    result = await db.execute(
        select(Appliance).where(Appliance.user_id == user.id)
    )
    appliances = result.scalars().all()
    return {
        "city": user.city,
        "state": getattr(user, "state", ""),
        "discom": user.discom_name or "N/A",
        "is_rural": getattr(user, "is_rural", False),
        "appliances": [a.name for a in appliances],
    }


def _build_system_prompt(ctx: dict) -> str:
    return (
        "You are ThunderVolts AI, an expert Indian home energy advisor. "
        "Answer questions about electricity usage, bills, and how to save money. "
        "Use ₹ currency. Be specific, friendly, and concise.\n\n"
        f"USER CONTEXT:\n"
        f"- City: {ctx.get('city', 'N/A')}\n"
        f"- DISCOM: {ctx.get('discom', 'N/A')}\n"
        f"- Area: {'Rural' if ctx.get('is_rural') else 'Urban'}\n"
        f"- Appliances: {', '.join(ctx.get('appliances', [])) or 'None tracked'}\n"
        f"- BESCOM peak hours: 6–10 AM and 6–10 PM\n"
        f"- Off-peak rate: ₹3.20/unit, Peak rate: ₹7.50/unit\n"
    )


# ── RULE-BASED FALLBACK ───────────────────────────────────────────────

_FALLBACK_RESPONSE = (
    "I'm temporarily running in offline mode. Based on your BESCOM tariff:\n\n"
    "• **Peak hours**: 6–10 AM and 6–10 PM (₹7.50/unit)\n"
    "• **Off-peak**: 10 PM–6 AM (₹3.20/unit)\n"
    "• **Tip**: Shifting your AC to run after 10 PM saves approximately ₹18/day\n\n"
    "Use the Scheduler page for a full AI-optimized plan."
)


# ── TRUE STREAMING ──────────────────────────────────────────────────────

async def _stream_from_provider(
    client: AsyncOpenAI,
    model: str,
    messages: list[dict],
    system_prompt: str,
) -> AsyncGenerator[str, None]:
    """
    Stream tokens from an OpenAI-compatible provider using stream=True.
    Yields individual tokens as they arrive from the API.
    """
    full_messages = [{"role": "system", "content": system_prompt}] + messages

    stream = await client.chat.completions.create(
        model=model,
        messages=full_messages,
        max_tokens=800,
        temperature=0.4,
        stream=True,
    )

    async for chunk in stream:
        if chunk.choices and chunk.choices[0].delta.content:
            yield chunk.choices[0].delta.content


async def _stream_response(
    message: str,
    history: list[dict],
    user_context: dict,
    session_id: str,
) -> AsyncGenerator[str, None]:
    """
    Stream the AI response via SSE. Tries Groq → Cerebras → OpenRouter → fallback.
    """
    system_prompt = _build_system_prompt(user_context)
    messages = [
        {"role": m.get("role", "user"), "content": m.get("content", "")}
        for m in history[-18:]
    ]
    messages.append({"role": "user", "content": message})

    # Provider fallback chain
    providers = [
        (_get_groq(),       "llama-3.3-70b-versatile",                       "groq"),
        (_get_cerebras(),   "llama-3.3-70b",                                 "cerebras"),
        (_get_openrouter(), "meta-llama/llama-3.3-70b-instruct:free",        "openrouter"),
    ]

    full_text = ""
    success = False

    for client, model, name in providers:
        try:
            t0 = time.perf_counter()
            async for token in _stream_from_provider(client, model, messages, system_prompt):
                full_text += token
                yield f"data: {json.dumps({'content': token})}\n\n"
            latency = (time.perf_counter() - t0) * 1000
            logger.info("Chat streamed via %s (%s) in %.0fms", name, model, latency)
            success = True
            break
        except Exception as exc:
            logger.warning("Chat provider %s failed: %s — trying next", name, exc)
            full_text = ""
            continue

    if not success:
        # Rule-based fallback — simulate streaming
        logger.error("All chat providers failed — using rule-based fallback")
        for char in _FALLBACK_RESPONSE:
            full_text += char
            if len(full_text) % 6 == 0:  # batch chars for efficiency
                yield f"data: {json.dumps({'content': full_text[-6:]})}\n\n"
        remainder = len(_FALLBACK_RESPONSE) % 6
        if remainder:
            yield f"data: {json.dumps({'content': full_text[-remainder:]})}\n\n"

    # Save to history
    history.append({"role": "user", "content": message})
    history.append({"role": "assistant", "content": full_text})
    await _save_history(session_id, history)

    yield f"data: [DONE]\n\n"


# ── Route ───────────────────────────────────────────────────────────────

@router.post("/chat")
async def chat_endpoint(
    body: ChatRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Conversational AI endpoint for energy-related questions.

    Streams the response as Server-Sent Events (SSE).
    Maintains conversation history in Redis per session_id.
    Rate limited to 20 messages per user per hour.
    """
    await _check_rate_limit(str(user.id))

    history = await _get_history(body.session_id)
    user_context = await _build_user_context(user, db)

    return StreamingResponse(
        _stream_response(body.message, history, user_context, body.session_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )
