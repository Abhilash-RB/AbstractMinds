"""
Claude-powered Energy Advisor Agent.

Provides natural-language explanations for bills, schedules,
anomalies, and general energy chat using the Anthropic SDK.
Includes retry logic with exponential backoff and token logging.
"""

import asyncio
import logging
import time
from typing import Any

from pydantic import BaseModel

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

_MAX_RETRIES = 3
_BASE_DELAY = 1.0


class TokenUsage(BaseModel):
    """Token usage record for a single API call."""
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""
    latency_ms: float = 0.0


class EnergyAdvisorAgent:
    """
    LLM agent that explains energy data in plain English.

    Uses Anthropic Claude via the official Python SDK.
    All methods are async with retry + exponential backoff.
    """

    DEFAULT_MODEL = "claude-sonnet-4-20250514"
    OPUS_MODEL = "claude-opus-4-20250514"

    def __init__(self) -> None:
        self._client: Any = None
        self._total_tokens_used: int = 0

    def _get_client(self) -> Any:
        """Lazy-initialise the Anthropic client."""
        if self._client is None:
            try:
                import anthropic
                self._client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
            except Exception as exc:
                logger.error("Failed to initialise Anthropic client: %s", exc)
                raise
        return self._client

    async def _call_with_retry(
        self,
        system_prompt: str,
        user_prompt: str,
        model: str | None = None,
        max_tokens: int = 1024,
    ) -> tuple[str, TokenUsage]:
        """
        Call Claude with exponential-backoff retry.

        Returns (response_text, token_usage).
        """
        model = model or self.DEFAULT_MODEL
        client = self._get_client()
        last_exc: Exception | None = None

        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                start = time.monotonic()
                response = await client.messages.create(
                    model=model,
                    max_tokens=max_tokens,
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_prompt}],
                )
                elapsed = (time.monotonic() - start) * 1000

                text = response.content[0].text if response.content else ""
                usage = TokenUsage(
                    input_tokens=response.usage.input_tokens,
                    output_tokens=response.usage.output_tokens,
                    model=model,
                    latency_ms=round(elapsed, 1),
                )
                self._total_tokens_used += usage.input_tokens + usage.output_tokens
                logger.info(
                    "Claude call: model=%s tokens_in=%d tokens_out=%d latency=%.0fms",
                    model, usage.input_tokens, usage.output_tokens, elapsed,
                )
                return text, usage

            except Exception as exc:
                last_exc = exc
                delay = _BASE_DELAY * (2 ** (attempt - 1))
                logger.warning(
                    "Claude API attempt %d/%d failed: %s — retrying in %.1fs",
                    attempt, _MAX_RETRIES, exc, delay,
                )
                await asyncio.sleep(delay)

        logger.error("All %d Claude retries exhausted.", _MAX_RETRIES)
        raise last_exc or RuntimeError("Claude API call failed")

    # ── Public Methods ──────────────────────────────────────────────────

    async def explain_bill(self, user_data: dict, bill_prediction: dict) -> str:
        """
        Generate a plain-English explanation of a predicted bill.

        Args:
            user_data: User profile (city, discom, appliances, etc.)
            bill_prediction: BillPrediction dict.

        Returns:
            Human-friendly bill explanation.
        """
        system = (
            "You are an expert Indian energy advisor. Explain electricity bills "
            "in simple, friendly Hindi-English (Hinglish) or English based on context. "
            "Use ₹ for currency. Be specific about which appliances cost most."
        )
        prompt = (
            f"User lives in {user_data.get('city', 'unknown')}, "
            f"DISCOM: {user_data.get('discom', 'unknown')}.\n\n"
            f"Predicted bill:\n"
            f"- Total units: {bill_prediction.get('predicted_units_kwh', 0)} kWh\n"
            f"- Estimated cost: ₹{bill_prediction.get('predicted_cost_inr', 0)}\n"
            f"- Confidence: ₹{bill_prediction.get('confidence_interval_low', 0)} – "
            f"₹{bill_prediction.get('confidence_interval_high', 0)}\n\n"
            f"Appliance breakdown:\n"
        )
        for appl in bill_prediction.get("breakdown_by_appliance", []):
            prompt += (
                f"  - {appl.get('name', '?')}: {appl.get('estimated_units_kwh', 0)} kWh "
                f"(₹{appl.get('estimated_cost_inr', 0)}, "
                f"{appl.get('percentage_of_total', 0)}%)\n"
            )
        prompt += "\nExplain this bill simply. Suggest 2-3 ways to save money."

        try:
            text, _ = await self._call_with_retry(system, prompt, model=self.OPUS_MODEL)
            return text
        except Exception:
            return self._fallback_bill_explanation(bill_prediction)

    async def recommend_schedule(self, day_schedule: dict, weather: dict) -> str:
        """
        Explain the optimized schedule conversationally.

        Args:
            day_schedule: DaySchedule dict.
            weather: Current WeatherData dict.

        Returns:
            Conversational schedule explanation.
        """
        system = (
            "You are a friendly home energy advisor. Explain why each "
            "appliance was scheduled at a specific time. Mention weather "
            "impact and potential savings. Keep it under 300 words."
        )
        prompt = (
            f"Today's weather: {weather.get('temp_celsius', 32)}°C, "
            f"{weather.get('condition', 'Clear')}, "
            f"humidity {weather.get('humidity_percent', 50)}%.\n\n"
            f"Optimized schedule for {day_schedule.get('date', 'today')}:\n"
        )
        for item in day_schedule.get("scheduled_appliances", []):
            prompt += (
                f"  - {item.get('appliance_name')}: "
                f"{item.get('recommended_start_hour', 0):02d}:00 – "
                f"{(item.get('recommended_end_hour', 0)+1)%24:02d}:00, "
                f"cost ₹{item.get('estimated_cost_inr', 0)}, "
                f"saves ₹{item.get('estimated_savings_vs_peak_inr', 0)}\n"
            )
        prompt += (
            f"\nTotal cost: ₹{day_schedule.get('total_estimated_cost', 0)}\n"
            f"Total savings: ₹{day_schedule.get('total_potential_savings', 0)}\n"
            f"\nExplain why each time was chosen."
        )

        try:
            text, _ = await self._call_with_retry(system, prompt)
            return text
        except Exception:
            return "Schedule optimized to run appliances during off-peak hours for maximum savings."

    async def explain_anomaly(self, anomaly: dict) -> str:
        """
        Explain a detected anomaly in user-friendly language.

        Args:
            anomaly: AnomalyAlert dict.

        Returns:
            Plain-English explanation with suggested action.
        """
        system = (
            "You are a home energy monitoring assistant. Explain anomalies "
            "simply and suggest practical fixes. Be reassuring but informative."
        )
        prompt = (
            f"Anomaly detected:\n"
            f"- Appliance: {anomaly.get('appliance_name', '?')}\n"
            f"- Type: {anomaly.get('anomaly_type', '?')}\n"
            f"- Severity: {anomaly.get('severity', '?')}\n"
            f"- Normal range: {anomaly.get('normal_range', '?')}\n"
            f"- Actual value: {anomaly.get('actual_value', '?')}\n"
            f"\nExplain what happened and what the user should do."
        )

        try:
            text, _ = await self._call_with_retry(system, prompt)
            return text
        except Exception:
            return anomaly.get("suggested_action", "Please review your appliance usage.")

    async def chat(
        self,
        user_message: str,
        conversation_history: list[dict],
        user_context: dict,
    ) -> str:
        """
        Full conversational endpoint with energy context injection.

        Args:
            user_message: The user's latest message.
            conversation_history: List of {role, content} dicts.
            user_context: Injected context (bill, appliances, city, etc.)

        Returns:
            Assistant's response.
        """
        system = (
            "You are an AI energy advisor for Indian households. You have access "
            "to the user's energy data. Answer questions about their electricity "
            "usage, bills, and how to save money. Be specific and use ₹ currency.\n\n"
            f"USER CONTEXT:\n"
            f"- City: {user_context.get('city', 'N/A')}\n"
            f"- DISCOM: {user_context.get('discom', 'N/A')}\n"
            f"- Current bill: ₹{user_context.get('current_bill', 'N/A')}\n"
            f"- Appliances: {', '.join(user_context.get('appliances', []))}\n"
            f"- Recent anomalies: {len(user_context.get('anomalies', []))}\n"
        )

        # Build messages array with history
        messages = []
        for msg in conversation_history[-18:]:  # Keep last 18 for context
            messages.append({
                "role": msg.get("role", "user"),
                "content": msg.get("content", ""),
            })
        messages.append({"role": "user", "content": user_message})

        try:
            client = self._get_client()
            start = time.monotonic()
            response = await client.messages.create(
                model=self.DEFAULT_MODEL,
                max_tokens=1024,
                system=system,
                messages=messages,
            )
            elapsed = (time.monotonic() - start) * 1000
            text = response.content[0].text if response.content else ""
            logger.info("Chat response: %.0fms, %d tokens out", elapsed, response.usage.output_tokens)
            return text
        except Exception as exc:
            logger.error("Chat failed: %s", exc)
            return "I'm having trouble connecting right now. Please try again shortly."

    @staticmethod
    def _fallback_bill_explanation(prediction: dict) -> str:
        """Rule-based bill explanation when Claude is unavailable."""
        units = prediction.get("predicted_units_kwh", 0)
        cost = prediction.get("predicted_cost_inr", 0)
        breakdown = prediction.get("breakdown_by_appliance", [])
        top = sorted(breakdown, key=lambda x: x.get("estimated_cost_inr", 0), reverse=True)

        lines = [f"Your estimated bill is ₹{cost:.0f} for {units:.0f} units this month."]
        if top:
            lines.append(f"Your biggest consumer is {top[0].get('name', '?')} "
                         f"at ₹{top[0].get('estimated_cost_inr', 0):.0f}.")
        lines.append("Tip: Shift heavy appliances to off-peak hours (10 PM–6 AM) to save up to 20%.")
        return " ".join(lines)
