"""
Context Builder — assembles structured context strings for LLM prompts.

Keeps context under ~2000 tokens by summarising when necessary.
Formats as structured markdown sections for clarity.
"""

import logging
from typing import Any

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

_MAX_CONTEXT_CHARS = 6000  # ~2000 tokens at ~3 chars/token


def _truncate(text: str, max_chars: int = _MAX_CONTEXT_CHARS) -> str:
    """Truncate text to fit within the token budget."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars - 50] + "\n\n…[context truncated for brevity]"


class ContextBuilder:
    """
    Builds structured markdown context for injection into LLM prompts.

    Each method returns a self-contained context string that can be
    prepended to a user prompt.
    """

    @staticmethod
    def build_bill_context(
        user: dict,
        appliances: list[dict],
        tariff: dict,
        weather: dict,
        prediction: dict,
    ) -> str:
        """
        Assemble context for bill explanation prompts.

        Args:
            user: User profile dict.
            appliances: List of appliance dicts.
            tariff: Tariff data dict.
            weather: Current weather dict.
            prediction: BillPrediction dict.

        Returns:
            Structured markdown context string.
        """
        lines = [
            "## User Profile",
            f"- **Name**: {user.get('full_name', 'N/A')}",
            f"- **City**: {user.get('city', 'N/A')}, {user.get('state', 'N/A')}",
            f"- **DISCOM**: {user.get('discom_name', 'N/A')}",
            f"- **Zone**: {'Rural' if user.get('is_rural') else 'Urban'}",
            "",
            "## Appliances",
        ]
        for a in appliances[:10]:  # Cap at 10
            lines.append(
                f"- {a.get('name', '?')}: {a.get('wattage_watts', 0)}W, "
                f"{a.get('avg_daily_usage_hours', 0)}h/day, "
                f"category={a.get('category', '?')}"
            )

        lines += [
            "",
            "## Current Tariff",
            f"- **DISCOM**: {tariff.get('discom', 'N/A')}",
            f"- **Zone**: {tariff.get('zone', 'N/A')}",
            f"- **Fixed charges**: ₹{tariff.get('fixed_charges_per_month', 0)}/month",
            f"- **Taxes**: {tariff.get('taxes_percentage', 0)}%",
        ]
        slabs = tariff.get("slab_data", [])
        if slabs:
            lines.append("- **Slabs**:")
            for s in slabs[:5]:
                lines.append(
                    f"  - {s.get('min_units', 0)}-{s.get('max_units', 0)} units: "
                    f"₹{s.get('rate_per_unit', 0)}/unit"
                )

        lines += [
            "",
            "## Weather",
            f"- Temperature: {weather.get('temp_celsius', 'N/A')}°C",
            f"- Humidity: {weather.get('humidity_percent', 'N/A')}%",
            f"- Condition: {weather.get('condition', 'N/A')}",
            "",
            "## Prediction",
            f"- Predicted units: {prediction.get('predicted_units_kwh', 0)} kWh",
            f"- Predicted cost: ₹{prediction.get('predicted_cost_inr', 0)}",
            f"- Confidence: ₹{prediction.get('confidence_interval_low', 0)} – "
            f"₹{prediction.get('confidence_interval_high', 0)}",
        ]

        return _truncate("\n".join(lines))

    @staticmethod
    def build_chat_context(
        user: dict,
        recent_usage_logs: list[dict],
        latest_anomalies: list[dict],
        current_schedule: dict | None = None,
    ) -> str:
        """
        Assemble context for the interactive chat endpoint.

        Args:
            user: User profile dict.
            recent_usage_logs: Last N usage log dicts.
            latest_anomalies: Recent anomaly alert dicts.
            current_schedule: Today's DaySchedule dict (optional).

        Returns:
            Structured markdown context string.
        """
        lines = [
            "## User Profile",
            f"- {user.get('full_name', 'N/A')} in {user.get('city', 'N/A')}",
            f"- DISCOM: {user.get('discom_name', 'N/A')}",
            f"- Zone: {'Rural' if user.get('is_rural') else 'Urban'}",
            "",
        ]

        # Recent usage summary
        if recent_usage_logs:
            total_kwh = sum(l.get("units_consumed_kwh", 0) for l in recent_usage_logs)
            total_cost = sum(l.get("cost_inr", 0) for l in recent_usage_logs)
            lines += [
                "## Recent Usage (last 7 days)",
                f"- Total consumption: {total_kwh:.1f} kWh",
                f"- Total cost: ₹{total_cost:.0f}",
                f"- Data points: {len(recent_usage_logs)}",
                "",
            ]

        # Anomalies
        if latest_anomalies:
            lines.append("## Recent Anomalies")
            for a in latest_anomalies[:5]:
                lines.append(
                    f"- **{a.get('anomaly_type', '?')}** on {a.get('appliance_name', '?')} "
                    f"(severity: {a.get('severity', '?')})"
                )
            lines.append("")

        # Schedule
        if current_schedule:
            lines.append("## Today's Schedule")
            for item in current_schedule.get("scheduled_appliances", [])[:5]:
                lines.append(
                    f"- {item.get('appliance_name', '?')}: "
                    f"{item.get('recommended_start_hour', 0):02d}:00–"
                    f"{(item.get('recommended_end_hour', 0)+1)%24:02d}:00"
                )
            lines.append(
                f"- Estimated total: ₹{current_schedule.get('total_estimated_cost', 0)}"
            )

        return _truncate("\n".join(lines))

    @staticmethod
    def build_schedule_context(
        appliances: list[dict],
        tariff_profile: dict,
        demand_forecast: list[dict],
        weather: dict,
    ) -> str:
        """
        Assemble context for schedule explanation prompts.

        Args:
            appliances: Appliance dicts.
            tariff_profile: 24-hour rate profile.
            demand_forecast: 24h demand forecast dicts.
            weather: Current weather dict.

        Returns:
            Structured markdown context string.
        """
        lines = [
            "## Appliances to Schedule",
        ]
        for a in appliances[:8]:
            lines.append(
                f"- {a.get('name', '?')}: {a.get('wattage_watts', 0)}W, "
                f"{a.get('duration_hours', 0)}h needed, "
                f"schedulable={a.get('is_schedulable', True)}"
            )

        # Tariff summary
        rates = tariff_profile.get("hourly_rates", [])
        if rates:
            min_rate = min(rates)
            max_rate = max(rates)
            cheapest_hours = [i for i, r in enumerate(rates) if r == min_rate]
            lines += [
                "",
                "## Tariff Summary",
                f"- Rate range: ₹{min_rate:.2f} – ₹{max_rate:.2f}/unit",
                f"- Cheapest hours: {cheapest_hours}",
            ]

        # Demand peaks
        peak_hours = [d.get("hour") for d in demand_forecast if d.get("is_likely_peak")]
        if peak_hours:
            lines += [
                "",
                "## Demand Forecast",
                f"- Peak hours today: {peak_hours}",
            ]

        lines += [
            "",
            "## Weather",
            f"- {weather.get('temp_celsius', 32)}°C, {weather.get('condition', 'Clear')}",
        ]

        return _truncate("\n".join(lines))
