"""
Redis-backed conversation memory store for ThunderVolts AI chat.

Manages per-session message history with auto-trim, TTL refresh,
and persistent user energy context.
"""

from __future__ import annotations

import json
import logging
from typing import Any

import redis.asyncio as aioredis

logger = logging.getLogger(__name__)

_SESSION_PREFIX = "tv:chat:session:"
_USER_CONTEXT_PREFIX = "tv:chat:context:"

_SESSION_TTL = 7200      # 2 hours
_CONTEXT_TTL = 86400     # 24 hours
_MAX_MESSAGES = 20
_SUMMARY_THRESHOLD = 10  # summarise older messages when history > this


class ConversationMemoryStore:
    """
    Redis-backed store for per-session conversation history and
    persistent per-user energy context.

    Parameters
    ----------
    redis_url:
        Full Redis connection URL.
    """

    def __init__(self, redis_url: str = "redis://localhost:6379/1") -> None:
        self._redis_url = redis_url
        self._client: aioredis.Redis | None = None

    async def _get_client(self) -> aioredis.Redis:
        """Return (and lazily initialise) the async Redis client."""
        if self._client is None:
            self._client = aioredis.from_url(
                self._redis_url, encoding="utf-8", decode_responses=True
            )
        return self._client

    # ── Message history ───────────────────────────────────────────────────

    async def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
    ) -> None:
        """
        Append a message to the session history.

        History is auto-trimmed to the last ``_MAX_MESSAGES`` messages,
        and the TTL is reset to 2 hours on every write.

        Parameters
        ----------
        session_id:
            Unique session identifier (e.g. ``"sess_1234"``).
        role:
            ``"user"`` or ``"assistant"``.
        content:
            Message text.
        """
        client = await self._get_client()
        key = f"{_SESSION_PREFIX}{session_id}"
        message = json.dumps({"role": role, "content": content})
        try:
            pipe = client.pipeline()
            pipe.rpush(key, message)
            pipe.ltrim(key, -_MAX_MESSAGES, -1)
            pipe.expire(key, _SESSION_TTL)
            await pipe.execute()
        except Exception as exc:
            logger.error("add_message failed for session %s: %s", session_id, exc)

    async def get_history(self, session_id: str) -> list[dict[str, str]]:
        """
        Retrieve the full message history for a session.

        Parameters
        ----------
        session_id:
            Session identifier.

        Returns
        -------
        list[dict]
            List of ``{"role": str, "content": str}`` dicts,
            ordered oldest-first.  Returns ``[]`` if expired / absent.
        """
        client = await self._get_client()
        key = f"{_SESSION_PREFIX}{session_id}"
        try:
            raw_messages = await client.lrange(key, 0, -1)
            return [json.loads(m) for m in raw_messages]
        except Exception as exc:
            logger.error("get_history failed for session %s: %s", session_id, exc)
            return []

    async def clear_session(self, session_id: str) -> None:
        """
        Delete all history for a session.

        Parameters
        ----------
        session_id:
            Session identifier.
        """
        client = await self._get_client()
        key = f"{_SESSION_PREFIX}{session_id}"
        try:
            await client.delete(key)
            logger.debug("Cleared session %s", session_id)
        except Exception as exc:
            logger.error("clear_session failed for %s: %s", session_id, exc)

    async def get_session_summary(self, session_id: str) -> str:
        """
        Return a concise extractive summary of the session history.

        If the history has more than ``_SUMMARY_THRESHOLD`` messages,
        the older portion is distilled into a single context string
        using a simple extractive strategy (no LLM call).

        Parameters
        ----------
        session_id:
            Session identifier.

        Returns
        -------
        str
            A compact context string suitable for including in a prompt.
        """
        history = await self.get_history(session_id)
        if not history:
            return ""

        if len(history) <= _SUMMARY_THRESHOLD:
            # Short enough — return as formatted string
            return "\n".join(
                f"{m['role'].upper()}: {m['content'][:120]}"
                for m in history
            )

        # Split: summarise first N-_SUMMARY_THRESHOLD messages, keep rest verbatim
        old = history[:-_SUMMARY_THRESHOLD]
        recent = history[-_SUMMARY_THRESHOLD:]

        # Extractive summary: first user message + last assistant message from old
        user_msgs = [m["content"] for m in old if m["role"] == "user"]
        asst_msgs = [m["content"] for m in old if m["role"] == "assistant"]

        summary_parts: list[str] = []
        if user_msgs:
            summary_parts.append(f"User previously asked about: {user_msgs[0][:150]}")
        if asst_msgs:
            summary_parts.append(f"AI previously noted: {asst_msgs[-1][:150]}")

        summary = "[Context from earlier in conversation] " + " | ".join(summary_parts)

        recent_str = "\n".join(
            f"{m['role'].upper()}: {m['content'][:120]}" for m in recent
        )
        return f"{summary}\n\n[Recent messages]\n{recent_str}"

    # ── User context ──────────────────────────────────────────────────────

    async def store_user_context(
        self,
        user_id: str,
        context: dict[str, Any],
    ) -> None:
        """
        Store persistent energy context for a user (TTL 24 hours).

        Typical context dict structure::

            {
                "current_bill": 1847,
                "top_appliances": ["AC", "Geyser"],
                "city": "Bengaluru",
                "discom": "BESCOM",
                "recent_anomalies": [...],
                "last_schedule": {...},
            }

        Parameters
        ----------
        user_id:
            Unique user identifier.
        context:
            Arbitrary JSON-serialisable context dictionary.
        """
        client = await self._get_client()
        key = f"{_USER_CONTEXT_PREFIX}{user_id}"
        try:
            await client.set(key, json.dumps(context), ex=_CONTEXT_TTL)
            logger.debug("Stored energy context for user %s", user_id)
        except Exception as exc:
            logger.error("store_user_context failed for %s: %s", user_id, exc)

    async def get_user_context(self, user_id: str) -> dict[str, Any] | None:
        """
        Retrieve persistent energy context for a user.

        Parameters
        ----------
        user_id:
            Unique user identifier.

        Returns
        -------
        dict | None
            Stored context, or ``None`` if expired / absent.
        """
        client = await self._get_client()
        key = f"{_USER_CONTEXT_PREFIX}{user_id}"
        try:
            raw = await client.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:
            logger.error("get_user_context failed for %s: %s", user_id, exc)
            return None

    async def close(self) -> None:
        """Close the underlying Redis connection."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None
