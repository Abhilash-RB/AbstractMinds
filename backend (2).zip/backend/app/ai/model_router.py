"""
backend/app/ai/model_router.py

100% free AI router — zero paid APIs.

Providers (priority order):
  1. Groq   — Llama 3.3 70B (primary, <200ms)
  2. Gemini — 2.5 Flash     (quality, budget-gated)
  3. Cerebras — Llama 3.3 70B (high-volume fallback)
  4. OpenRouter — Llama 3.3 70B (emergency last-resort)

All use the openai SDK (Groq/Cerebras/OpenRouter are
OpenAI-compatible). Gemini uses google-generativeai.

Rate limits enforced via Redis counters. Fallback chain
guarantees a response is always returned.
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone, timedelta
from typing import Any

from openai import AsyncOpenAI

try:
    import google.generativeai as genai
    _GEMINI_SDK = True
except ImportError:
    genai = None  # type: ignore
    _GEMINI_SDK = False

try:
    import redis.asyncio as aioredis
except ImportError:
    aioredis = None  # type: ignore

logger = logging.getLogger(__name__)

# ── Model constants ────────────────────────────────────────────────────────────
GROQ_MODEL       = "llama-3.3-70b-versatile"
GROQ_BASE_URL    = "https://api.groq.com/openai/v1"

GEMINI_MODEL     = "gemini-2.5-flash"

CEREBRAS_MODEL   = "llama-3.3-70b"
CEREBRAS_BASE_URL = "https://api.cerebras.ai/v1"

OPENROUTER_MODEL = "meta-llama/llama-3.3-70b-instruct:free"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

# ── Routing table ──────────────────────────────────────────────────────────────
_GROQ_TASKS   = {"bill_explanation", "anomaly_explanation", "rural_estimation",
                  "chat", "quick_question"}
_GEMINI_TASKS = {"schedule_advice", "weekly_planner", "data_analysis"}

# ── IST timezone ───────────────────────────────────────────────────────────────
_IST = timezone(timedelta(hours=5, minutes=30))


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Rate Limit Manager
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class RateLimitManager:
    """Track per-provider request/token counts in Redis with TTL-based expiry."""

    # Hard provider limits (with safety buffers baked in)
    LIMITS = {
        "groq":     {"rpm": 28, "tpm": 5500,  "rpd": 14000},
        "gemini":   {"rpm": 4,  "tpm": 280000, "rpd": 28},
        "cerebras": {"rpm": 28, "tpm": 55000,  "rpd": 999999},
    }

    def __init__(self, redis_client: Any | None) -> None:
        self._r = redis_client

    # ── Key helpers ────────────────────────────────────────────────────────────
    def _minute_key(self, provider: str, metric: str) -> str:
        ts = int(time.time()) // 60
        return f"rl:{provider}:{metric}:{ts}"

    def _day_key(self, provider: str) -> str:
        today = datetime.now(_IST).strftime("%Y-%m-%d")
        return f"rl:{provider}:rpd:{today}"

    # ── Check methods ──────────────────────────────────────────────────────────
    async def can_use_groq(self, estimated_tokens: int) -> bool:
        if self._r is None:
            return True
        try:
            rpm = int(await self._r.get(self._minute_key("groq", "rpm")) or 0)
            tpm = int(await self._r.get(self._minute_key("groq", "tpm")) or 0)
            rpd = int(await self._r.get(self._day_key("groq")) or 0)
            return rpm < 28 and (tpm + estimated_tokens) < 5500 and rpd < 14000
        except Exception:
            return True

    async def can_use_gemini(self, estimated_tokens: int) -> bool:
        if self._r is None:
            return True
        try:
            rpm = int(await self._r.get(self._minute_key("gemini", "rpm")) or 0)
            rpd = int(await self._r.get(self._day_key("gemini")) or 0)
            return rpm < 4 and rpd < 28
        except Exception:
            return True

    async def can_use_cerebras(self, estimated_tokens: int) -> bool:
        if self._r is None:
            return True
        try:
            rpm = int(await self._r.get(self._minute_key("cerebras", "rpm")) or 0)
            return rpm < 28
        except Exception:
            return True

    # ── Increment after success ────────────────────────────────────────────────
    async def increment(self, provider: str, tokens: int) -> None:
        if self._r is None:
            return
        try:
            pipe = self._r.pipeline()
            rpm_key = self._minute_key(provider, "rpm")
            tpm_key = self._minute_key(provider, "tpm")
            rpd_key = self._day_key(provider)
            stats_key = f"stats:requests:{provider}:{datetime.now(_IST).strftime('%Y-%m-%d')}"

            pipe.incr(rpm_key)
            pipe.expire(rpm_key, 60)
            pipe.incrby(tpm_key, tokens)
            pipe.expire(tpm_key, 60)
            pipe.incr(rpd_key)
            pipe.expire(rpd_key, 86400)
            pipe.incr(stats_key)
            pipe.expire(stats_key, 172800)  # 2 days
            await pipe.execute()
        except Exception as exc:
            logger.debug("RateLimitManager.increment failed: %s", exc)

    # ── Degraded provider tracking ─────────────────────────────────────────────
    async def mark_degraded(self, provider: str) -> None:
        if self._r is None:
            return
        try:
            await self._r.setex(f"provider_degraded:{provider}", 60, "1")
        except Exception:
            pass

    async def is_degraded(self, provider: str) -> bool:
        if self._r is None:
            return False
        try:
            return bool(await self._r.get(f"provider_degraded:{provider}"))
        except Exception:
            return False

    # ── Status report ──────────────────────────────────────────────────────────
    async def get_all_status(self) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        for p in ("groq", "gemini", "cerebras"):
            rpm = tpm = rpd = 0
            degraded = False
            if self._r:
                try:
                    rpm = int(await self._r.get(self._minute_key(p, "rpm")) or 0)
                    tpm = int(await self._r.get(self._minute_key(p, "tpm")) or 0)
                    rpd = int(await self._r.get(self._day_key(p)) or 0)
                    degraded = bool(await self._r.get(f"provider_degraded:{p}"))
                except Exception:
                    pass
            limits = self.LIMITS.get(p, {})
            result[p] = {
                "rpm_used": rpm, "rpm_limit": limits.get("rpm", 0),
                "tpm_used": tpm, "tpm_limit": limits.get("tpm", 0),
                "rpd_used": rpd, "rpd_limit": limits.get("rpd", 0),
                "rpd_remaining": max(0, limits.get("rpd", 0) - rpd),
                "degraded": degraded,
            }
        return result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Model Router
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class ModelRouter:
    """Route AI tasks to the optimal free-tier provider with rate-limit
    awareness, automatic fallback chain, and rule-based last resort."""

    def __init__(self, redis_client: Any | None = None, settings: Any | None = None) -> None:
        # Load settings
        if settings is None:
            try:
                from app.core.config import settings as _s
                settings = _s
            except ImportError:
                import os
                class _S:
                    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
                    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
                    CEREBRAS_API_KEY = os.getenv("CEREBRAS_API_KEY", "")
                    OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
                settings = _S()

        self._settings = settings

        # Provider clients
        self._groq = AsyncOpenAI(
            base_url=GROQ_BASE_URL,
            api_key=getattr(settings, "GROQ_API_KEY", "") or "noop",
        )
        self._cerebras = AsyncOpenAI(
            base_url=CEREBRAS_BASE_URL,
            api_key=getattr(settings, "CEREBRAS_API_KEY", "") or "noop",
        )
        self._openrouter = AsyncOpenAI(
            base_url=OPENROUTER_BASE_URL,
            api_key=getattr(settings, "OPENROUTER_API_KEY", "") or "noop",
        )

        # Gemini (synchronous SDK, will run in executor)
        self._gemini_model = None
        if _GEMINI_SDK and getattr(settings, "GEMINI_API_KEY", ""):
            genai.configure(api_key=settings.GEMINI_API_KEY)  # type: ignore[union-attr]
            self._gemini_model = genai.GenerativeModel(GEMINI_MODEL)  # type: ignore[union-attr]

        # Rate-limit manager
        self._rl = RateLimitManager(redis_client)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Public API
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def route(self, task_type: str, payload: dict) -> str:
        """
        Route a task to the optimal provider and return text.
        Never raises — falls back to rule-based on total failure.
        """
        prompt: str = payload.get("prompt", "")
        system: str = payload.get("system", "You are ThunderVolts AI, an Indian home energy advisor.")
        max_tokens: int = payload.get("max_tokens", 800)
        est_tokens = self.estimate_tokens(payload)

        # Build ordered fallback chain based on task type
        if task_type in _GEMINI_TASKS:
            chain = await self._build_gemini_chain(est_tokens)
        else:
            chain = await self._build_groq_chain(est_tokens)

        was_fallback = False
        fallback_reason: str | None = None

        for idx, (provider_name, call_fn) in enumerate(chain):
            if idx > 0:
                was_fallback = True
            try:
                t0 = time.perf_counter()
                result = await self._with_retry(
                    call_fn, prompt, system, max_tokens, provider_name
                )
                latency = (time.perf_counter() - t0) * 1000

                # Count tokens used (rough: prompt + response)
                response_tokens = len(result) // 4
                total_tokens = est_tokens + response_tokens
                await self._rl.increment(provider_name, total_tokens)

                logger.info(
                    "task=%s provider=%s model=%s tokens≈%d latency=%.0fms "
                    "fallback=%s fallback_reason=%s",
                    task_type, provider_name,
                    self._model_for(provider_name),
                    total_tokens, latency,
                    was_fallback, fallback_reason,
                )
                return result

            except _RateLimited as exc:
                fallback_reason = f"{provider_name} rate-limited: {exc}"
                logger.warning(fallback_reason)
                continue
            except _ProviderTimeout:
                fallback_reason = f"{provider_name} timeout (>10s)"
                logger.warning(fallback_reason)
                await self._rl.mark_degraded(provider_name)
                continue
            except Exception as exc:
                fallback_reason = f"{provider_name} error: {exc}"
                logger.warning(fallback_reason)
                continue

        # All providers exhausted
        logger.error(
            "ALL providers failed for task=%s. Returning rule-based. last_reason=%s",
            task_type, fallback_reason,
        )
        return self.rule_based_response(task_type, payload)

    async def get_model_status(self) -> dict:
        """Return live health of all providers + rate-limit counters."""
        rl_status = await self._rl.get_all_status()

        groq_ok = not await self._rl.is_degraded("groq")
        gemini_ok = self._gemini_model is not None and not await self._rl.is_degraded("gemini")
        cerebras_ok = not await self._rl.is_degraded("cerebras")
        openrouter_ok = not await self._rl.is_degraded("openrouter")

        return {
            "groq": {
                "available": groq_ok,
                "model": GROQ_MODEL,
                **rl_status.get("groq", {}),
            },
            "gemini": {
                "available": gemini_ok,
                "model": GEMINI_MODEL,
                **rl_status.get("gemini", {}),
            },
            "cerebras": {
                "available": cerebras_ok,
                "model": CEREBRAS_MODEL,
                **rl_status.get("cerebras", {}),
            },
            "openrouter": {
                "available": openrouter_ok,
                "model": OPENROUTER_MODEL,
            },
            "last_updated": datetime.now(_IST).isoformat(),
        }

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Chain builders
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def _build_groq_chain(self, est_tokens: int) -> list[tuple[str, Any]]:
        chain: list[tuple[str, Any]] = []
        if not await self._rl.is_degraded("groq") and await self._rl.can_use_groq(est_tokens):
            chain.append(("groq", self._call_groq))
        if not await self._rl.is_degraded("cerebras") and await self._rl.can_use_cerebras(est_tokens):
            chain.append(("cerebras", self._call_cerebras))
        if not await self._rl.is_degraded("openrouter"):
            chain.append(("openrouter", self._call_openrouter))
        if not chain:
            chain.append(("groq", self._call_groq))  # try anyway
        return chain

    async def _build_gemini_chain(self, est_tokens: int) -> list[tuple[str, Any]]:
        chain: list[tuple[str, Any]] = []
        if (self._gemini_model is not None
                and not await self._rl.is_degraded("gemini")
                and await self._rl.can_use_gemini(est_tokens)):
            chain.append(("gemini", self._call_gemini))
        if not await self._rl.is_degraded("cerebras") and await self._rl.can_use_cerebras(est_tokens):
            chain.append(("cerebras", self._call_cerebras))
        if not await self._rl.is_degraded("groq") and await self._rl.can_use_groq(est_tokens):
            chain.append(("groq", self._call_groq))
        if not await self._rl.is_degraded("openrouter"):
            chain.append(("openrouter", self._call_openrouter))
        if not chain:
            chain.append(("cerebras", self._call_cerebras))
        return chain

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Retry wrapper
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def _with_retry(self, fn, prompt: str, system: str,
                          max_tokens: int, provider: str) -> str:
        delays = (1, 3)
        last_exc: Exception | None = None
        for attempt in range(len(delays) + 1):
            try:
                result = await asyncio.wait_for(
                    fn(prompt, system, max_tokens),
                    timeout=10.0,
                )
                return result
            except asyncio.TimeoutError:
                raise _ProviderTimeout(provider)
            except _RateLimited:
                raise  # don't retry 429s, skip to next provider
            except Exception as exc:
                last_exc = exc
                # Check for 429 in OpenAI-style errors
                status = getattr(exc, "status_code", None) or getattr(exc, "status", 0)
                if status == 429:
                    raise _RateLimited(f"{provider}: 429")
                # Retryable server errors
                if status in (500, 502, 503) and attempt < len(delays):
                    await asyncio.sleep(delays[attempt])
                    continue
                if attempt < len(delays):
                    await asyncio.sleep(delays[attempt])
                    continue
        raise last_exc  # type: ignore[misc]

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Provider calls
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def _call_groq(self, prompt: str, system: str, max_tokens: int) -> str:
        resp = await self._groq.chat.completions.create(
            model=GROQ_MODEL,
            max_tokens=max_tokens,
            temperature=0.4,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""

    async def _call_gemini(self, prompt: str, system: str, max_tokens: int) -> str:
        if self._gemini_model is None:
            raise RuntimeError("Gemini not configured")
        full_prompt = f"System: {system}\n\nUser: {prompt}"
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: self._gemini_model.generate_content(
                full_prompt,
                generation_config={"max_output_tokens": max_tokens, "temperature": 0.4},
            ),
        )
        return response.text

    async def _call_cerebras(self, prompt: str, system: str, max_tokens: int) -> str:
        resp = await self._cerebras.chat.completions.create(
            model=CEREBRAS_MODEL,
            max_tokens=max_tokens,
            temperature=0.4,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""

    async def _call_openrouter(self, prompt: str, system: str, max_tokens: int) -> str:
        resp = await self._openrouter.chat.completions.create(
            model=OPENROUTER_MODEL,
            max_tokens=max_tokens,
            temperature=0.4,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Token estimation
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def estimate_tokens(self, payload: dict) -> int:
        """Rough token estimate: chars/4 + 200 response buffer."""
        text = payload.get("prompt", "") + payload.get("system", "")
        return (len(text) // 4) + 200

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Rule-based last resort
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def rule_based_response(self, task_type: str, payload: dict) -> str:
        """Generate a deterministic response when all providers fail."""
        # Extract context from payload for template substitution
        cost = payload.get("predicted_cost", "₹1,400")
        top_appliance = payload.get("top_appliance", "Air Conditioner")
        appliance_cost = payload.get("appliance_cost", "₹680")
        appliance = payload.get("appliance_name", "the appliance")
        actual = payload.get("actual_value", "an unusually high amount")
        normal = payload.get("normal_value", "the typical amount")
        action = payload.get("suggested_action", "Check the appliance and verify schedule settings")

        responses: dict[str, str] = {
            "bill_explanation": (
                f"Your bill is estimated at {cost}. Your biggest cost driver is "
                f"{top_appliance} at {appliance_cost}. To reduce your bill: run heavy "
                f"appliances after 10 PM, pre-cool your home before 6 PM peak, and use "
                f"the scheduler to shift loads to cheap hours."
            ),
            "anomaly_explanation": (
                f"We detected unusual activity in your {appliance}. It ran {actual} vs "
                f"the normal {normal}. Recommended action: {action}."
            ),
            "schedule_advice": (
                "Based on BESCOM peak hours (6–10 AM, 6–10 PM): run your AC after "
                "10 PM (₹3.20/unit vs ₹7.50). Run your geyser at 5 AM (cheapest "
                "window). Run your washer between 11 AM–1 PM (shoulder rate)."
            ),
            "weekly_planner": (
                "Recommended weekly schedule: Run washing machine on weekday mornings "
                "(10 AM–12 PM), AC overnight (11 PM–5 AM), geyser at 5 AM daily. "
                "Avoid heavy loads on weekday evenings (6–10 PM). "
                "Estimated savings: ₹200–400/month."
            ),
            "data_analysis": (
                "Analysis summary: your household energy consumption follows typical "
                "Indian residential patterns with peaks during 6–10 AM and 6–10 PM. "
                "Your primary cost driver is space cooling, which accounts for "
                "approximately 48% of your monthly bill."
            ),
            "quick_question": (
                "Based on your DISCOM tariff, off-peak hours (10 PM–6 AM) offer the "
                "lowest rates at ₹3.20/unit. Shifting schedulable appliances to these "
                "windows can reduce your monthly bill by 20–35%. Use the scheduler "
                "for an AI-optimized plan."
            ),
            "rural_estimation": (
                "For rural households with flat-rate pricing, your bill is estimated "
                "based on total connected load and average daily usage hours. Consider "
                "load management to stay within your sanctioned load limit."
            ),
            "chat": (
                "I'm temporarily running in offline mode. Based on your usage data: "
                "your peak hours are 6–10 AM and 6–10 PM. Shifting your AC to 11 PM "
                "saves approximately ₹18 per day. Use the scheduler for a full plan."
            ),
        }
        return responses.get(task_type, responses["chat"])

    # ── Helpers ────────────────────────────────────────────────────────────────

    @staticmethod
    def _model_for(provider: str) -> str:
        return {
            "groq": GROQ_MODEL,
            "gemini": GEMINI_MODEL,
            "cerebras": CEREBRAS_MODEL,
            "openrouter": OPENROUTER_MODEL,
        }.get(provider, "unknown")


# ── Internal exceptions ────────────────────────────────────────────────────────

class _RateLimited(Exception):
    pass

class _ProviderTimeout(Exception):
    pass


# ── Singleton accessor ─────────────────────────────────────────────────────────

_router_instance: ModelRouter | None = None


def get_model_router(redis_client: Any | None = None) -> ModelRouter:
    """Return the global ModelRouter singleton (lazy-initialised)."""
    global _router_instance
    if _router_instance is None:
        _router_instance = ModelRouter(redis_client=redis_client)
    return _router_instance
