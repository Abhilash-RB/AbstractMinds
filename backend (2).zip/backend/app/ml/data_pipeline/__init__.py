"""ML data pipeline: ingestion, preprocessing, feature store."""
