"""
Feature engineering and preprocessing for ThunderVolts ML pipeline.

Provides cleaning, feature engineering for demand / bill / LSTM,
and a reusable FeatureScaler wrapper around sklearn StandardScaler.
"""

from __future__ import annotations

import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler


# ---------------------------------------------------------------------------
# Demand data cleaning
# ---------------------------------------------------------------------------


def clean_demand_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean raw demand DataFrame.

    Steps applied:

    1. Remove outliers using IQR method; cap remaining at ±3 sigma.
    2. Forward-fill missing timestamps (max 2 consecutive gaps).
    3. Validate ``demand_mw`` within [5 000, 250 000] MW.
    4. Drop rows where ``frequency_hz`` is outside [49.0, 51.0].

    Parameters
    ----------
    df:
        Raw demand DataFrame with at least ``demand_mw`` and
        ``frequency_hz`` columns.

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame (sorted by ``timestamp`` if present).
    """
    df = df.copy()

    # Sort by timestamp if available
    if "timestamp" in df.columns:
        df = df.sort_values("timestamp").reset_index(drop=True)

    # ── demand_mw outliers ──────────────────────────────────────────────────
    q1 = df["demand_mw"].quantile(0.25)
    q3 = df["demand_mw"].quantile(0.75)
    iqr = q3 - q1
    lower_fence = max(5_000, q1 - 1.5 * iqr)
    upper_fence = min(250_000, q3 + 1.5 * iqr)

    mu = df["demand_mw"].mean()
    sigma = df["demand_mw"].std()
    cap_lo = max(5_000, mu - 3 * sigma)
    cap_hi = min(250_000, mu + 3 * sigma)

    df["demand_mw"] = df["demand_mw"].clip(cap_lo, cap_hi)
    df = df[df["demand_mw"].between(lower_fence, upper_fence)]

    # ── frequency validation ────────────────────────────────────────────────
    if "frequency_hz" in df.columns:
        df = df[df["frequency_hz"].between(49.0, 51.0)]

    # ── forward-fill missing timestamps (max gap = 2) ───────────────────────
    if "timestamp" in df.columns:
        df = df.set_index("timestamp")
        full_idx = pd.date_range(df.index.min(), df.index.max(), freq="1h")
        df = df.reindex(full_idx)
        df["demand_mw"] = df["demand_mw"].ffill(limit=2)
        df = df.dropna(subset=["demand_mw"])
        df.index.name = "timestamp"
        df = df.reset_index()

    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Demand feature engineering
# ---------------------------------------------------------------------------


def engineer_demand_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add time-series and cyclical features to a demand DataFrame.

    New columns added:

    * ``hour_sin``, ``hour_cos`` — cyclical hour encoding
    * ``day_sin``, ``day_cos`` — cyclical day-of-week encoding
    * ``month_sin``, ``month_cos`` — cyclical month encoding
    * ``lag_1h``, ``lag_24h``, ``lag_168h`` — lagged demand
    * ``rolling_mean_24h``, ``rolling_std_24h``
    * ``is_morning_peak`` — bool, True for hours 6-9
    * ``is_evening_peak`` — bool, True for hours 18-21
    * ``heat_index`` — derived from temperature + humidity

    Parameters
    ----------
    df:
        DataFrame with ``demand_mw`` and ``timestamp`` columns.

    Returns
    -------
    pd.DataFrame
        Extended DataFrame with all new feature columns.
    """
    df = df.copy().sort_values("timestamp").reset_index(drop=True)

    hour = df["timestamp"].dt.hour
    dow = df["timestamp"].dt.dayofweek
    month = df["timestamp"].dt.month

    # Cyclical encodings
    df["hour_sin"] = np.sin(2 * math.pi * hour / 24)
    df["hour_cos"] = np.cos(2 * math.pi * hour / 24)
    df["day_sin"] = np.sin(2 * math.pi * dow / 7)
    df["day_cos"] = np.cos(2 * math.pi * dow / 7)
    df["month_sin"] = np.sin(2 * math.pi * month / 12)
    df["month_cos"] = np.cos(2 * math.pi * month / 12)

    # Lag features
    df["lag_1h"] = df["demand_mw"].shift(1)
    df["lag_24h"] = df["demand_mw"].shift(24)
    df["lag_168h"] = df["demand_mw"].shift(168)

    # Rolling statistics
    df["rolling_mean_24h"] = (
        df["demand_mw"].rolling(window=24, min_periods=1).mean()
    )
    df["rolling_std_24h"] = (
        df["demand_mw"].rolling(window=24, min_periods=1).std().fillna(0)
    )

    # Peak flags
    df["is_morning_peak"] = hour.isin(range(6, 10)).astype(int)
    df["is_evening_peak"] = hour.isin(range(18, 22)).astype(int)

    # Heat index (Steadman approximation, simplified)
    if "temperature" in df.columns and "humidity" in df.columns:
        T = df["temperature"]
        RH = df["humidity"]
    elif "temperature_2m" in df.columns and "relativehumidity_2m" in df.columns:
        T = df["temperature_2m"]
        RH = df["relativehumidity_2m"]
    else:
        T = pd.Series(np.full(len(df), 28.0))
        RH = pd.Series(np.full(len(df), 60.0))

    # HI = -8.78469 + 1.61139*(T) + 2.33855*(RH) - 0.14611*(T*RH) ... (simplified)
    df["heat_index"] = (
        -8.785 + 1.611 * T + 2.339 * RH - 0.146 * T * RH
        - 0.012 * T**2 - 0.016 * RH**2
    ).clip(-20, 70)

    return df


# ---------------------------------------------------------------------------
# Bill feature engineering
# ---------------------------------------------------------------------------

# Encode city → integer index (consistent with training set)
CITY_ENCODING: dict[str, int] = {
    "bengaluru": 0, "mumbai": 1, "delhi": 2, "chennai": 3,
    "hyderabad": 4, "kolkata": 5, "pune": 6, "ahmedabad": 7,
    "jaipur": 8, "lucknow": 9, "bhopal": 10, "nagpur": 11,
    "patna": 12, "indore": 13, "surat": 14, "kochi": 15,
    "coimbatore": 16, "visakhapatnam": 17, "chandigarh": 18,
    "bhubaneswar": 19,
}

DISCOM_ENCODING: dict[str, int] = {
    "bescom": 0, "tata power mumbai": 1, "apepdcl": 2,
    "msedcl": 3, "cesc": 4, "generic_rural": 5,
    "bses rajdhani": 6, "bses yamuna": 7, "uppcl": 8,
    "tneb": 9, "jvvnl": 10, "dhbvn": 11,
}


def engineer_bill_features(user_data: dict[str, Any]) -> np.ndarray:
    """
    Transform raw user inputs into a normalised XGBoost feature vector.

    Parameters
    ----------
    user_data:
        Dictionary with keys:
        ``city``, ``month``, ``avg_daily_temp``, ``appliances``
        (list of dicts with ``wattage_watts`` and ``avg_daily_usage_hours``),
        ``household_size``, ``previous_month_units``, ``discom_name``,
        ``is_rural``.

    Returns
    -------
    np.ndarray
        1-D float64 array of shape ``(15,)``.
    """
    city = user_data.get("city", "bengaluru").lower()
    month = int(user_data.get("month", 6))
    avg_daily_temp = float(user_data.get("avg_daily_temp", 28.0))
    appliances: list[dict] = user_data.get("appliances", [])
    household_size = int(user_data.get("household_size", 3))
    previous_month_units = float(user_data.get("previous_month_units", 200.0))
    discom = user_data.get("discom_name", "bescom").lower()
    is_rural = int(bool(user_data.get("is_rural", False)))

    city_encoded = CITY_ENCODING.get(city, 0)
    discom_encoded = DISCOM_ENCODING.get(discom, 0)

    num_appliances = len(appliances)
    total_rated_watts = sum(
        float(a.get("wattage_watts", 0)) for a in appliances
    )
    avg_daily_usage_hours = (
        sum(float(a.get("avg_daily_usage_hours", 0)) for a in appliances)
        / max(num_appliances, 1)
    )

    categories = {a.get("category", "").lower() for a in appliances}
    has_ac = int("cooling" in categories)
    has_ev = int("ev" in categories or any("ev" in a.get("name", "").lower() for a in appliances))
    has_geyser = int(
        "heating" in categories
        or any("geyser" in a.get("name", "").lower() for a in appliances)
    )

    is_summer = int(month in (3, 4, 5, 6))

    # Peak-hour usage ratio: fraction of appliances that are schedulable
    schedulable = [a for a in appliances if a.get("is_schedulable", False)]
    peak_hour_usage_ratio = len(schedulable) / max(num_appliances, 1)

    # Weekend usage ratio: simple proxy — rural households use more on weekends
    weekend_usage_ratio = 0.30 if is_rural else 0.20

    features = np.array([
        city_encoded,
        month,
        avg_daily_temp,
        num_appliances,
        total_rated_watts,
        avg_daily_usage_hours,
        has_ac,
        has_ev,
        has_geyser,
        household_size,
        previous_month_units,
        discom_encoded,
        is_summer,
        peak_hour_usage_ratio,
        weekend_usage_ratio,
    ], dtype=np.float64)

    return features


# ---------------------------------------------------------------------------
# LSTM sequence builder
# ---------------------------------------------------------------------------


def create_lstm_sequences(
    df: pd.DataFrame,
    sequence_length: int = 168,
    target_horizon: int = 24,
    feature_cols: list[str] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Create sliding-window (X, y) pairs for LSTM training.

    Parameters
    ----------
    df:
        Feature-engineered demand DataFrame (sorted by time).
    sequence_length:
        Number of past hourly steps used as input (default 168 = 1 week).
    target_horizon:
        Number of future hours to predict (default 24).
    feature_cols:
        List of column names to use as features. Defaults to a
        standard set of engineered columns.

    Returns
    -------
    tuple[np.ndarray, np.ndarray]
        ``X`` of shape ``(samples, sequence_length, n_features)``
        ``y`` of shape ``(samples, target_horizon)``
    """
    if feature_cols is None:
        feature_cols = [
            "demand_mw", "hour_sin", "hour_cos", "day_sin", "day_cos",
            "month_sin", "month_cos", "lag_1h", "lag_24h", "lag_168h",
            "rolling_mean_24h", "rolling_std_24h",
            "is_morning_peak", "is_evening_peak", "heat_index",
        ]

    # Keep only columns that actually exist
    feature_cols = [c for c in feature_cols if c in df.columns]
    data = df[feature_cols].values.astype(np.float32)
    demand_idx = feature_cols.index("demand_mw") if "demand_mw" in feature_cols else 0

    X_list: list[np.ndarray] = []
    y_list: list[np.ndarray] = []

    total = len(data)
    for i in range(total - sequence_length - target_horizon + 1):
        X_list.append(data[i : i + sequence_length])
        y_list.append(
            data[i + sequence_length : i + sequence_length + target_horizon,
                 demand_idx]
        )

    X = np.array(X_list, dtype=np.float32)
    y = np.array(y_list, dtype=np.float32)
    return X, y


# ---------------------------------------------------------------------------
# FeatureScaler
# ---------------------------------------------------------------------------


class FeatureScaler:
    """
    Thin wrapper around :class:`sklearn.preprocessing.StandardScaler`
    with serialisation support.

    Usage
    -----
    ::

        scaler = FeatureScaler()
        scaler.fit(train_df)
        X_scaled = scaler.transform(train_df)
        scaler.save("/path/to/scaler.pkl")

        loaded = FeatureScaler.load("/path/to/scaler.pkl")
        X_test = loaded.transform(test_df)
    """

    def __init__(self) -> None:
        self._scaler: StandardScaler = StandardScaler()
        self._fitted: bool = False
        self._feature_cols: list[str] = []

    def fit(self, df: pd.DataFrame, feature_cols: list[str] | None = None) -> "FeatureScaler":
        """Fit the scaler on a DataFrame's numeric columns."""
        if feature_cols is None:
            feature_cols = list(df.select_dtypes(include=[np.number]).columns)
        self._feature_cols = feature_cols
        self._scaler.fit(df[feature_cols].values.astype(np.float64))
        self._fitted = True
        return self

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        """Scale the DataFrame using fitted parameters."""
        if not self._fitted:
            raise RuntimeError("FeatureScaler has not been fitted yet.")
        cols = [c for c in self._feature_cols if c in df.columns]
        return self._scaler.transform(df[cols].values.astype(np.float64))

    def inverse_transform(self, arr: np.ndarray) -> np.ndarray:
        """Invert the scaling for a numpy array."""
        if not self._fitted:
            raise RuntimeError("FeatureScaler has not been fitted yet.")
        return self._scaler.inverse_transform(arr)

    def save(self, path: str | Path) -> None:
        """Persist the scaler to disk as a pickle file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as fh:
            pickle.dump(
                {"scaler": self._scaler, "feature_cols": self._feature_cols},
                fh,
            )

    @classmethod
    def load(cls, path: str | Path) -> "FeatureScaler":
        """Load a previously saved FeatureScaler from disk."""
        with open(path, "rb") as fh:
            payload = pickle.load(fh)
        obj = cls()
        obj._scaler = payload["scaler"]
        obj._feature_cols = payload["feature_cols"]
        obj._fitted = True
        return obj
