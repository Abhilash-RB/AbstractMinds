"""
Data ingestion module for ThunderVolts ML pipeline.

Fetches grid demand data from POSOCO, state load data, weather
history from Open-Meteo, and generates realistic synthetic Indian
grid demand data when live sources are unavailable.
"""

from __future__ import annotations

import asyncio
import logging
import math
import random
from datetime import date, datetime, timedelta
from typing import Any

import aiohttp
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

POSOCO_BASE_URL = "https://posoco.in/reports/"
OPEN_METEO_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"

REGION_WEIGHTS: dict[str, float] = {
    "northern": 0.28,
    "western": 0.27,
    "southern": 0.23,
    "eastern": 0.14,
    "northeastern": 0.08,
}

STATE_TO_REGION: dict[str, str] = {
    "delhi": "northern", "haryana": "northern", "uttar pradesh": "northern",
    "punjab": "northern", "rajasthan": "northern", "himachal pradesh": "northern",
    "uttarakhand": "northern", "jammu and kashmir": "northern",
    "maharashtra": "western", "gujarat": "western", "madhya pradesh": "western",
    "goa": "western", "chhattisgarh": "western",
    "karnataka": "southern", "tamil nadu": "southern", "andhra pradesh": "southern",
    "telangana": "southern", "kerala": "southern", "puducherry": "southern",
    "west bengal": "eastern", "odisha": "eastern", "jharkhand": "eastern",
    "bihar": "eastern",
    "assam": "northeastern", "meghalaya": "northeastern", "manipur": "northeastern",
    "mizoram": "northeastern", "nagaland": "northeastern", "tripura": "northeastern",
    "arunachal pradesh": "northeastern", "sikkim": "northeastern",
}

# Major Indian holidays (month, day) — approximate fixed dates
INDIAN_HOLIDAYS: set[tuple[int, int]] = {
    (1, 26),   # Republic Day
    (3, 25),   # Holi (approximate)
    (8, 15),   # Independence Day
    (10, 2),   # Gandhi Jayanti
    (10, 24),  # Dussehra (approximate)
    (11, 12),  # Diwali (approximate)
    (12, 25),  # Christmas
}

CITY_COORDINATES: dict[str, tuple[float, float]] = {
    "bengaluru": (12.9716, 77.5946),
    "mumbai": (19.0760, 72.8777),
    "delhi": (28.7041, 77.1025),
    "chennai": (13.0827, 80.2707),
    "hyderabad": (17.3850, 78.4867),
    "kolkata": (22.5726, 88.3639),
    "pune": (18.5204, 73.8567),
    "ahmedabad": (23.0225, 72.5714),
    "jaipur": (26.9124, 75.7873),
    "lucknow": (26.8467, 80.9462),
    "bhopal": (23.2599, 77.4126),
    "nagpur": (21.1458, 79.0882),
    "patna": (25.5941, 85.1376),
    "indore": (22.7196, 75.8577),
    "surat": (21.1702, 72.8311),
    "kochi": (9.9312, 76.2673),
    "coimbatore": (11.0168, 76.9558),
    "visakhapatnam": (17.6868, 83.2185),
    "chandigarh": (30.7333, 76.7794),
    "bhubaneswar": (20.2961, 85.8245),
}


# ---------------------------------------------------------------------------
# Public async functions
# ---------------------------------------------------------------------------


async def fetch_posoco_demand_data(fetch_date: str) -> pd.DataFrame:
    """
    Fetch national / regional grid demand data from POSOCO reports.

    Parameters
    ----------
    fetch_date:
        ISO date string ``"YYYY-MM-DD"``.

    Returns
    -------
    pd.DataFrame
        Columns: ``timestamp, region, demand_mw, frequency_hz``.
        Falls back to synthetic data on any network or parse error.
    """
    dt = datetime.strptime(fetch_date, "%Y-%m-%d")
    # POSOCO serves day-ahead reports; we try a known CSV path pattern
    url = (
        f"{POSOCO_BASE_URL}day-ahead-demand-forecast-report/"
        f"{dt.year}/{dt.month:02d}/{dt.day:02d}/demand_report.csv"
    )
    try:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=15)
        ) as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    text = await resp.text()
                    df = _parse_posoco_csv(text, dt)
                    logger.info("Fetched POSOCO demand data for %s", fetch_date)
                    return df
    except Exception as exc:
        logger.warning("POSOCO fetch failed (%s) – using synthetic data", exc)

    return _synthetic_day_demand(dt)


async def fetch_state_load_data(state: str, fetch_date: str) -> pd.DataFrame:
    """
    Return hourly load data for a specific Indian state.

    Parameters
    ----------
    state:
        State name (case-insensitive).
    fetch_date:
        ISO date string ``"YYYY-MM-DD"``.

    Returns
    -------
    pd.DataFrame
        Columns: ``timestamp, state, demand_mw, frequency_hz``.
        Falls back to regional data scaled by the state's weight.
    """
    state_lower = state.lower()
    region = STATE_TO_REGION.get(state_lower, "western")
    weight = REGION_WEIGHTS.get(region, 0.2)

    regional_df = await fetch_posoco_demand_data(fetch_date)
    # Narrow to the relevant region, then scale by state weight
    region_df = regional_df[regional_df["region"] == region].copy()
    if region_df.empty:
        region_df = regional_df.copy()
    region_df["demand_mw"] = region_df["demand_mw"] * weight * 0.4  # sub-state share
    region_df["state"] = state.title()
    region_df = region_df.rename(columns={"region": "_region"}).drop(
        columns=["_region"], errors="ignore"
    )
    return region_df[["timestamp", "state", "demand_mw", "frequency_hz"]]


def generate_synthetic_demand_data(days: int = 365) -> pd.DataFrame:
    """
    Generate realistic synthetic Indian grid demand data.

    The synthetic series captures:

    * Daily dual-peak curve (6-10 AM and 6-10 PM)
    * Seasonal variation (summer peaks 15% higher than winter)
    * Weekly pattern (weekends ~10% lower)
    * Random Gaussian noise (±3%)
    * Holiday demand dips (~8% drop)

    Parameters
    ----------
    days:
        Number of days of hourly data to generate.

    Returns
    -------
    pd.DataFrame
        Columns: ``timestamp, demand_mw, temperature, humidity,
        is_peak, is_holiday, day_of_week, month, hour``.
    """
    rng = random.Random(42)
    np_rng = np.random.default_rng(42)

    start = datetime(2024, 1, 1, 0, 0, 0)
    records: list[dict[str, Any]] = []

    base_demand = 180_000  # MW — approximate Indian grid peak

    for day_idx in range(days):
        current_date = start + timedelta(days=day_idx)
        month = current_date.month
        dow = current_date.weekday()  # 0=Mon, 6=Sun
        is_hol = (month, current_date.day) in INDIAN_HOLIDAYS

        # Seasonal multiplier
        if month in (4, 5, 6):       # summer
            season_mult = 1.15
            base_temp = rng.uniform(32, 42)
            base_humid = rng.uniform(30, 60)
        elif month in (7, 8, 9):     # monsoon
            season_mult = 1.05
            base_temp = rng.uniform(28, 36)
            base_humid = rng.uniform(65, 90)
        elif month in (10, 11, 12):  # post-monsoon / early winter
            season_mult = 1.00
            base_temp = rng.uniform(20, 30)
            base_humid = rng.uniform(40, 70)
        else:                        # winter
            season_mult = 0.92
            base_temp = rng.uniform(8, 22)
            base_humid = rng.uniform(35, 65)

        weekend_mult = 0.90 if dow >= 5 else 1.0
        holiday_mult = 0.92 if is_hol else 1.0

        for hour in range(24):
            ts = current_date + timedelta(hours=hour)
            hourly_factor = _hourly_demand_factor(hour)
            noise = np_rng.normal(1.0, 0.03)

            demand_mw = (
                base_demand * hourly_factor * season_mult
                * weekend_mult * holiday_mult * noise
            )
            demand_mw = max(80_000, min(240_000, demand_mw))

            temp = base_temp + _hour_temp_delta(hour)
            humid = base_humid + rng.uniform(-5, 5)
            is_peak = hour in range(6, 10) or hour in range(18, 22)

            records.append({
                "timestamp": ts,
                "demand_mw": round(demand_mw, 1),
                "temperature": round(temp, 1),
                "humidity": round(max(10, min(99, humid)), 1),
                "is_peak": is_peak,
                "is_holiday": is_hol,
                "day_of_week": dow,
                "month": month,
                "hour": hour,
            })

    df = pd.DataFrame(records)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df


async def fetch_weather_history(city: str, days: int = 90) -> pd.DataFrame:
    """
    Fetch hourly temperature and humidity for the past N days
    using the Open-Meteo free archive API (no key required).

    Parameters
    ----------
    city:
        City name (case-insensitive). Falls back to Bengaluru coordinates.
    days:
        Number of historic days to fetch.

    Returns
    -------
    pd.DataFrame
        Columns: ``timestamp, temperature_2m, relativehumidity_2m, city``.
    """
    city_lower = city.lower()
    lat, lon = CITY_COORDINATES.get(city_lower, (12.9716, 77.5946))

    end_date = date.today() - timedelta(days=1)
    start_date = end_date - timedelta(days=days - 1)

    params = {
        "latitude": lat,
        "longitude": lon,
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "hourly": "temperature_2m,relativehumidity_2m",
        "timezone": "Asia/Kolkata",
    }

    try:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30)
        ) as session:
            async with session.get(OPEN_METEO_ARCHIVE_URL, params=params) as resp:
                if resp.status == 200:
                    payload = await resp.json()
                    hourly = payload.get("hourly", {})
                    df = pd.DataFrame({
                        "timestamp": pd.to_datetime(hourly["time"]),
                        "temperature_2m": hourly["temperature_2m"],
                        "relativehumidity_2m": hourly["relativehumidity_2m"],
                    })
                    df["city"] = city.title()
                    logger.info(
                        "Fetched %d weather rows for %s", len(df), city
                    )
                    return df
    except Exception as exc:
        logger.warning("Open-Meteo fetch failed (%s) – generating synthetic", exc)

    return _synthetic_weather(city, days)


async def load_all_training_data() -> dict[str, pd.DataFrame]:
    """
    Load and merge all training data sources.

    Returns
    -------
    dict
        Keys: ``"demand"`` (synthetic yearly demand),
        ``"weather"`` (Open-Meteo 90-day history for Bengaluru),
        ``"merged"`` (demand joined with weather on hour-level timestamp).
    """
    demand_df = generate_synthetic_demand_data(days=365)
    weather_df = await fetch_weather_history("bengaluru", days=365)

    # Align on truncated hour
    demand_df["_merge_key"] = demand_df["timestamp"].dt.floor("h")
    weather_df["_merge_key"] = weather_df["timestamp"].dt.floor("h")

    merged = demand_df.merge(
        weather_df[["_merge_key", "temperature_2m", "relativehumidity_2m"]],
        on="_merge_key",
        how="left",
    ).drop(columns=["_merge_key"])

    # Fill any missing weather with demand-internal temperature column
    merged["temperature_2m"] = merged["temperature_2m"].fillna(merged["temperature"])
    merged["relativehumidity_2m"] = merged["relativehumidity_2m"].fillna(
        merged["humidity"]
    )

    return {"demand": demand_df, "weather": weather_df, "merged": merged}


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _hourly_demand_factor(hour: int) -> float:
    """Return a demand multiplier (0.55–1.0) for a given hour (0-23)."""
    # Dual-peak curve: morning 6-10 AM and evening 6-10 PM
    curve = {
        0: 0.58, 1: 0.55, 2: 0.54, 3: 0.53, 4: 0.55, 5: 0.61,
        6: 0.72, 7: 0.85, 8: 0.95, 9: 1.00, 10: 0.96, 11: 0.91,
        12: 0.88, 13: 0.87, 14: 0.86, 15: 0.87, 16: 0.89, 17: 0.93,
        18: 0.98, 19: 1.00, 20: 0.99, 21: 0.95, 22: 0.83, 23: 0.68,
    }
    return curve.get(hour, 0.80)


def _hour_temp_delta(hour: int) -> float:
    """Diurnal temperature swing: coldest at 4-5 AM, hottest 2-3 PM."""
    rad = (hour - 4) / 24 * 2 * math.pi
    return 5.0 * math.sin(max(0.0, math.sin(rad)))


def _parse_posoco_csv(text: str, dt: datetime) -> pd.DataFrame:
    """Parse a POSOCO CSV response into a normalised DataFrame."""
    from io import StringIO

    try:
        raw = pd.read_csv(StringIO(text))
        raw.columns = [c.strip().lower().replace(" ", "_") for c in raw.columns]
        # Attempt to map common POSOCO column names
        col_map = {}
        for c in raw.columns:
            if "demand" in c and "mw" in c:
                col_map[c] = "demand_mw"
            elif "freq" in c:
                col_map[c] = "frequency_hz"
            elif "region" in c:
                col_map[c] = "region"
            elif "time" in c or "hour" in c:
                col_map[c] = "_hour"
        raw = raw.rename(columns=col_map)
        rows = []
        for region, weight in REGION_WEIGHTS.items():
            sub = raw.copy()
            sub["region"] = region
            if "demand_mw" not in sub.columns:
                sub["demand_mw"] = weight * 180_000
            if "frequency_hz" not in sub.columns:
                sub["frequency_hz"] = 50.0
            if "_hour" in sub.columns:
                sub["timestamp"] = sub["_hour"].apply(
                    lambda h: dt.replace(hour=int(h) % 24)
                )
            else:
                sub["timestamp"] = [
                    dt.replace(hour=i % 24) for i in range(len(sub))
                ]
            rows.append(sub[["timestamp", "region", "demand_mw", "frequency_hz"]])
        return pd.concat(rows, ignore_index=True)
    except Exception:
        return _synthetic_day_demand(dt)


def _synthetic_day_demand(dt: datetime) -> pd.DataFrame:
    """Generate one day of synthetic hourly demand for all regions."""
    rng = np.random.default_rng(int(dt.timestamp()))
    rows = []
    for region, weight in REGION_WEIGHTS.items():
        for hour in range(24):
            ts = dt.replace(hour=hour, minute=0, second=0, microsecond=0)
            factor = _hourly_demand_factor(hour)
            demand = 180_000 * weight * factor * rng.normal(1.0, 0.02)
            rows.append({
                "timestamp": ts,
                "region": region,
                "demand_mw": round(demand, 1),
                "frequency_hz": round(rng.normal(50.0, 0.05), 3),
            })
    return pd.DataFrame(rows)


def _synthetic_weather(city: str, days: int) -> pd.DataFrame:
    """Generate synthetic hourly weather for a city."""
    rng = np.random.default_rng(abs(hash(city)) % 2**32)
    start = datetime.now().replace(
        hour=0, minute=0, second=0, microsecond=0
    ) - timedelta(days=days)
    rows = []
    base_temp = 28.0
    base_humid = 60.0
    for d in range(days):
        for h in range(24):
            ts = start + timedelta(days=d, hours=h)
            rows.append({
                "timestamp": ts,
                "temperature_2m": round(
                    base_temp + _hour_temp_delta(h) + rng.normal(0, 1.5), 1
                ),
                "relativehumidity_2m": round(
                    max(10, min(99, base_humid + rng.normal(0, 5))), 1
                ),
                "city": city.title(),
            })
    return pd.DataFrame(rows)
