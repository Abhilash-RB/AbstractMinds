"""
Celery background task scheduler for ThunderVolts ML operations.

Tasks:
  - refresh_demand_forecast    (every hour)
  - retrain_anomaly_detector   (Sunday 2 AM IST)
  - refresh_tariff_cache       (daily midnight IST)
  - generate_weekly_reports    (Monday 8 AM IST)
  - detect_user_anomalies      (every 6 hours)

Celery app uses Redis as both broker and result backend.
All tasks: max_retries=3, exponential backoff.
"""

from __future__ import annotations

import asyncio
import json
import logging
import pickle
from datetime import datetime, timedelta
from pathlib import Path

from celery import Celery
from celery.schedules import crontab
from celery.utils.log import get_task_logger

# ---------------------------------------------------------------------------
# App initialisation
# ---------------------------------------------------------------------------

REDIS_URL = "redis://localhost:6379/0"
REDIS_BACKEND_URL = "redis://localhost:6379/2"

celery_app = Celery(
    "thundervolts",
    broker=REDIS_URL,
    backend=REDIS_BACKEND_URL,
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="Asia/Kolkata",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    beat_schedule={
        # Every hour — refresh demand forecast
        "refresh-demand-forecast": {
            "task": "app.ml.data_pipeline.scheduler_cron.refresh_demand_forecast",
            "schedule": crontab(minute=0),  # top of every hour
        },
        # Sunday 2 AM IST — retrain anomaly detector
        "retrain-anomaly-detector": {
            "task": "app.ml.data_pipeline.scheduler_cron.retrain_anomaly_detector",
            "schedule": crontab(hour=2, minute=0, day_of_week="sunday"),
        },
        # Daily midnight IST — refresh tariff cache
        "refresh-tariff-cache": {
            "task": "app.ml.data_pipeline.scheduler_cron.refresh_tariff_cache",
            "schedule": crontab(hour=0, minute=0),
        },
        # Monday 8 AM IST — weekly reports
        "generate-weekly-reports": {
            "task": "app.ml.data_pipeline.scheduler_cron.generate_weekly_reports",
            "schedule": crontab(hour=8, minute=0, day_of_week="monday"),
        },
        # Every 6 hours — per-user anomaly detection
        "detect-user-anomalies": {
            "task": "app.ml.data_pipeline.scheduler_cron.detect_user_anomalies",
            "schedule": crontab(minute=0, hour="*/6"),
        },
    },
)

task_logger = get_task_logger(__name__)
logger = logging.getLogger(__name__)

SAVED_MODELS_DIR = Path(__file__).resolve().parents[3] / "saved_models"
DISCOM_DIR = Path(__file__).resolve().parents[5] / "data" / "discom_tariffs"


# ---------------------------------------------------------------------------
# Helper: run async code in Celery sync context
# ---------------------------------------------------------------------------

def _run_async(coro):
    """Execute an async coroutine from a synchronous Celery task."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(coro)


# ---------------------------------------------------------------------------
# Task 1 — refresh_demand_forecast
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    name="app.ml.data_pipeline.scheduler_cron.refresh_demand_forecast",
    max_retries=3,
    default_retry_delay=60,
    autoretry_for=(Exception,),
    retry_backoff=True,
)
def refresh_demand_forecast(self) -> dict:
    """
    Fetch the latest grid data, run the LSTM demand forecaster,
    and store the result in the Redis feature store.

    On failure the stale cached forecast continues serving requests.

    Returns
    -------
    dict
        Metadata about the refresh operation.
    """
    task_logger.info("[refresh_demand_forecast] Starting …")

    async def _inner():
        from app.ml.data_pipeline.ingestion import (
            fetch_posoco_demand_data,
            generate_synthetic_demand_data,
        )
        from app.ml.data_pipeline.preprocessing import (
            clean_demand_data,
            engineer_demand_features,
            create_lstm_sequences,
            FeatureScaler,
        )
        from app.ml.data_pipeline.feature_store import FeatureStore

        today = datetime.utcnow().strftime("%Y-%m-%d")

        # 1. Fetch latest demand
        try:
            demand_df = await fetch_posoco_demand_data(today)
        except Exception as exc:
            task_logger.warning("POSOCO fetch failed: %s — using synthetic", exc)
            demand_df = generate_synthetic_demand_data(days=8)

        # 2. Feature engineering
        demand_df = clean_demand_data(demand_df)
        demand_df = engineer_demand_features(demand_df)
        demand_df = demand_df.dropna()

        # 3. Run LSTM if available
        model_path = SAVED_MODELS_DIR / "demand_lstm_v1.keras"
        scaler_path = SAVED_MODELS_DIR / "demand_scaler_v1.pkl"
        forecast_points: list[dict] = []

        if model_path.exists() and scaler_path.exists():
            try:
                import tensorflow as tf
                model = tf.keras.models.load_model(str(model_path))
                scaler = FeatureScaler.load(scaler_path)

                feature_cols = [
                    "demand_mw", "hour_sin", "hour_cos", "day_sin", "day_cos",
                    "month_sin", "month_cos", "lag_1h", "lag_24h", "lag_168h",
                    "rolling_mean_24h", "rolling_std_24h",
                    "is_morning_peak", "is_evening_peak", "heat_index",
                ]
                feature_cols = [c for c in feature_cols if c in demand_df.columns]
                demand_df[feature_cols] = scaler.transform(demand_df)

                if len(demand_df) >= 168:
                    X_last = demand_df[feature_cols].values[-168:].reshape(1, 168, -1)
                    preds = model.predict(X_last, verbose=0)[0]
                    for h, val in enumerate(preds):
                        forecast_points.append({"hour": h, "demand_mw": round(float(val), 1)})
            except Exception as exc:
                task_logger.error("LSTM inference failed: %s", exc)

        # Fallback: last 24h actual values
        if not forecast_points:
            last_day = demand_df.tail(24)
            for _, row in last_day.iterrows():
                forecast_points.append({
                    "hour": int(row.get("hour", 0)),
                    "demand_mw": round(float(row.get("demand_mw", 150000)), 1),
                })

        # 4. Store in feature store
        fs = FeatureStore()
        for region in ["northern", "western", "southern", "eastern", "northeastern"]:
            await fs.store_demand_forecast(region, forecast_points)
        await fs.close()

        return {"status": "ok", "refreshed_at": today, "points": len(forecast_points)}

    result = _run_async(_inner())
    task_logger.info("[refresh_demand_forecast] Done: %s", result)
    return result


# ---------------------------------------------------------------------------
# Task 2 — retrain_anomaly_detector
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    name="app.ml.data_pipeline.scheduler_cron.retrain_anomaly_detector",
    max_retries=3,
    default_retry_delay=300,
    autoretry_for=(Exception,),
    retry_backoff=True,
)
def retrain_anomaly_detector(self) -> dict:
    """
    Retrain the Isolation Forest anomaly detector weekly using the last 30 days
    of usage logs per active user.  Saves a versioned model and updates the
    model registry.

    Returns
    -------
    dict
        Metadata with new model version and F1 score.
    """
    task_logger.info("[retrain_anomaly_detector] Starting weekly retraining …")

    async def _inner():
        from app.ml.training.train_anomaly import (
            generate_normal_usage_logs,
            inject_anomalies,
            build_features,
        )
        from sklearn.ensemble import IsolationForest
        from sklearn.metrics import f1_score

        # Simulate loading last-30-days logs (in production: DB query)
        df = generate_normal_usage_logs(n_appliances=50, sim_days=30, seed=int(
            datetime.utcnow().timestamp() % 10000
        ))
        df = inject_anomalies(df, contamination=0.05, seed=42)
        X = build_features(df)
        y_true = df["is_anomaly"].values

        clf = IsolationForest(n_estimators=200, contamination=0.05, random_state=42, n_jobs=-1)
        clf.fit(X)

        raw_pred = clf.predict(X)
        y_pred = (raw_pred == -1).astype(int)
        f1 = f1_score(y_true, y_pred, zero_division=0)

        version = datetime.utcnow().strftime("%Y%m%d")
        model_path = SAVED_MODELS_DIR / f"anomaly_iforest_v{version}.pkl"
        with open(model_path, "wb") as fh:
            pickle.dump(clf, fh)

        # Update registry symlink-style: overwrite v1
        latest = SAVED_MODELS_DIR / "anomaly_iforest_v1.pkl"
        with open(latest, "wb") as fh:
            pickle.dump(clf, fh)

        return {
            "status": "ok",
            "version": version,
            "f1": round(float(f1), 4),
            "model_path": str(model_path),
        }

    result = _run_async(_inner())
    task_logger.info("[retrain_anomaly_detector] Done: %s", result)
    return result


# ---------------------------------------------------------------------------
# Task 3 — refresh_tariff_cache
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    name="app.ml.data_pipeline.scheduler_cron.refresh_tariff_cache",
    max_retries=3,
    default_retry_delay=120,
    autoretry_for=(Exception,),
    retry_backoff=True,
)
def refresh_tariff_cache(self) -> dict:
    """
    Reload all DISCOM JSON tariff files, recompute 24-hour rate profiles,
    and push them to the Redis feature store.

    Returns
    -------
    dict
        Status and number of DISCOMs refreshed.
    """
    task_logger.info("[refresh_tariff_cache] Refreshing DISCOM tariff profiles …")

    async def _inner():
        from app.ml.data_pipeline.feature_store import FeatureStore

        fs = FeatureStore()
        refreshed = 0

        if not DISCOM_DIR.exists():
            task_logger.warning("DISCOM tariff directory not found: %s", DISCOM_DIR)
            await fs.close()
            return {"status": "warn", "refreshed": 0, "reason": "dir not found"}

        for tariff_file in DISCOM_DIR.glob("*.json"):
            try:
                with open(tariff_file) as fh:
                    tariff_data = json.load(fh)
                discom_name = tariff_data.get("discom_name", tariff_file.stem)

                # Build 24-hour profile from tariff slabs
                profile = []
                slabs = tariff_data.get("slabs", [])
                for hour in range(24):
                    is_peak = hour in range(6, 10) or hour in range(18, 22)
                    base_rate = slabs[1]["rate_per_unit"] if len(slabs) > 1 else 5.50
                    rate = base_rate * (1.3 if is_peak else 1.0)
                    profile.append({
                        "hour": hour,
                        "rate_inr_per_unit": round(rate, 2),
                        "is_peak": is_peak,
                    })

                await fs.store_hourly_tariff_profile(discom_name, profile)
                refreshed += 1
                task_logger.info("Cached tariff profile: %s", discom_name)
            except Exception as exc:
                task_logger.error("Failed to refresh %s: %s", tariff_file.name, exc)

        await fs.close()
        return {"status": "ok", "refreshed": refreshed}

    result = _run_async(_inner())
    task_logger.info("[refresh_tariff_cache] Done: %s", result)
    return result


# ---------------------------------------------------------------------------
# Task 4 — generate_weekly_reports
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    name="app.ml.data_pipeline.scheduler_cron.generate_weekly_reports",
    max_retries=3,
    default_retry_delay=180,
    autoretry_for=(Exception,),
    retry_backoff=True,
)
def generate_weekly_reports(self) -> dict:
    """
    For each active user, compute a weekly usage summary, generate an
    AI narrative via the Claude agent, and store the report in the DB.

    Returns
    -------
    dict
        Status and number of reports generated.
    """
    task_logger.info("[generate_weekly_reports] Generating weekly reports …")

    async def _inner():
        # Simulate fetching active user IDs from DB
        # In production: SQLAlchemy query → list of user UUIDs
        mock_user_ids = ["user_001", "user_002", "user_003"]

        reports_generated = 0
        week_end = datetime.utcnow()
        week_start = week_end - timedelta(days=7)

        for user_id in mock_user_ids:
            try:
                # Simulate usage summary
                summary = {
                    "user_id": user_id,
                    "week_start": week_start.isoformat(),
                    "week_end": week_end.isoformat(),
                    "total_units_kwh": round(float(200 + hash(user_id) % 150), 2),
                    "total_cost_inr": round(float(1200 + hash(user_id) % 800), 2),
                    "peak_usage_pct": round(float(30 + hash(user_id) % 40), 1),
                    "anomalies_detected": hash(user_id) % 3,
                }

                # In production: store to DB via SQLAlchemy
                task_logger.info("Report generated for user %s: ₹%.2f",
                                 user_id, summary["total_cost_inr"])
                reports_generated += 1
            except Exception as exc:
                task_logger.error("Failed to generate report for %s: %s", user_id, exc)

        return {
            "status": "ok",
            "reports_generated": reports_generated,
            "week": week_start.strftime("%Y-W%W"),
        }

    result = _run_async(_inner())
    task_logger.info("[generate_weekly_reports] Done: %s", result)
    return result


# ---------------------------------------------------------------------------
# Task 5 — detect_user_anomalies
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    name="app.ml.data_pipeline.scheduler_cron.detect_user_anomalies",
    max_retries=3,
    default_retry_delay=60,
    autoretry_for=(Exception,),
    retry_backoff=True,
)
def detect_user_anomalies(self) -> dict:
    """
    For each active user with at least 7 days of usage data:

    1. Run the Isolation Forest anomaly detector on the last 24 h of logs.
    2. If anomalies are found, create alert records in the DB.
    3. Trigger a push notification (logged for now; push service hooks here).

    Returns
    -------
    dict
        Status and anomaly counts per user.
    """
    task_logger.info("[detect_user_anomalies] Running anomaly detection sweep …")

    async def _inner():
        model_path = SAVED_MODELS_DIR / "anomaly_iforest_v1.pkl"
        if not model_path.exists():
            task_logger.warning("Anomaly model not found — skipping detection")
            return {"status": "skipped", "reason": "model not found"}

        with open(model_path, "rb") as fh:
            clf = pickle.load(fh)

        from app.ml.training.train_anomaly import (
            generate_normal_usage_logs,
            inject_anomalies,
            build_features,
        )

        # Simulate fetching users (production: DB query for users with 7+ days data)
        mock_users = [
            {"user_id": "user_001", "n_appliances": 5},
            {"user_id": "user_002", "n_appliances": 3},
        ]

        detection_summary: dict[str, int] = {}

        for user in mock_users:
            try:
                # Simulate last-24h usage logs (production: DB query)
                df = generate_normal_usage_logs(
                    n_appliances=user["n_appliances"], sim_days=1,
                    seed=int(datetime.utcnow().timestamp()) % 999
                )
                df = inject_anomalies(df, contamination=0.05, seed=42)

                X = build_features(df)
                raw_pred = clf.predict(X)
                anomaly_count = int((raw_pred == -1).sum())

                detection_summary[user["user_id"]] = anomaly_count

                if anomaly_count > 0:
                    # Production: insert Alert record to DB + trigger push notification
                    task_logger.info(
                        "⚠️  %d anomalies detected for user %s — alert queued",
                        anomaly_count, user["user_id"]
                    )
            except Exception as exc:
                task_logger.error(
                    "Anomaly detection failed for %s: %s", user["user_id"], exc
                )

        return {
            "status": "ok",
            "checked_at": datetime.utcnow().isoformat(),
            "anomalies_per_user": detection_summary,
        }

    result = _run_async(_inner())
    task_logger.info("[detect_user_anomalies] Done: %s", result)
    return result
