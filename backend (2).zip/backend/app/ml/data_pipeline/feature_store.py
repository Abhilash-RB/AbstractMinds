"""
Redis-backed feature store for ThunderVolts ML pipeline.

Provides async caching for user feature vectors, DISCOM tariff
profiles, and 24-hour demand forecasts.
"""

from __future__ import annotations

import json
import logging
from typing import Any

import redis.asyncio as aioredis

logger = logging.getLogger(__name__)

# Key prefix constants
_USER_FEATURES_PREFIX = "tv:features:user:"
_TARIFF_PREFIX = "tv:features:tariff:"
_FORECAST_PREFIX = "tv:features:forecast:"

_DEFAULT_TTL_USER = 3600       # 1 hour
_DEFAULT_TTL_TARIFF = 86400    # 24 hours
_DEFAULT_TTL_FORECAST = 3600   # 1 hour


class FeatureStore:
    """
    Redis-backed feature cache for the ThunderVolts ML pipeline.

    All methods are ``async`` and communicate with Redis via
    ``redis.asyncio``.  Serialisation uses JSON for portability.

    Parameters
    ----------
    redis_url:
        Full Redis connection URL, e.g.
        ``"redis://localhost:6379/1"``.
    """

    def __init__(self, redis_url: str = "redis://localhost:6379/1") -> None:
        self._redis_url = redis_url
        self._client: aioredis.Redis | None = None

    async def _get_client(self) -> aioredis.Redis:
        """Return (and lazily create) the async Redis client."""
        if self._client is None:
            self._client = aioredis.from_url(
                self._redis_url, encoding="utf-8", decode_responses=True
            )
        return self._client

    # ── User features ────────────────────────────────────────────────────────

    async def store_user_features(
        self,
        user_id: str,
        features: dict[str, Any],
        ttl: int = _DEFAULT_TTL_USER,
    ) -> None:
        """
        Store computed feature dict for a user in Redis.

        Parameters
        ----------
        user_id:
            Unique user identifier.
        features:
            Dictionary of feature name → value.
        ttl:
            Time-to-live in seconds (default 3600).
        """
        client = await self._get_client()
        key = f"{_USER_FEATURES_PREFIX}{user_id}"
        try:
            await client.set(key, json.dumps(features), ex=ttl)
            logger.debug("Stored features for user %s (ttl=%ds)", user_id, ttl)
        except Exception as exc:
            logger.error("FeatureStore.store_user_features failed: %s", exc)

    async def get_user_features(self, user_id: str) -> dict[str, Any] | None:
        """
        Retrieve cached feature dict for a user.

        Returns
        -------
        dict | None
            The stored feature dictionary, or ``None`` if expired / absent.
        """
        client = await self._get_client()
        key = f"{_USER_FEATURES_PREFIX}{user_id}"
        try:
            raw = await client.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:
            logger.error("FeatureStore.get_user_features failed: %s", exc)
            return None

    # ── Tariff profiles ──────────────────────────────────────────────────────

    async def store_hourly_tariff_profile(
        self,
        discom: str,
        profile: list[dict[str, Any]],
    ) -> None:
        """
        Cache a 24-hour tariff profile for a DISCOM (TTL 24 hours).

        Parameters
        ----------
        discom:
            DISCOM identifier string (case-insensitive).
        profile:
            List of 24 dicts, each with at least
            ``{"hour": int, "rate_inr_per_unit": float}``.
        """
        client = await self._get_client()
        key = f"{_TARIFF_PREFIX}{discom.lower()}"
        try:
            await client.set(key, json.dumps(profile), ex=_DEFAULT_TTL_TARIFF)
            logger.debug("Cached tariff profile for DISCOM %s", discom)
        except Exception as exc:
            logger.error("FeatureStore.store_hourly_tariff_profile failed: %s", exc)

    async def get_hourly_tariff_profile(
        self, discom: str
    ) -> list[dict[str, Any]] | None:
        """
        Retrieve cached 24-hour tariff profile for a DISCOM.

        Returns
        -------
        list[dict] | None
        """
        client = await self._get_client()
        key = f"{_TARIFF_PREFIX}{discom.lower()}"
        try:
            raw = await client.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:
            logger.error("FeatureStore.get_hourly_tariff_profile failed: %s", exc)
            return None

    # ── Demand forecasts ─────────────────────────────────────────────────────

    async def store_demand_forecast(
        self,
        region: str,
        forecast: list[dict[str, Any]],
    ) -> None:
        """
        Cache a 24-hour demand forecast for a grid region (TTL 1 hour).

        Parameters
        ----------
        region:
            Grid region identifier (e.g. ``"southern"``).
        forecast:
            List of 24 dicts with ``{"hour": int, "demand_mw": float}``.
        """
        client = await self._get_client()
        key = f"{_FORECAST_PREFIX}{region.lower()}"
        try:
            await client.set(key, json.dumps(forecast), ex=_DEFAULT_TTL_FORECAST)
            logger.debug("Cached demand forecast for region %s", region)
        except Exception as exc:
            logger.error("FeatureStore.store_demand_forecast failed: %s", exc)

    async def get_demand_forecast(
        self, region: str
    ) -> list[dict[str, Any]] | None:
        """
        Retrieve cached 24-hour demand forecast for a grid region.

        Returns
        -------
        list[dict] | None
        """
        client = await self._get_client()
        key = f"{_FORECAST_PREFIX}{region.lower()}"
        try:
            raw = await client.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:
            logger.error("FeatureStore.get_demand_forecast failed: %s", exc)
            return None

    # ── Cache management ─────────────────────────────────────────────────────

    async def invalidate_user_cache(self, user_id: str) -> None:
        """
        Delete all cached feature entries for a user.

        Parameters
        ----------
        user_id:
            Unique user identifier.
        """
        client = await self._get_client()
        key = f"{_USER_FEATURES_PREFIX}{user_id}"
        try:
            await client.delete(key)
            logger.debug("Invalidated feature cache for user %s", user_id)
        except Exception as exc:
            logger.error("FeatureStore.invalidate_user_cache failed: %s", exc)

    async def close(self) -> None:
        """Close the underlying Redis connection."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None
