"""
XGBoost bill predictor training script.

Run directly:
    python -m app.ml.training.train_bill
"""

from __future__ import annotations

import json
import logging
import math
import random
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

SAVED_MODELS_DIR = Path(__file__).resolve().parents[2] / "saved_models"
SAVED_MODELS_DIR.mkdir(parents=True, exist_ok=True)
PLOTS_DIR = SAVED_MODELS_DIR / "plots"
PLOTS_DIR.mkdir(parents=True, exist_ok=True)

MODEL_VERSION = "1"
N_SAMPLES = 50_000
CV_FOLDS = 5

# ── City definitions ──────────────────────────────────────────────────────
CITY_CONFIG: dict[str, dict] = {
    "bengaluru": {"state": "karnataka", "discom": "bescom", "avg_temp_summer": 33, "avg_temp_winter": 18},
    "mumbai": {"state": "maharashtra", "discom": "tata power mumbai", "avg_temp_summer": 35, "avg_temp_winter": 24},
    "delhi": {"state": "delhi", "discom": "bses rajdhani", "avg_temp_summer": 43, "avg_temp_winter": 8},
    "chennai": {"state": "tamil nadu", "discom": "tneb", "avg_temp_summer": 40, "avg_temp_winter": 28},
    "hyderabad": {"state": "telangana", "discom": "apepdcl", "avg_temp_summer": 40, "avg_temp_winter": 18},
    "kolkata": {"state": "west bengal", "discom": "cesc", "avg_temp_summer": 38, "avg_temp_winter": 14},
    "pune": {"state": "maharashtra", "discom": "msedcl", "avg_temp_summer": 36, "avg_temp_winter": 16},
    "ahmedabad": {"state": "gujarat", "discom": "msedcl", "avg_temp_summer": 44, "avg_temp_winter": 14},
    "jaipur": {"state": "rajasthan", "discom": "jvvnl", "avg_temp_summer": 44, "avg_temp_winter": 10},
    "lucknow": {"state": "uttar pradesh", "discom": "uppcl", "avg_temp_summer": 42, "avg_temp_winter": 8},
    "bhopal": {"state": "madhya pradesh", "discom": "msedcl", "avg_temp_summer": 40, "avg_temp_winter": 12},
    "nagpur": {"state": "maharashtra", "discom": "msedcl", "avg_temp_summer": 44, "avg_temp_winter": 14},
    "patna": {"state": "bihar", "discom": "uppcl", "avg_temp_summer": 42, "avg_temp_winter": 8},
    "indore": {"state": "madhya pradesh", "discom": "msedcl", "avg_temp_summer": 40, "avg_temp_winter": 13},
    "surat": {"state": "gujarat", "discom": "msedcl", "avg_temp_summer": 38, "avg_temp_winter": 20},
    "kochi": {"state": "kerala", "discom": "kseb", "avg_temp_summer": 34, "avg_temp_winter": 28},
    "coimbatore": {"state": "tamil nadu", "discom": "tneb", "avg_temp_summer": 36, "avg_temp_winter": 24},
    "visakhapatnam": {"state": "andhra pradesh", "discom": "apepdcl", "avg_temp_summer": 38, "avg_temp_winter": 24},
    "chandigarh": {"state": "punjab", "discom": "dhbvn", "avg_temp_summer": 42, "avg_temp_winter": 6},
    "bhubaneswar": {"state": "odisha", "discom": "cesc", "avg_temp_summer": 40, "avg_temp_winter": 16},
}

CITY_LIST = list(CITY_CONFIG.keys())

APPLIANCE_POOL = [
    {"name": "Split AC 1.5T", "wattage_watts": 1500, "category": "cooling", "is_schedulable": True},
    {"name": "Ceiling Fan", "wattage_watts": 75, "category": "other", "is_schedulable": True},
    {"name": "Refrigerator", "wattage_watts": 150, "category": "other", "is_schedulable": False},
    {"name": "Geyser 15L", "wattage_watts": 2000, "category": "heating", "is_schedulable": True},
    {"name": "Washing Machine", "wattage_watts": 500, "category": "washing", "is_schedulable": True},
    {"name": "LED TV 43\"", "wattage_watts": 120, "category": "entertainment", "is_schedulable": True},
    {"name": "Microwave", "wattage_watts": 800, "category": "cooking", "is_schedulable": True},
    {"name": "Induction Cooktop", "wattage_watts": 1500, "category": "cooking", "is_schedulable": True},
    {"name": "LED Lighting", "wattage_watts": 80, "category": "lighting", "is_schedulable": True},
    {"name": "Laptop", "wattage_watts": 65, "category": "other", "is_schedulable": True},
    {"name": "EV Charger", "wattage_watts": 3300, "category": "ev", "is_schedulable": True},
    {"name": "Air Purifier", "wattage_watts": 50, "category": "other", "is_schedulable": True},
    {"name": "Water Pump 1HP", "wattage_watts": 746, "category": "other", "is_schedulable": True},
    {"name": "Dishwasher", "wattage_watts": 900, "category": "washing", "is_schedulable": True},
    {"name": "Iron", "wattage_watts": 1000, "category": "other", "is_schedulable": True},
]


def _compute_bill_label(
    appliances: list[dict],
    month: int,
    city: str,
    household_size: int,
    previous_month_units: float,
    is_rural: bool,
) -> tuple[float, float]:
    """
    Deterministic bill calculation as ground-truth label.

    Returns
    -------
    tuple[float, float]
        (predicted_units_kwh, predicted_cost_inr)
    """
    is_summer = month in (3, 4, 5, 6)
    seasonal_mult = 1.15 if is_summer else 1.0

    total_kwh = 0.0
    for appl in appliances:
        watts = appl["wattage_watts"]
        hours = appl["avg_daily_usage_hours"] * seasonal_mult
        total_kwh += (watts * hours * 30) / 1000.0

    # Smooth with previous month (regression to mean)
    blended_units = 0.7 * total_kwh + 0.3 * previous_month_units

    # Tariff — simplified BESCOM-like slab structure
    city_cfg = CITY_CONFIG.get(city, CITY_CONFIG["bengaluru"])
    rural_discount = 0.85 if is_rural else 1.0

    slabs = [(100, 3.50), (100, 5.50), (100, 7.25), (float("inf"), 8.50)]
    units_left = blended_units
    cost = 0.0
    for slab_units, rate in slabs:
        used = min(units_left, slab_units)
        cost += used * rate * rural_discount
        units_left -= used
        if units_left <= 0:
            break

    # Fixed charges + taxes
    fixed = 80 + (household_size * 10)
    tax = cost * 0.06
    total_cost = cost + fixed + tax

    return round(blended_units, 2), round(total_cost, 2)


def generate_synthetic_bill_dataset(n: int = N_SAMPLES, seed: int = 42) -> pd.DataFrame:
    """
    Generate a synthetic dataset of Indian household bill records.

    Parameters
    ----------
    n:
        Number of samples.
    seed:
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame
        DataFrame with feature columns and target columns
        ``units_kwh`` and ``bill_inr``.
    """
    rng = random.Random(seed)
    records = []

    for _ in range(n):
        city = rng.choice(CITY_LIST)
        month = rng.randint(1, 12)
        household_size = rng.randint(1, 6)
        is_rural = rng.random() < 0.25
        prev_units = rng.uniform(50, 800)
        city_cfg = CITY_CONFIG[city]

        is_summer = month in (3, 4, 5, 6)
        is_winter = month in (12, 1, 2)
        avg_temp = (
            city_cfg["avg_temp_summer"] if is_summer
            else city_cfg["avg_temp_winter"] if is_winter
            else (city_cfg["avg_temp_summer"] + city_cfg["avg_temp_winter"]) / 2
        )

        # Randomly select 2-7 appliances
        n_appliances = rng.randint(2, 7)
        selected = rng.sample(APPLIANCE_POOL, k=min(n_appliances, len(APPLIANCE_POOL)))
        appliances = []
        for a in selected:
            daily_hours = rng.uniform(0.5, 10.0)
            if a["category"] == "cooling":
                daily_hours = rng.uniform(4, 12) if is_summer else rng.uniform(0, 2)
            elif a["category"] == "heating":
                daily_hours = rng.uniform(0, 1) if is_summer else rng.uniform(1, 3)
            elif a["category"] == "ev":
                daily_hours = rng.uniform(4, 8)
            appliances.append({**a, "avg_daily_usage_hours": round(daily_hours, 1)})

        units, cost = _compute_bill_label(
            appliances, month, city, household_size, prev_units, is_rural
        )

        from app.ml.data_pipeline.preprocessing import engineer_bill_features
        feat_vec = engineer_bill_features({
            "city": city,
            "month": month,
            "avg_daily_temp": avg_temp,
            "appliances": appliances,
            "household_size": household_size,
            "previous_month_units": prev_units,
            "discom_name": city_cfg["discom"],
            "is_rural": is_rural,
        })

        rec = {
            f"f{i:02d}": val
            for i, val in enumerate(feat_vec)
        }
        rec["units_kwh"] = units
        rec["bill_inr"] = cost
        records.append(rec)

    return pd.DataFrame(records)


def train() -> dict:
    """
    Full XGBoost bill predictor training pipeline.

    Returns
    -------
    dict
        Training metadata.
    """
    try:
        import xgboost as xgb
    except ImportError:
        raise RuntimeError("xgboost is required: pip install xgboost")

    from sklearn.model_selection import KFold, cross_val_score
    import pickle

    logger.info("═══ ThunderVolts XGBoost Bill Training — v%s ═══", MODEL_VERSION)

    # ── 1. Generate dataset ────────────────────────────────────────────────
    logger.info("Generating %d synthetic training samples …", N_SAMPLES)
    df = generate_synthetic_bill_dataset(N_SAMPLES)

    feature_cols = [c for c in df.columns if c.startswith("f")]
    X = df[feature_cols].values
    y = df["bill_inr"].values

    logger.info("Dataset shape: X=%s, y=%s", X.shape, y.shape)

    # ── 2. XGBoost model ──────────────────────────────────────────────────
    model = xgb.XGBRegressor(
        n_estimators=500,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        early_stopping_rounds=20,
        eval_metric="mae",
        random_state=42,
        n_jobs=-1,
    )

    # Holdout 10% for evaluation
    split = int(0.9 * len(X))
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    model.fit(
        X_train, y_train,
        eval_set=[(X_test, y_test)],
        verbose=50,
    )

    # ── 3. Cross-validation ────────────────────────────────────────────────
    logger.info("5-fold cross-validation …")
    cv_model = xgb.XGBRegressor(
        n_estimators=200, max_depth=6, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1
    )
    kf = KFold(n_splits=CV_FOLDS, shuffle=False)
    cv_scores = cross_val_score(cv_model, X_train, y_train, cv=kf, scoring="neg_mean_absolute_error")
    cv_mae = -cv_scores.mean()
    logger.info("CV MAE: ₹%.2f ± %.2f", cv_mae, cv_scores.std())

    # ── 4. Evaluate on hold-out ────────────────────────────────────────────
    y_pred = model.predict(X_test)
    mae = float(np.mean(np.abs(y_pred - y_test)))
    rmse = float(math.sqrt(np.mean((y_pred - y_test) ** 2)))
    within_10pct = float(np.mean(np.abs(y_pred - y_test) / y_test < 0.10) * 100)
    logger.info("Test MAE=₹%.2f | RMSE=₹%.2f | Within 10%%: %.1f%%",
                mae, rmse, within_10pct)

    # ── 5. Feature importance plot ─────────────────────────────────────────
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        feat_names = [
            "city", "month", "avg_temp", "n_appliances", "total_watts",
            "avg_hours", "has_ac", "has_ev", "has_geyser", "household",
            "prev_units", "discom", "is_summer", "peak_ratio", "weekend_ratio",
        ]
        importances = model.feature_importances_
        idx = np.argsort(importances)[::-1]

        plt.figure(figsize=(10, 6))
        plt.bar(range(len(importances)), importances[idx], color="#F5C842")
        plt.xticks(range(len(importances)), [feat_names[i] for i in idx], rotation=45, ha="right")
        plt.title("XGBoost Feature Importance — Bill Predictor")
        plt.tight_layout()
        plot_path = PLOTS_DIR / f"bill_feature_importance_v{MODEL_VERSION}.png"
        plt.savefig(plot_path, dpi=120)
        plt.close()
        logger.info("Feature importance plot → %s", plot_path)
    except Exception as exc:
        logger.warning("Could not save feature importance plot: %s", exc)

    # ── 6. Save model ──────────────────────────────────────────────────────
    model_path = SAVED_MODELS_DIR / f"bill_xgb_v{MODEL_VERSION}.pkl"
    with open(model_path, "wb") as fh:
        pickle.dump(model, fh)
    logger.info("Model saved → %s", model_path)

    # ── 7. Metadata ────────────────────────────────────────────────────────
    meta = {
        "model_version": MODEL_VERSION,
        "trained_at": datetime.utcnow().isoformat() + "Z",
        "test_mae_inr": round(mae, 2),
        "test_rmse_inr": round(rmse, 2),
        "within_10pct": round(within_10pct, 1),
        "cv_mae_inr": round(float(cv_mae), 2),
        "training_samples": int(len(X_train)),
        "features_used": feat_names,
        "n_estimators_best": int(model.best_iteration + 1),
    }
    meta_path = SAVED_MODELS_DIR / f"bill_xgb_v{MODEL_VERSION}_meta.json"
    meta_path.write_text(json.dumps(meta, indent=2))
    logger.info("Metadata → %s", meta_path)
    logger.info("═══ XGBoost training complete ═══")
    return meta


if __name__ == "__main__":
    result = train()
    print("\n=== Bill Predictor Training Summary ===")
    for k, v in result.items():
        print(f"  {k}: {v}")
