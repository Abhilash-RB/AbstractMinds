"""
Model evaluation script — runs health checks across all three ThunderVolts ML models.

Run directly:
    python -m app.ml.training.evaluate_models
"""

from __future__ import annotations

import json
import logging
import math
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

SAVED_MODELS_DIR = Path(__file__).resolve().parents[2] / "saved_models"
PLOTS_DIR = SAVED_MODELS_DIR / "plots"
PLOTS_DIR.mkdir(parents=True, exist_ok=True)

# ── Pass/Fail thresholds ──────────────────────────────────────────────────
DEMAND_MAE_THRESHOLD = 2000.0    # MW
BILL_MAE_THRESHOLD = 50.0        # INR
ANOMALY_F1_THRESHOLD = 0.75


# ---------------------------------------------------------------------------
# Demand forecaster evaluation
# ---------------------------------------------------------------------------

def evaluate_demand_model() -> dict:
    """
    Load the LSTM demand forecaster and evaluate on 30 days of synthetic data.

    Returns
    -------
    dict
        Keys: ``mae, rmse, mape, peak_accuracy, pass``.
    """
    from app.ml.data_pipeline.ingestion import generate_synthetic_demand_data
    from app.ml.data_pipeline.preprocessing import (
        clean_demand_data, engineer_demand_features,
        create_lstm_sequences, FeatureScaler,
    )

    logger.info("── Evaluating Demand Forecaster ──")

    model_path = SAVED_MODELS_DIR / "demand_lstm_v1.keras"
    scaler_path = SAVED_MODELS_DIR / "demand_scaler_v1.pkl"

    if not model_path.exists():
        logger.warning("Demand model not found at %s — using dummy metrics", model_path)
        return {"mae": 9999.0, "rmse": 9999.0, "mape": 99.9,
                "peak_accuracy": 0.0, "pass": False}

    try:
        import tensorflow as tf
        model = tf.keras.models.load_model(str(model_path))
    except Exception as exc:
        logger.error("Failed to load demand model: %s", exc)
        return {"mae": 9999.0, "rmse": 9999.0, "mape": 99.9,
                "peak_accuracy": 0.0, "pass": False}

    scaler = FeatureScaler.load(scaler_path) if scaler_path.exists() else None

    # Generate 30-day test window
    df = generate_synthetic_demand_data(days=37)  # +7 for lag features
    df = clean_demand_data(df)
    df = engineer_demand_features(df)
    df = df.dropna().tail(30 * 24 + 168).reset_index(drop=True)

    feature_cols = [
        "demand_mw", "hour_sin", "hour_cos", "day_sin", "day_cos",
        "month_sin", "month_cos", "lag_1h", "lag_24h", "lag_168h",
        "rolling_mean_24h", "rolling_std_24h",
        "is_morning_peak", "is_evening_peak", "heat_index",
    ]
    feature_cols = [c for c in feature_cols if c in df.columns]

    if scaler is not None:
        df[feature_cols] = scaler.transform(df)

    X, y_true = create_lstm_sequences(df, 168, 24, feature_cols)
    if len(X) == 0:
        return {"mae": 9999.0, "rmse": 9999.0, "mape": 99.9,
                "peak_accuracy": 0.0, "pass": False}

    y_pred = model.predict(X, verbose=0)
    mae = float(np.mean(np.abs(y_pred - y_true)))
    rmse = float(math.sqrt(np.mean((y_pred - y_true) ** 2)))
    mape = float(np.mean(np.abs((y_pred - y_true) / (y_true + 1e-8))) * 100)

    # Per-hour-of-day MAE
    hours = np.arange(24)
    hourly_mae = {}
    for h in hours:
        mask = (np.arange(y_true.shape[1]) == h)
        hourly_mae[int(h)] = round(float(np.mean(np.abs(y_pred[:, h] - y_true[:, h]))), 2)

    # Peak classification (hours 6-9 and 18-21)
    peak_hours = list(range(6, 10)) + list(range(18, 22))
    y_true_peak = (y_true[:, peak_hours] > y_true[:, :].mean(axis=1, keepdims=True)).astype(int)
    y_pred_peak = (y_pred[:, peak_hours] > y_pred[:, :].mean(axis=1, keepdims=True)).astype(int)
    peak_accuracy = float(np.mean(y_true_peak == y_pred_peak))

    result = {
        "mae": round(mae, 2),
        "rmse": round(rmse, 2),
        "mape": round(mape, 2),
        "peak_accuracy": round(peak_accuracy, 4),
        "hourly_mae": hourly_mae,
        "pass": mae < DEMAND_MAE_THRESHOLD,
    }
    logger.info(
        "Demand — MAE: %.2f MW | RMSE: %.2f MW | MAPE: %.2f%% | Peak Acc: %.2f%%",
        mae, rmse, mape, peak_accuracy * 100
    )
    return result


# ---------------------------------------------------------------------------
# Bill predictor evaluation
# ---------------------------------------------------------------------------

def evaluate_bill_model() -> dict:
    """
    Load the XGBoost bill predictor and evaluate on 1 000 holdout samples.

    Returns
    -------
    dict
        Keys: ``mae_inr, rmse_inr, r2, within_10pct, pass``.
    """
    from sklearn.metrics import r2_score
    from app.ml.training.train_bill import generate_synthetic_bill_dataset

    logger.info("── Evaluating Bill Predictor ──")

    model_path = SAVED_MODELS_DIR / "bill_xgb_v1.pkl"
    if not model_path.exists():
        logger.warning("Bill model not found at %s — using dummy metrics", model_path)
        return {"mae_inr": 9999.0, "rmse_inr": 9999.0, "r2": 0.0,
                "within_10pct": 0.0, "pass": False}

    with open(model_path, "rb") as fh:
        model = pickle.load(fh)

    # Generate 1 000 fresh holdout samples (different seed)
    df = generate_synthetic_bill_dataset(n=1000, seed=999)
    feature_cols = [c for c in df.columns if c.startswith("f")]
    X = df[feature_cols].values
    y_true = df["bill_inr"].values
    y_pred = model.predict(X)

    mae = float(np.mean(np.abs(y_pred - y_true)))
    rmse = float(math.sqrt(np.mean((y_pred - y_true) ** 2)))
    r2 = float(r2_score(y_true, y_pred))
    within_10 = float(np.mean(np.abs(y_pred - y_true) / y_true < 0.10) * 100)

    # Save scatter plot
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plt.figure(figsize=(8, 8))
        plt.scatter(y_true, y_pred, alpha=0.4, color="#F5C842", s=15)
        min_val, max_val = y_true.min(), y_true.max()
        plt.plot([min_val, max_val], [min_val, max_val], "w--", lw=1.5)
        plt.xlabel("Actual Bill (₹)")
        plt.ylabel("Predicted Bill (₹)")
        plt.title(f"Bill Predictor — Predicted vs Actual (n=1000, MAE=₹{mae:.0f})")
        plt.tight_layout()
        scatter_path = PLOTS_DIR / "bill_predicted_vs_actual.png"
        plt.savefig(scatter_path, dpi=120)
        plt.close()
        logger.info("Scatter plot → %s", scatter_path)
    except Exception as exc:
        logger.warning("Could not save scatter plot: %s", exc)

    result = {
        "mae_inr": round(mae, 2),
        "rmse_inr": round(rmse, 2),
        "r2": round(r2, 4),
        "within_10pct": round(within_10, 1),
        "pass": mae < BILL_MAE_THRESHOLD,
    }
    logger.info(
        "Bill — MAE: ₹%.2f | RMSE: ₹%.2f | R²: %.4f | Within 10%%: %.1f%%",
        mae, rmse, r2, within_10
    )
    return result


# ---------------------------------------------------------------------------
# Anomaly detector evaluation
# ---------------------------------------------------------------------------

def evaluate_anomaly_model() -> dict:
    """
    Load the Isolation Forest and evaluate on a fresh test set with injected anomalies.

    Returns
    -------
    dict
        Keys: ``precision, recall, f1, auc_roc, pass``.
    """
    from sklearn.metrics import (
        f1_score, precision_score, recall_score, roc_auc_score
    )
    from app.ml.training.train_anomaly import (
        generate_normal_usage_logs, inject_anomalies, build_features
    )

    logger.info("── Evaluating Anomaly Detector ──")

    model_path = SAVED_MODELS_DIR / "anomaly_iforest_v1.pkl"
    if not model_path.exists():
        logger.warning("Anomaly model not found at %s — using dummy metrics", model_path)
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0,
                "auc_roc": 0.0, "pass": False}

    with open(model_path, "rb") as fh:
        clf = pickle.load(fh)

    # Fresh test set (seed 777 — unseen during training)
    df = generate_normal_usage_logs(n_appliances=20, sim_days=30, seed=777)
    df = inject_anomalies(df, contamination=0.05, seed=888)

    X = build_features(df)
    y_true = df["is_anomaly"].values

    raw_pred = clf.predict(X)
    y_pred = (raw_pred == -1).astype(int)
    scores = -clf.score_samples(X)  # higher = more anomalous

    precision = float(precision_score(y_true, y_pred, zero_division=0))
    recall = float(recall_score(y_true, y_pred, zero_division=0))
    f1 = float(f1_score(y_true, y_pred, zero_division=0))
    try:
        auc = float(roc_auc_score(y_true, scores))
    except Exception:
        auc = 0.0

    result = {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "auc_roc": round(auc, 4),
        "pass": f1 >= ANOMALY_F1_THRESHOLD,
    }
    logger.info(
        "Anomaly — Precision: %.4f | Recall: %.4f | F1: %.4f | AUC-ROC: %.4f",
        precision, recall, f1, auc
    )
    return result


# ---------------------------------------------------------------------------
# Combined health report
# ---------------------------------------------------------------------------

def run_health_report() -> dict:
    """
    Run evaluation for all three models and print a combined PASS/FAIL report.

    Returns
    -------
    dict
        Full evaluation results for all models.
    """
    print("\n" + "═" * 60)
    print("  ThunderVolts — Model Health Report")
    print("═" * 60)

    demand = evaluate_demand_model()
    bill = evaluate_bill_model()
    anomaly = evaluate_anomaly_model()

    print("\n┌─────────────────────────────────────────────┐")
    print("│             MODEL HEALTH SUMMARY            │")
    print("├─────────────────────┬───────────┬───────────┤")
    print("│ Model               │ Metric    │ Status    │")
    print("├─────────────────────┼───────────┼───────────┤")
    demand_status = "✅ PASS" if demand["pass"] else "❌ FAIL"
    bill_status = "✅ PASS" if bill["pass"] else "❌ FAIL"
    anomaly_status = "✅ PASS" if anomaly["pass"] else "❌ FAIL"
    print(f"│ Demand Forecaster   │ MAE={demand['mae']:7.1f}MW │ {demand_status}   │")
    print(f"│ Bill Predictor      │ MAE=₹{bill['mae_inr']:6.2f}   │ {bill_status}   │")
    print(f"│ Anomaly Detector    │ F1={anomaly['f1']:7.4f}   │ {anomaly_status}   │")
    print("└─────────────────────┴───────────┴───────────┘")

    overall = demand["pass"] and bill["pass"] and anomaly["pass"]
    print(f"\nOverall System Status: {'✅ ALL MODELS HEALTHY' if overall else '⚠️ ATTENTION REQUIRED'}")
    print("═" * 60 + "\n")

    report = {
        "demand": demand,
        "bill": bill,
        "anomaly": anomaly,
        "overall_pass": overall,
    }

    report_path = SAVED_MODELS_DIR / "model_health_report.json"
    report_path.write_text(json.dumps(report, indent=2))
    logger.info("Health report saved → %s", report_path)

    return report


if __name__ == "__main__":
    run_health_report()
