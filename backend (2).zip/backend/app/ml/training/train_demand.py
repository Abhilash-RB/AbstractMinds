"""
LSTM demand forecaster training script.

Run directly:
    python -m app.ml.training.train_demand

Or import and call ``train()`` from another script.
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
from datetime import datetime
from pathlib import Path

import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

SAVED_MODELS_DIR = Path(__file__).resolve().parents[2] / "saved_models"
SAVED_MODELS_DIR.mkdir(parents=True, exist_ok=True)

MODEL_VERSION = "1"
SEQUENCE_LENGTH = 168   # 1 week of hourly data
TARGET_HORIZON = 24     # next 24 hours
BATCH_SIZE = 32
EPOCHS = 100
VALIDATION_SPLIT = 0.20


def _build_model(sequence_length: int, n_features: int) -> "keras.Model":
    """
    Construct the LSTM demand forecasting model.

    Architecture
    ------------
    Input(sequence_length, n_features)
      → LSTM(128, return_sequences=True)
      → Dropout(0.2)
      → LSTM(64, return_sequences=False)
      → Dropout(0.2)
      → Dense(32, relu)
      → Dense(24, linear)

    Parameters
    ----------
    sequence_length:
        Number of timesteps in each input window.
    n_features:
        Number of feature channels per timestep.

    Returns
    -------
    keras.Model
        Compiled Keras model.
    """
    try:
        import tensorflow as tf
        from tensorflow import keras

        inputs = keras.Input(shape=(sequence_length, n_features), name="demand_input")
        x = keras.layers.LSTM(128, return_sequences=True, name="lstm_1")(inputs)
        x = keras.layers.Dropout(0.2, name="dropout_1")(x)
        x = keras.layers.LSTM(64, return_sequences=False, name="lstm_2")(x)
        x = keras.layers.Dropout(0.2, name="dropout_2")(x)
        x = keras.layers.Dense(32, activation="relu", name="dense_hidden")(x)
        outputs = keras.layers.Dense(TARGET_HORIZON, activation="linear", name="demand_output")(x)

        model = keras.Model(inputs, outputs, name="ThunderVoltsDemandLSTM")
        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=0.001),
            loss="huber",
            metrics=["mae"],
        )
        logger.info(model.summary())
        return model
    except ImportError:
        raise RuntimeError(
            "TensorFlow is required for LSTM training. "
            "Install with: pip install tensorflow"
        )


def _get_callbacks(model_path: Path) -> list:
    """
    Build Keras training callbacks.

    Returns
    -------
    list
        [EarlyStopping, ReduceLROnPlateau, ModelCheckpoint]
    """
    from tensorflow import keras

    early_stop = keras.callbacks.EarlyStopping(
        monitor="val_loss",
        patience=10,
        restore_best_weights=True,
        verbose=1,
    )
    reduce_lr = keras.callbacks.ReduceLROnPlateau(
        monitor="val_loss",
        factor=0.5,
        patience=5,
        min_lr=1e-6,
        verbose=1,
    )
    checkpoint = keras.callbacks.ModelCheckpoint(
        filepath=str(model_path),
        monitor="val_loss",
        save_best_only=True,
        verbose=1,
    )
    return [early_stop, reduce_lr, checkpoint]


async def train() -> dict:
    """
    Full LSTM demand forecaster training pipeline.

    Steps
    -----
    1. Load training data via :func:`load_all_training_data`.
    2. Clean and engineer features.
    3. Create LSTM sequences.
    4. Chronological 80/20 train/val split.
    5. Build, compile and train the Keras model.
    6. Evaluate on validation set.
    7. Save model + scaler to ``saved_models/``.
    8. Write training metadata JSON.

    Returns
    -------
    dict
        Metadata dict with validation MAE and RMSE.
    """
    from app.ml.data_pipeline.ingestion import load_all_training_data
    from app.ml.data_pipeline.preprocessing import (
        clean_demand_data,
        create_lstm_sequences,
        engineer_demand_features,
        FeatureScaler,
    )

    logger.info("═══ ThunderVolts LSTM Training — v%s ═══", MODEL_VERSION)

    # ── 1. Load data ───────────────────────────────────────────────────────
    logger.info("Loading training data …")
    data = await load_all_training_data()
    df = data["merged"]

    # ── 2. Clean & engineer features ─────────────────────────────────────
    logger.info("Cleaning and engineering features …")
    df = clean_demand_data(df)
    df = engineer_demand_features(df)
    df = df.dropna().reset_index(drop=True)

    feature_cols = [
        "demand_mw", "hour_sin", "hour_cos", "day_sin", "day_cos",
        "month_sin", "month_cos", "lag_1h", "lag_24h", "lag_168h",
        "rolling_mean_24h", "rolling_std_24h",
        "is_morning_peak", "is_evening_peak", "heat_index",
    ]
    feature_cols = [c for c in feature_cols if c in df.columns]
    n_features = len(feature_cols)
    logger.info("Features: %s (%d total)", feature_cols, n_features)

    # ── 3. Scale features ─────────────────────────────────────────────────
    scaler = FeatureScaler()
    scaler.fit(df, feature_cols)
    scaled_values = scaler.transform(df)
    scaled_df = df.copy()
    scaled_df[feature_cols] = scaled_values

    # ── 4. Create sequences ───────────────────────────────────────────────
    logger.info("Creating LSTM sequences (window=%d, horizon=%d) …",
                SEQUENCE_LENGTH, TARGET_HORIZON)
    X, y = create_lstm_sequences(scaled_df, SEQUENCE_LENGTH, TARGET_HORIZON, feature_cols)
    logger.info("X shape: %s, y shape: %s", X.shape, y.shape)

    # ── 5. Chronological train/val split ──────────────────────────────────
    split_idx = int(len(X) * (1 - VALIDATION_SPLIT))
    X_train, X_val = X[:split_idx], X[split_idx:]
    y_train, y_val = y[:split_idx], y[split_idx:]
    logger.info(
        "Train samples: %d | Val samples: %d", len(X_train), len(X_val)
    )

    # ── 6. Build & train model ────────────────────────────────────────────
    model_path = SAVED_MODELS_DIR / f"demand_lstm_v{MODEL_VERSION}.keras"
    model = _build_model(SEQUENCE_LENGTH, n_features)
    callbacks = _get_callbacks(model_path)

    logger.info("Training …")
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=callbacks,
        verbose=1,
    )

    # ── 7. Evaluate ───────────────────────────────────────────────────────
    y_pred = model.predict(X_val, batch_size=BATCH_SIZE)
    mae = float(np.mean(np.abs(y_pred - y_val)))
    rmse = float(math.sqrt(np.mean((y_pred - y_val) ** 2)))
    logger.info("Validation MAE : %.4f | RMSE : %.4f", mae, rmse)

    # ── 8. Save scaler ────────────────────────────────────────────────────
    scaler_path = SAVED_MODELS_DIR / f"demand_scaler_v{MODEL_VERSION}.pkl"
    scaler.save(scaler_path)
    logger.info("Scaler saved → %s", scaler_path)

    # ── 9. Metadata ───────────────────────────────────────────────────────
    meta = {
        "model_version": MODEL_VERSION,
        "trained_at": datetime.utcnow().isoformat() + "Z",
        "val_mae": round(mae, 4),
        "val_rmse": round(rmse, 4),
        "training_samples": int(len(X_train)),
        "val_samples": int(len(X_val)),
        "features_used": feature_cols,
        "sequence_length": SEQUENCE_LENGTH,
        "target_horizon": TARGET_HORIZON,
        "epochs_run": len(history.history["loss"]),
    }
    meta_path = SAVED_MODELS_DIR / f"demand_lstm_v{MODEL_VERSION}_meta.json"
    meta_path.write_text(json.dumps(meta, indent=2))
    logger.info("Metadata saved → %s", meta_path)
    logger.info("═══ Training complete. Model → %s ═══", model_path)

    return meta


if __name__ == "__main__":
    result = asyncio.run(train())
    print("\n=== Training Summary ===")
    for k, v in result.items():
        print(f"  {k}: {v}")
