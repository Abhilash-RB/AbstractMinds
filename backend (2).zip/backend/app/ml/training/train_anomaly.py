"""
Isolation Forest anomaly detector training script.

Run directly:
    python -m app.ml.training.train_anomaly
"""

from __future__ import annotations

import json
import logging
import pickle
import random
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import classification_report, f1_score, precision_score, recall_score

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

SAVED_MODELS_DIR = Path(__file__).resolve().parents[2] / "saved_models"
SAVED_MODELS_DIR.mkdir(parents=True, exist_ok=True)

MODEL_VERSION = "1"
N_APPLIANCES = 100
SIM_DAYS = 60
CONTAMINATION = 0.05

# ---------------------------------------------------------------------------
# Appliance usage generators
# ---------------------------------------------------------------------------

ApplianceType = str


def _ac_usage(hour: int, month: int, rng: random.Random) -> float:
    """Return kWh consumed by a split AC unit for the given hour."""
    is_summer = month in (3, 4, 5, 6)
    base = 1.5  # kW
    if is_summer and hour in range(12, 16):
        return base * rng.uniform(0.9, 1.1)
    if hour in range(20, 24) or hour == 0:
        return base * rng.uniform(0.7, 1.0)
    if hour in range(1, 6):
        return base * rng.uniform(0.5, 0.8)
    return 0.0


def _geyser_usage(hour: int, rng: random.Random) -> float:
    """Return kWh consumed by a storage geyser for the given hour."""
    # Spikes 6-8 AM and 7-9 PM, each 20-40 min
    if hour in (6, 7):
        return 2.0 * rng.uniform(0.33, 0.65)  # 20-40 min at 2kW
    if hour in (19, 20):
        return 2.0 * rng.uniform(0.33, 0.65)
    return 0.0


def _washing_machine_usage(
    hour: int, dow: int, week_count: dict, rng: random.Random
) -> float:
    """Return kWh consumed by a washing machine for the given hour."""
    # 1-2 sessions per week, 45-90 min at 0.5 kW
    sessions_this_week = week_count.get("wm", 0)
    if sessions_this_week >= 2:
        return 0.0
    if dow in (5, 6) and hour in range(9, 11) and rng.random() < 0.3:
        week_count["wm"] = sessions_this_week + 1
        return 0.5 * rng.uniform(0.75, 1.5)  # 45-90 min
    if rng.random() < 0.05 and hour in range(8, 11):
        week_count["wm"] = sessions_this_week + 1
        return 0.5 * rng.uniform(0.75, 1.5)
    return 0.0


def _ev_charger_usage(hour: int, rng: random.Random) -> float:
    """Return kWh consumed by a slow EV charger for the given hour."""
    # Overnight 10 PM-6 AM
    if hour in range(22, 24) or hour in range(0, 6):
        return 3.3 * rng.uniform(0.9, 1.05)
    return 0.0


APPLIANCE_GENERATORS = {
    "ac": _ac_usage,
    "geyser": _geyser_usage,
    "ev": _ev_charger_usage,
}


# ---------------------------------------------------------------------------
# Synthetic data generation
# ---------------------------------------------------------------------------


def generate_normal_usage_logs(
    n_appliances: int = N_APPLIANCES,
    sim_days: int = SIM_DAYS,
    seed: int = 42,
) -> pd.DataFrame:
    """
    Generate synthetic normal usage logs for multiple appliances.

    Parameters
    ----------
    n_appliances:
        Number of appliances to simulate.
    sim_days:
        Number of days to simulate.
    seed:
        Random seed.

    Returns
    -------
    pd.DataFrame
        Columns: ``appliance_id, appliance_type, timestamp, hour,
        dow, month, kwh, duration_min, is_anomaly``.
    """
    rng = random.Random(seed)
    np_rng = np.random.default_rng(seed)

    appliance_types = ["ac", "geyser", "washing_machine", "ev"] * (n_appliances // 4 + 1)
    appliance_types = appliance_types[:n_appliances]

    start = datetime(2024, 1, 1)
    records = []
    week_count: dict[str, dict] = {str(i): {} for i in range(n_appliances)}

    for day in range(sim_days):
        current = start + timedelta(days=day)
        month = current.month
        dow = current.weekday()
        if dow == 0:
            for k in week_count:
                week_count[k] = {}

        for appl_id in range(n_appliances):
            atype = appliance_types[appl_id]
            wc = week_count[str(appl_id)]

            for hour in range(24):
                ts = current + timedelta(hours=hour)

                if atype == "ac":
                    kwh = _ac_usage(hour, month, rng)
                elif atype == "geyser":
                    kwh = _geyser_usage(hour, rng)
                elif atype == "washing_machine":
                    kwh = _washing_machine_usage(hour, dow, wc, rng)
                else:
                    kwh = _ev_charger_usage(hour, rng)

                # Add mild noise to normal readings
                if kwh > 0:
                    kwh = max(0.0, kwh + np_rng.normal(0, kwh * 0.05))

                duration_min = (kwh / max(kwh, 0.001)) * 60 if kwh > 0 else 0

                records.append({
                    "appliance_id": appl_id,
                    "appliance_type": atype,
                    "timestamp": ts,
                    "hour": hour,
                    "dow": dow,
                    "month": month,
                    "kwh": round(kwh, 4),
                    "duration_min": round(duration_min, 1),
                    "is_anomaly": 0,
                })

    return pd.DataFrame(records)


def inject_anomalies(
    df: pd.DataFrame,
    contamination: float = CONTAMINATION,
    seed: int = 99,
) -> pd.DataFrame:
    """
    Inject three types of anomalies into a normal usage DataFrame.

    * **Type A** — Usage outside normal operating hours
    * **Type B** — Duration 3× longer than typical
    * **Type C** — Sudden wattage spike (kwh 4× normal)

    Parameters
    ----------
    df:
        Normal usage log DataFrame.
    contamination:
        Fraction of records to mark as anomalous.
    seed:
        Random seed.

    Returns
    -------
    pd.DataFrame
        DataFrame with injected anomalies; ``is_anomaly`` column updated.
    """
    rng = np.random.default_rng(seed)
    df = df.copy()

    non_zero_mask = df["kwh"] > 0
    non_zero_idx = df[non_zero_mask].index.tolist()
    n_inject = int(len(non_zero_idx) * contamination)
    anom_idx = rng.choice(non_zero_idx, size=n_inject, replace=False)

    for pos, idx in enumerate(anom_idx):
        atype = pos % 3  # cycle through A, B, C
        if atype == 0:  # Type A: off-hour usage
            current_hour = df.at[idx, "hour"]
            new_hour = (current_hour + 12) % 24  # shift by 12 h
            df.at[idx, "hour"] = new_hour
        elif atype == 1:  # Type B: 3× duration
            df.at[idx, "kwh"] = df.at[idx, "kwh"] * 3.0
            df.at[idx, "duration_min"] = df.at[idx, "duration_min"] * 3.0
        else:  # Type C: 4× wattage spike
            df.at[idx, "kwh"] = df.at[idx, "kwh"] * 4.0
        df.at[idx, "is_anomaly"] = 1

    return df


def build_features(df: pd.DataFrame) -> np.ndarray:
    """
    Build a feature matrix for the IsolationForest from usage logs.

    Features: ``[hour, dow, month, kwh, duration_min,
    is_expected_hour, kwh_vs_typical]``.

    Parameters
    ----------
    df:
        Usage log DataFrame.

    Returns
    -------
    np.ndarray
        Shape ``(n_rows, 7)``.
    """
    # Compute per-appliance-type median kwh for "is_expected" context
    type_median = df.groupby("appliance_type")["kwh"].transform("median")
    kwh_vs_typical = df["kwh"] / (type_median + 1e-6)

    # Expected hour flag (simplified: AC expected 12-16 and 20-23; geyser 6-8 and 19-20; etc.)
    expected_hours = {
        "ac": set(range(12, 16)) | set(range(20, 24)),
        "geyser": {6, 7, 19, 20},
        "washing_machine": set(range(8, 11)) | {19, 20},
        "ev": set(range(22, 24)) | set(range(0, 6)),
    }
    is_expected = df.apply(
        lambda row: int(row["hour"] in expected_hours.get(row["appliance_type"], set())),
        axis=1,
    )

    X = np.column_stack([
        df["hour"].values,
        df["dow"].values,
        df["month"].values,
        df["kwh"].values,
        df["duration_min"].values,
        is_expected.values,
        kwh_vs_typical.values,
    ])
    return X.astype(np.float32)


def train() -> dict:
    """
    Full Isolation Forest training pipeline for anomaly detection.

    Returns
    -------
    dict
        Metadata with precision, recall, F1.
    """
    logger.info("═══ ThunderVolts Anomaly Detector Training — v%s ═══", MODEL_VERSION)

    # ── 1. Generate normal logs ────────────────────────────────────────────
    logger.info("Generating %d synthetic appliance logs (%d days) …",
                N_APPLIANCES, SIM_DAYS)
    df = generate_normal_usage_logs(N_APPLIANCES, SIM_DAYS)

    # ── 2. Inject anomalies ────────────────────────────────────────────────
    logger.info("Injecting %.0f%% anomalies …", CONTAMINATION * 100)
    df = inject_anomalies(df, CONTAMINATION)
    logger.info("Anomaly count: %d / %d records",
                df["is_anomaly"].sum(), len(df))

    # ── 3. Build feature matrix ────────────────────────────────────────────
    X = build_features(df)
    y_true = df["is_anomaly"].values

    # Train/test split (last 10 days as test)
    split_ts = df["timestamp"].max() - timedelta(days=10)
    train_mask = df["timestamp"] < split_ts
    test_mask = ~train_mask

    X_train = X[train_mask]
    X_test = X[test_mask]
    y_test = y_true[test_mask]

    # ── 4. Train IsolationForest ───────────────────────────────────────────
    logger.info("Training IsolationForest (n_estimators=200, contamination=%.2f) …",
                CONTAMINATION)
    clf = IsolationForest(
        n_estimators=200,
        contamination=CONTAMINATION,
        random_state=42,
        n_jobs=-1,
    )
    clf.fit(X_train)

    # ── 5. Evaluate ───────────────────────────────────────────────────────
    # IsolationForest: -1 = anomaly, +1 = normal
    raw_pred = clf.predict(X_test)
    y_pred = (raw_pred == -1).astype(int)

    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)

    logger.info("Precision: %.4f | Recall: %.4f | F1: %.4f",
                precision, recall, f1)
    logger.info("\n%s", classification_report(y_test, y_pred,
                                              target_names=["Normal", "Anomaly"]))

    # ── 6. Save model ──────────────────────────────────────────────────────
    model_path = SAVED_MODELS_DIR / f"anomaly_iforest_v{MODEL_VERSION}.pkl"
    with open(model_path, "wb") as fh:
        pickle.dump(clf, fh)
    logger.info("Model saved → %s", model_path)

    meta = {
        "model_version": MODEL_VERSION,
        "trained_at": datetime.utcnow().isoformat() + "Z",
        "precision": round(float(precision), 4),
        "recall": round(float(recall), 4),
        "f1": round(float(f1), 4),
        "contamination": CONTAMINATION,
        "n_estimators": 200,
        "training_records": int(X_train.shape[0]),
        "test_records": int(X_test.shape[0]),
        "features": ["hour", "dow", "month", "kwh", "duration_min",
                     "is_expected_hour", "kwh_vs_typical"],
    }
    meta_path = SAVED_MODELS_DIR / f"anomaly_iforest_v{MODEL_VERSION}_meta.json"
    meta_path.write_text(json.dumps(meta, indent=2))
    logger.info("Metadata → %s", meta_path)
    logger.info("═══ Anomaly training complete ═══")
    return meta


if __name__ == "__main__":
    result = train()
    print("\n=== Anomaly Detector Training Summary ===")
    for k, v in result.items():
        print(f"  {k}: {v}")
