"""
Usage Anomaly Detector — uses Isolation Forest to detect unusual
energy consumption patterns per appliance.

Detects:
    - Unusually high consumption
    - Appliance running at unexpected hours
    - Sudden spikes vs 7-day rolling average
"""

import logging
from datetime import datetime, timezone
from typing import Any, Optional

import numpy as np
from pydantic import BaseModel

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class AnomalyAlert(BaseModel):
    """Single anomaly detection result."""
    appliance_name: str
    anomaly_type: str  # "high_consumption" | "unexpected_hour" | "spike"
    severity: str  # "low" | "medium" | "high"
    detected_at: str
    normal_range: str
    actual_value: float
    suggested_action: str


class UsageAnomalyDetector:
    """
    Isolation Forest-based anomaly detector for appliance usage.

    Trains on the first 30 days of user data, then updates weekly.
    """

    MODEL_VERSION = "anomaly-detector-v1.0"

    def __init__(self) -> None:
        self._model: Optional[Any] = None
        self._trained: bool = False
        self._rolling_stats: dict[str, dict] = {}

    def _build_features(self, usage_logs: list[dict]) -> np.ndarray:
        """
        Extract features from usage logs for anomaly detection.

        Features: [hour_of_day, units_consumed, day_of_week, is_weekend]
        """
        features = []
        for log in usage_logs:
            hour = log.get("hour_of_day", 0)
            units = log.get("units_consumed_kwh", 0)
            usage_date = log.get("usage_date")
            dow = 0
            if usage_date:
                try:
                    if isinstance(usage_date, str):
                        from datetime import date
                        d = date.fromisoformat(usage_date)
                    else:
                        d = usage_date
                    dow = d.weekday()
                except (ValueError, AttributeError):
                    pass
            is_weekend = int(dow >= 5)
            features.append([hour, units, dow, is_weekend])
        return np.array(features, dtype=np.float32) if features else np.empty((0, 4))

    def train(self, usage_logs: list[dict]) -> None:
        """
        Train the Isolation Forest on historical usage data.

        Requires at least 30 data points for meaningful training.
        """
        from sklearn.ensemble import IsolationForest

        X = self._build_features(usage_logs)
        if X.shape[0] < 10:
            logger.warning("Not enough data to train anomaly detector (%d rows).", X.shape[0])
            return

        self._model = IsolationForest(
            n_estimators=100,
            contamination=0.05,
            random_state=42,
            n_jobs=-1,
        )
        self._model.fit(X)
        self._trained = True
        logger.info("AnomalyDetector trained on %d samples.", X.shape[0])

    def _compute_rolling_stats(
        self, usage_logs: list[dict], appliance_name: str
    ) -> dict:
        """Compute 7-day rolling average and std for an appliance."""
        units_list = [l.get("units_consumed_kwh", 0) for l in usage_logs[-168:]]  # 7 days × 24h
        if not units_list:
            return {"mean": 0.0, "std": 1.0, "max": 0.0}
        arr = np.array(units_list)
        return {
            "mean": float(np.mean(arr)),
            "std": float(np.std(arr)) or 1.0,
            "max": float(np.max(arr)),
        }

    def detect_anomalies(
        self,
        usage_logs: list[dict],
        appliance: dict,
    ) -> list[AnomalyAlert]:
        """
        Detect anomalies in recent usage data for an appliance.

        Args:
            usage_logs: List of usage log dicts for this appliance.
            appliance: Appliance dict with name, wattage, category, etc.

        Returns:
            List of ``AnomalyAlert`` items.
        """
        if not usage_logs:
            return []

        appliance_name = appliance.get("name", "Unknown")
        wattage = appliance.get("wattage_watts", 100)
        pref_start = appliance.get("preferred_start_hour", 0)
        pref_end = appliance.get("preferred_end_hour", 23)

        stats = self._compute_rolling_stats(usage_logs, appliance_name)
        alerts: list[AnomalyAlert] = []
        now_iso = datetime.now(timezone.utc).isoformat()

        # --- Check recent logs (last 24 entries) ---
        recent = usage_logs[-24:]

        for log in recent:
            units = log.get("units_consumed_kwh", 0)
            hour = log.get("hour_of_day", 0)

            # 1. High consumption (> mean + 2*std)
            threshold = stats["mean"] + 2 * stats["std"]
            if units > threshold and threshold > 0:
                severity = "high" if units > stats["mean"] + 3 * stats["std"] else "medium"
                alerts.append(AnomalyAlert(
                    appliance_name=appliance_name,
                    anomaly_type="high_consumption",
                    severity=severity,
                    detected_at=now_iso,
                    normal_range=f"{stats['mean']:.2f} ± {stats['std']:.2f} kWh",
                    actual_value=units,
                    suggested_action=(
                        f"Your {appliance_name} consumed {units:.2f} kWh at hour {hour}, "
                        f"which is {'significantly ' if severity == 'high' else ''}"
                        f"above the normal range. Check for faulty thermostat, "
                        f"dirty filters, or incorrect settings."
                    ),
                ))

            # 2. Unexpected hour (outside preferred window)
            if not (pref_start <= hour <= pref_end) and units > stats["mean"] * 0.5:
                alerts.append(AnomalyAlert(
                    appliance_name=appliance_name,
                    anomaly_type="unexpected_hour",
                    severity="low",
                    detected_at=now_iso,
                    normal_range=f"Expected between {pref_start}:00–{pref_end}:00",
                    actual_value=float(hour),
                    suggested_action=(
                        f"Your {appliance_name} was active at {hour}:00, outside "
                        f"its usual window ({pref_start}:00–{pref_end}:00). "
                        f"If unintentional, check if it was left on or has a faulty timer."
                    ),
                ))

            # 3. Spike vs rolling average (>3x)
            if stats["mean"] > 0 and units > stats["mean"] * 3:
                alerts.append(AnomalyAlert(
                    appliance_name=appliance_name,
                    anomaly_type="spike",
                    severity="high",
                    detected_at=now_iso,
                    normal_range=f"7-day avg: {stats['mean']:.2f} kWh/hr",
                    actual_value=units,
                    suggested_action=(
                        f"Sudden spike detected: {units:.2f} kWh vs 7-day average "
                        f"of {stats['mean']:.2f} kWh. This could indicate a "
                        f"malfunctioning appliance or power surge. Inspect the "
                        f"{appliance_name} immediately."
                    ),
                ))

        # --- Isolation Forest scoring (if trained) ---
        if self._trained and self._model is not None:
            X = self._build_features(recent)
            if X.shape[0] > 0:
                scores = self._model.decision_function(X)
                predictions = self._model.predict(X)
                for i, (pred, score) in enumerate(zip(predictions, scores)):
                    if pred == -1:  # anomaly
                        log = recent[i]
                        alerts.append(AnomalyAlert(
                            appliance_name=appliance_name,
                            anomaly_type="statistical_anomaly",
                            severity="medium" if score < -0.3 else "low",
                            detected_at=now_iso,
                            normal_range=f"Isolation score: {score:.3f}",
                            actual_value=log.get("units_consumed_kwh", 0),
                            suggested_action=(
                                f"Statistical anomaly detected in {appliance_name} "
                                f"usage pattern. The consumption pattern differs "
                                f"from your typical behavior. Review if this was "
                                f"intentional."
                            ),
                        ))

        # De-duplicate by (type, hour)
        seen = set()
        unique: list[AnomalyAlert] = []
        for a in alerts:
            key = (a.anomaly_type, a.actual_value)
            if key not in seen:
                seen.add(key)
                unique.append(a)

        return unique
