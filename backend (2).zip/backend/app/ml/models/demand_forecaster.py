"""
Demand Forecaster ML model.

Uses an LSTM (Keras Sequential) to predict the next 24 hours of
electricity demand. Falls back to historical average peak-hour
patterns for the Indian grid when no trained model is available.
"""

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import numpy as np
from pydantic import BaseModel

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class HourlyDemandForecast(BaseModel):
    """Predicted demand for a single hour."""
    hour: int
    demand_mw: float
    is_likely_peak: bool
    confidence: float


_HISTORICAL_DEMAND: dict[int, float] = {
    0: 35, 1: 30, 2: 28, 3: 27, 4: 28, 5: 35,
    6: 55, 7: 70, 8: 80, 9: 85, 10: 78, 11: 72,
    12: 68, 13: 65, 14: 70, 15: 72, 16: 75, 17: 80,
    18: 90, 19: 95, 20: 92, 21: 85, 22: 70, 23: 50,
}
_PEAK_THRESHOLD = 80


class DemandForecasterModel:
    """
    LSTM-based 24h demand forecaster.
    Architecture: LSTM(128)->Dropout(0.2)->LSTM(64)->Dropout(0.2)->Dense(24)
    """

    MODEL_VERSION = "demand-forecaster-v1.0"
    SEQ_LEN = 24

    def __init__(self) -> None:
        self._model: Optional[Any] = None
        self._model_loaded: bool = False

    def _build_model(self) -> Any:
        """Build and compile the Keras LSTM model."""
        from tensorflow import keras
        from tensorflow.keras import layers
        model = keras.Sequential([
            layers.LSTM(128, return_sequences=True, input_shape=(self.SEQ_LEN, 7)),
            layers.Dropout(0.2),
            layers.LSTM(64, return_sequences=False),
            layers.Dropout(0.2),
            layers.Dense(24, activation="linear"),
        ])
        model.compile(optimizer="adam", loss="mse", metrics=["mae"])
        return model

    def load_model(self, path: str) -> None:
        """Load pre-trained LSTM model."""
        try:
            from tensorflow import keras
            self._model = keras.models.load_model(path)
            self._model_loaded = True
            logger.info("DemandForecaster loaded from %s", path)
        except Exception as exc:
            logger.warning("Could not load LSTM: %s", exc)
            self._model_loaded = False

    def save_model(self, path: str) -> None:
        """Save model to disk."""
        if self._model is None:
            return
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._model.save(path)

    def _prepare_input(self, cond: dict) -> np.ndarray:
        """Build (1,24,7) tensor from conditions."""
        now = datetime.now(timezone.utc)
        month = cond.get("month", now.month)
        dow = cond.get("day_of_week", now.weekday())
        temp = cond.get("temperature", 32.0)
        hum = cond.get("humidity", 55.0)
        holiday = float(cond.get("is_holiday", False))
        prev = cond.get("previous_24h_demand", list(_HISTORICAL_DEMAND.values()))
        if len(prev) < 24:
            prev = list(_HISTORICAL_DEMAND.values())
        seq = np.zeros((self.SEQ_LEN, 7), dtype=np.float32)
        for i in range(self.SEQ_LEN):
            h = (now.hour - self.SEQ_LEN + i) % 24
            seq[i] = [h/23, dow/6, month/12, temp/50, hum/100, holiday, prev[i]/100]
        return seq.reshape(1, self.SEQ_LEN, 7)

    def _fallback_predict(self, cond: dict) -> list[HourlyDemandForecast]:
        """Historical-average fallback adjusted by temperature."""
        temp = cond.get("temperature", 32.0)
        now_h = cond.get("current_hour", datetime.now(timezone.utc).hour)
        factor = 1.0 + max(0, (temp - 30)) * 0.02
        out: list[HourlyDemandForecast] = []
        for off in range(24):
            h = (now_h + off) % 24
            d = round(_HISTORICAL_DEMAND.get(h, 50) * factor, 1)
            out.append(HourlyDemandForecast(
                hour=h, demand_mw=d,
                is_likely_peak=d >= _PEAK_THRESHOLD,
                confidence=round(max(0.5, 0.95 - off * 0.015), 2),
            ))
        return out

    def predict_next_24h(self, current_conditions: dict) -> list[HourlyDemandForecast]:
        """Predict demand for next 24 hours."""
        if not self._model_loaded:
            return self._fallback_predict(current_conditions)
        try:
            X = self._prepare_input(current_conditions)
            raw = self._model.predict(X, verbose=0)[0] * 100
            now_h = current_conditions.get("current_hour", datetime.now(timezone.utc).hour)
            out: list[HourlyDemandForecast] = []
            for off in range(24):
                h = (now_h + off) % 24
                d = round(float(max(0, raw[off])), 1)
                out.append(HourlyDemandForecast(
                    hour=h, demand_mw=d,
                    is_likely_peak=d >= _PEAK_THRESHOLD,
                    confidence=round(max(0.5, 0.95 - off * 0.015), 2),
                ))
            return out
        except Exception as exc:
            logger.error("LSTM prediction failed: %s", exc)
            return self._fallback_predict(current_conditions)

    @staticmethod
    def classify_peak_hours(forecast: list[HourlyDemandForecast]) -> list[int]:
        """Return sorted list of peak-hour integers."""
        return sorted(f.hour for f in forecast if f.is_likely_peak)

    def train(self, X: np.ndarray, y: np.ndarray, epochs: int = 50, batch_size: int = 32) -> Any:
        """Train the LSTM on historical data. X:(n,24,7), y:(n,24)."""
        self._model = self._build_model()
        history = self._model.fit(X, y, epochs=epochs, batch_size=batch_size, validation_split=0.2)
        self._model_loaded = True
        return history
