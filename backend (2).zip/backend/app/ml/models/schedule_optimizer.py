"""
Schedule Optimizer — finds optimal time windows for running
schedulable appliances to minimize cost.

Scoring: (cost_score × 0.6) + (demand_score × 0.2) + (user_pref_score × 0.2)
Handles load conflicts when total wattage exceeds a safe limit.
"""

import logging
from typing import Optional

from pydantic import BaseModel

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

MAX_SAFE_LOAD_WATTS = 7000  # 7 kW — typical Indian domestic connection limit


class ApplianceInput(BaseModel):
    """Input schema for a single appliance to schedule."""
    name: str
    wattage_watts: float
    duration_hours: float
    is_schedulable: bool = True
    preferred_start_hour: int = 0
    preferred_end_hour: int = 23
    category: str = "other"


class TariffProfile(BaseModel):
    """Simplified 24-hour tariff profile."""
    hourly_rates: list[float]  # length 24, INR/kWh for each hour


class HourlyDemand(BaseModel):
    """Demand forecast for one hour."""
    hour: int
    demand_mw: float
    is_likely_peak: bool = False


class UserPreferences(BaseModel):
    """User scheduling preferences."""
    avoid_hours: list[int] = []  # hours the user wants to avoid
    prefer_hours: list[int] = []  # hours the user prefers
    max_concurrent_appliances: int = 3


class ScheduledAppliance(BaseModel):
    """Scheduled appliance output."""
    appliance_name: str
    recommended_start_hour: int
    recommended_end_hour: int
    estimated_cost_inr: float
    estimated_savings_vs_peak_inr: float
    reasoning: str


class DaySchedule(BaseModel):
    """Complete day schedule output."""
    date: str
    scheduled_appliances: list[ScheduledAppliance]
    total_estimated_cost: float
    total_potential_savings: float


class ScheduleOptimizer:
    """
    Optimizes appliance schedules using a sliding-window cost minimizer.

    For each schedulable appliance, slides a window of size
    ``duration_hours`` across 24 hours and scores each position.
    """

    COST_WEIGHT = 0.6
    DEMAND_WEIGHT = 0.2
    PREF_WEIGHT = 0.2

    def __init__(self) -> None:
        self._occupied_slots: dict[int, float] = {}  # hour → watts committed

    def _reset_slots(self) -> None:
        """Reset occupied slot tracker for a new scheduling run."""
        self._occupied_slots = {h: 0.0 for h in range(24)}

    def _score_window(
        self,
        start: int,
        duration: int,
        wattage: float,
        tariff: TariffProfile,
        demand: list[HourlyDemand],
        prefs: UserPreferences,
        pref_start: int,
        pref_end: int,
    ) -> tuple[float, float, str]:
        """
        Score a candidate time window. Lower is better.

        Returns (score, cost_inr, reasoning).
        """
        demand_map = {d.hour: d for d in demand}
        cost = 0.0
        demand_score = 0.0
        pref_score = 0.0
        reasons: list[str] = []

        for offset in range(duration):
            hour = (start + offset) % 24
            rate = tariff.hourly_rates[hour]
            units = wattage / 1000.0
            cost += units * rate

            # Demand score: prefer low-demand hours
            hd = demand_map.get(hour)
            if hd and hd.is_likely_peak:
                demand_score += 1.0
            elif hd:
                demand_score += hd.demand_mw / 100.0

            # User preference score
            if hour in prefs.avoid_hours:
                pref_score += 2.0
            elif hour in prefs.prefer_hours:
                pref_score -= 0.5
            if pref_start <= hour <= pref_end:
                pref_score -= 0.3

            # Check load conflict
            if self._occupied_slots.get(hour, 0) + wattage > MAX_SAFE_LOAD_WATTS:
                pref_score += 5.0  # heavy penalty

        # Normalize
        cost_norm = cost / max(1, duration)
        demand_norm = demand_score / max(1, duration)
        pref_norm = pref_score / max(1, duration)

        total = (
            self.COST_WEIGHT * cost_norm
            + self.DEMAND_WEIGHT * demand_norm
            + self.PREF_WEIGHT * pref_norm
        )

        end_hour = (start + duration - 1) % 24

        # Build reasoning
        peak_hours_used = sum(
            1 for off in range(duration)
            if demand_map.get((start + off) % 24, HourlyDemand(hour=0, demand_mw=0)).is_likely_peak
        )
        if peak_hours_used == 0:
            reasons.append("runs entirely during off-peak hours")
        avg_rate = cost / (wattage / 1000 * duration) if duration > 0 else 0
        reasons.append(f"avg rate ₹{avg_rate:.2f}/unit")
        if any((start + off) % 24 in prefs.prefer_hours for off in range(duration)):
            reasons.append("aligns with your preferred hours")

        reasoning = f"Scheduled {start:02d}:00–{(end_hour+1)%24:02d}:00 — " + "; ".join(reasons)
        return total, cost, reasoning

    def optimize_day_schedule(
        self,
        appliances: list[ApplianceInput],
        tariff_profile: TariffProfile,
        demand_forecast: list[HourlyDemand],
        user_preferences: UserPreferences,
        schedule_date: str = "",
    ) -> DaySchedule:
        """
        Find the optimal schedule for all schedulable appliances.

        Args:
            appliances: List of appliances to schedule.
            tariff_profile: 24-hour tariff rates.
            demand_forecast: 24-hour demand forecast.
            user_preferences: User's scheduling preferences.
            schedule_date: ISO date string.

        Returns:
            ``DaySchedule`` with per-appliance recommendations.
        """
        from datetime import date as _date
        if not schedule_date:
            schedule_date = _date.today().isoformat()

        self._reset_slots()
        scheduled: list[ScheduledAppliance] = []
        total_cost = 0.0
        total_savings = 0.0

        # Sort by wattage descending (schedule heavy loads first)
        sorted_appliances = sorted(appliances, key=lambda a: a.wattage_watts, reverse=True)

        for appl in sorted_appliances:
            if not appl.is_schedulable:
                # Non-schedulable: just estimate cost at preferred hour
                dur = max(1, int(appl.duration_hours))
                _, cost, _ = self._score_window(
                    appl.preferred_start_hour, dur, appl.wattage_watts,
                    tariff_profile, demand_forecast, user_preferences,
                    appl.preferred_start_hour, appl.preferred_end_hour,
                )
                end_h = (appl.preferred_start_hour + dur - 1) % 24
                scheduled.append(ScheduledAppliance(
                    appliance_name=appl.name,
                    recommended_start_hour=appl.preferred_start_hour,
                    recommended_end_hour=end_h,
                    estimated_cost_inr=round(cost, 2),
                    estimated_savings_vs_peak_inr=0.0,
                    reasoning="Non-schedulable — kept at preferred time.",
                ))
                total_cost += cost
                continue

            dur = max(1, int(appl.duration_hours))
            best_score = float("inf")
            best_start = 0
            best_cost = 0.0
            best_reasoning = ""

            for start_h in range(24):
                score, cost, reasoning = self._score_window(
                    start_h, dur, appl.wattage_watts,
                    tariff_profile, demand_forecast, user_preferences,
                    appl.preferred_start_hour, appl.preferred_end_hour,
                )
                if score < best_score:
                    best_score = score
                    best_start = start_h
                    best_cost = cost
                    best_reasoning = reasoning

            # Calculate savings vs worst (peak) time
            savings = self.calculate_savings_vs_worst_time(appl, tariff_profile)

            end_h = (best_start + dur - 1) % 24

            # Reserve slots
            for off in range(dur):
                h = (best_start + off) % 24
                self._occupied_slots[h] = self._occupied_slots.get(h, 0) + appl.wattage_watts

            scheduled.append(ScheduledAppliance(
                appliance_name=appl.name,
                recommended_start_hour=best_start,
                recommended_end_hour=end_h,
                estimated_cost_inr=round(best_cost, 2),
                estimated_savings_vs_peak_inr=round(savings, 2),
                reasoning=best_reasoning,
            ))
            total_cost += best_cost
            total_savings += savings

        return DaySchedule(
            date=schedule_date,
            scheduled_appliances=scheduled,
            total_estimated_cost=round(total_cost, 2),
            total_potential_savings=round(total_savings, 2),
        )

    @staticmethod
    def calculate_savings_vs_worst_time(
        appliance: ApplianceInput,
        tariff_profile: TariffProfile,
    ) -> float:
        """
        Calculate potential savings compared to running at the most
        expensive (peak) hours.

        Args:
            appliance: The appliance to evaluate.
            tariff_profile: 24-hour tariff rates.

        Returns:
            Savings in INR.
        """
        dur = max(1, int(appliance.duration_hours))
        units_per_hour = appliance.wattage_watts / 1000.0

        # Find most expensive window
        worst_cost = 0.0
        for start in range(24):
            cost = sum(
                tariff_profile.hourly_rates[(start + off) % 24] * units_per_hour
                for off in range(dur)
            )
            worst_cost = max(worst_cost, cost)

        # Find cheapest window
        best_cost = float("inf")
        for start in range(24):
            cost = sum(
                tariff_profile.hourly_rates[(start + off) % 24] * units_per_hour
                for off in range(dur)
            )
            best_cost = min(best_cost, cost)

        return round(worst_cost - best_cost, 2)
