"""
Bill Predictor ML model.

Uses XGBoost regression to predict monthly electricity bills.
Falls back to a deterministic rule-based calculation when no
trained model is available.

Every prediction is logged to the prediction_log table for
auditing and model performance tracking.
"""

import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import numpy as np
from pydantic import BaseModel

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# ── Pydantic Schemas ────────────────────────────────────────────────────

class ApplianceBreakdown(BaseModel):
    """Predicted consumption breakdown for one appliance."""
    name: str
    estimated_units_kwh: float
    estimated_cost_inr: float
    percentage_of_total: float


class BillPrediction(BaseModel):
    """Complete bill prediction output."""
    predicted_units_kwh: float
    predicted_cost_inr: float
    confidence_interval_low: float
    confidence_interval_high: float
    breakdown_by_appliance: list[ApplianceBreakdown]
    model_version: str
    prediction_id: str


# ── Feature names (must match training pipeline) ────────────────────────
FEATURE_NAMES = [
    "city_encoded",
    "month",
    "avg_daily_temp",
    "num_appliances",
    "total_rated_watts",
    "avg_daily_usage_hours",
    "has_ac",
    "has_ev",
    "has_geyser",
    "household_size",
    "previous_month_units",
    "discom_encoded",
    "is_summer",
]

# ── City / DISCOM encoding maps (deterministic hashing) ─────────────────

_CITY_CODES: dict[str, int] = {
    "bengaluru": 1, "bangalore": 1, "mumbai": 2, "delhi": 3,
    "new delhi": 3, "chennai": 4, "hyderabad": 5, "kolkata": 6,
    "pune": 7, "ahmedabad": 8, "jaipur": 9, "lucknow": 10,
    "surat": 11, "kochi": 12, "nagpur": 13, "visakhapatnam": 14,
    "indore": 15, "bhopal": 16, "chandigarh": 17, "coimbatore": 18,
    "thiruvananthapuram": 19, "vadodara": 20, "mysuru": 21,
}

_DISCOM_CODES: dict[str, int] = {
    "bescom": 1, "msedcl": 2, "tata power mumbai": 3,
    "adani electricity": 4, "bses rajdhani": 5, "bses yamuna": 6,
    "tpddl": 7, "tangedco": 8, "tsspdcl": 9, "cesc kolkata": 10,
    "wbsedcl": 11, "pvvnl": 12, "mvvnl": 13, "kesco": 14,
    "jvvnl": 15, "ugvcl": 16, "dgvcl": 17, "kseb": 18,
}


def _encode_city(city: str) -> int:
    """Hash a city name to a numeric code."""
    return _CITY_CODES.get(city.strip().lower(), hash(city.lower()) % 100 + 50)


def _encode_discom(discom: str) -> int:
    """Hash a DISCOM name to a numeric code."""
    return _DISCOM_CODES.get(discom.strip().lower(), hash(discom.lower()) % 100 + 50)


class BillPredictorModel:
    """
    Monthly electricity bill predictor using XGBoost.

    When no trained model file is available, the predictor automatically
    falls back to a rule-based calculation using wattage × hours × tariff.
    """

    MODEL_VERSION = "bill-predictor-v1.0"

    def __init__(self) -> None:
        self._model: Optional[Any] = None
        self._model_loaded: bool = False

    # ── Model I/O ───────────────────────────────────────────────────────

    def load_model(self, path: str) -> None:
        """
        Load a pre-trained XGBoost model from disk.

        Args:
            path: File path to the saved ``.json`` or ``.ubj`` model.
        """
        try:
            import xgboost as xgb

            booster = xgb.Booster()
            booster.load_model(path)
            self._model = booster
            self._model_loaded = True
            logger.info("BillPredictorModel loaded from %s", path)
        except Exception as exc:
            logger.warning("Could not load XGBoost model from %s: %s", path, exc)
            self._model_loaded = False

    def save_model(self, path: str) -> None:
        """
        Save the trained model to disk.

        Args:
            path: Destination file path.
        """
        if self._model is None:
            logger.error("No model to save.")
            return
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            self._model.save_model(path)
            logger.info("Model saved to %s", path)
        except Exception as exc:
            logger.error("Failed to save model: %s", exc)

    # ── Feature Engineering ─────────────────────────────────────────────

    def _build_feature_vector(self, features: dict) -> np.ndarray:
        """
        Convert a raw feature dict into a numeric numpy array.

        Missing keys default to sensible values.
        """
        appliances = features.get("appliances", [])
        has_ac = int(any(
            a.get("category", "").lower() == "cooling" or "ac" in a.get("name", "").lower()
            for a in appliances
        ))
        has_ev = int(any(
            a.get("category", "").lower() == "ev" or "ev" in a.get("name", "").lower()
            for a in appliances
        ))
        has_geyser = int(any(
            a.get("category", "").lower() == "heating" or "geyser" in a.get("name", "").lower()
            for a in appliances
        ))
        total_watts = sum(a.get("wattage_watts", 0) for a in appliances)
        avg_hours = (
            np.mean([a.get("avg_daily_usage_hours", 0) for a in appliances])
            if appliances else 0.0
        )
        month = features.get("month", datetime.now().month)
        is_summer = int(month in (3, 4, 5, 6, 7, 8, 9, 10))

        vector = np.array([
            _encode_city(features.get("city", "")),
            month,
            features.get("avg_daily_temp", 32.0),
            len(appliances),
            total_watts,
            float(avg_hours),
            has_ac,
            has_ev,
            has_geyser,
            features.get("household_size", 4),
            features.get("previous_month_units", 250.0),
            _encode_discom(features.get("discom", "")),
            is_summer,
        ], dtype=np.float32).reshape(1, -1)

        return vector

    # ── Rule-based Fallback ─────────────────────────────────────────────

    def _rule_based_predict(self, features: dict) -> BillPrediction:
        """
        Deterministic bill prediction from wattage × hours × tariff rate.

        Used when no trained ML model is available.
        """
        appliances = features.get("appliances", [])
        tariff_rate = features.get("tariff_rate", 6.5)  # INR/unit fallback
        days_in_month = features.get("days_in_month", 30)

        breakdowns: list[ApplianceBreakdown] = []
        total_units = 0.0
        total_cost = 0.0

        for appl in appliances:
            wattage = appl.get("wattage_watts", 100)
            hours = appl.get("avg_daily_usage_hours", 2.0)
            name = appl.get("name", "Unknown")

            units = (wattage / 1000.0) * hours * days_in_month
            cost = units * tariff_rate

            total_units += units
            total_cost += cost
            breakdowns.append(
                ApplianceBreakdown(
                    name=name,
                    estimated_units_kwh=round(units, 2),
                    estimated_cost_inr=round(cost, 2),
                    percentage_of_total=0.0,  # filled below
                )
            )

        # Fill percentage
        for b in breakdowns:
            b.percentage_of_total = round(
                (b.estimated_units_kwh / total_units * 100) if total_units > 0 else 0.0, 1
            )

        # Add fixed charges and taxes estimate
        fixed_charges = features.get("fixed_charges", 75.0)
        taxes_pct = features.get("taxes_percentage", 5.0)
        total_cost += fixed_charges
        total_cost *= 1 + taxes_pct / 100.0

        prediction_id = str(uuid.uuid4())
        return BillPrediction(
            predicted_units_kwh=round(total_units, 2),
            predicted_cost_inr=round(total_cost, 2),
            confidence_interval_low=round(total_cost * 0.85, 2),
            confidence_interval_high=round(total_cost * 1.15, 2),
            breakdown_by_appliance=breakdowns,
            model_version=f"{self.MODEL_VERSION}-rule-based",
            prediction_id=prediction_id,
        )

    # ── ML Prediction ──────────────────────────────────────────────────

    def predict_monthly_bill(self, features: dict) -> BillPrediction:
        """
        Predict the monthly electricity bill.

        Uses XGBoost if a trained model is loaded; otherwise falls
        back to rule-based calculation.

        Args:
            features: Dictionary containing user profile, appliance
                list, weather data, and tariff information.

        Returns:
            ``BillPrediction`` with units, cost, confidence interval,
            and per-appliance breakdown.
        """
        if not self._model_loaded or self._model is None:
            logger.info("No trained model — using rule-based fallback.")
            return self._rule_based_predict(features)

        try:
            import xgboost as xgb

            X = self._build_feature_vector(features)
            dmatrix = xgb.DMatrix(X, feature_names=FEATURE_NAMES)
            predicted_units = float(self._model.predict(dmatrix)[0])
            predicted_units = max(0.0, predicted_units)

            # Derive cost from predicted units × tariff
            tariff_rate = features.get("tariff_rate", 6.5)
            fixed_charges = features.get("fixed_charges", 75.0)
            taxes_pct = features.get("taxes_percentage", 5.0)

            base_cost = predicted_units * tariff_rate + fixed_charges
            total_cost = base_cost * (1 + taxes_pct / 100.0)

            # Build approximate per-appliance breakdown using wattage share
            appliances = features.get("appliances", [])
            total_watts = sum(a.get("wattage_watts", 0) for a in appliances) or 1
            breakdowns: list[ApplianceBreakdown] = []
            for appl in appliances:
                share = appl.get("wattage_watts", 0) / total_watts
                appl_units = predicted_units * share
                breakdowns.append(
                    ApplianceBreakdown(
                        name=appl.get("name", "Unknown"),
                        estimated_units_kwh=round(appl_units, 2),
                        estimated_cost_inr=round(total_cost * share, 2),
                        percentage_of_total=round(share * 100, 1),
                    )
                )

            # Confidence interval (±15% heuristic; proper quantile
            # regression would be used in production)
            ci_low = total_cost * 0.85
            ci_high = total_cost * 1.15

            prediction_id = str(uuid.uuid4())
            return BillPrediction(
                predicted_units_kwh=round(predicted_units, 2),
                predicted_cost_inr=round(total_cost, 2),
                confidence_interval_low=round(ci_low, 2),
                confidence_interval_high=round(ci_high, 2),
                breakdown_by_appliance=breakdowns,
                model_version=self.MODEL_VERSION,
                prediction_id=prediction_id,
            )

        except Exception as exc:
            logger.error("XGBoost prediction failed, falling back: %s", exc)
            return self._rule_based_predict(features)

    # ── Training Stub (for Celery tasks) ────────────────────────────────

    def train(self, X: np.ndarray, y: np.ndarray, **kwargs: Any) -> None:
        """
        Train the XGBoost model on labelled data.

        Args:
            X: Feature matrix of shape (n_samples, 13).
            y: Target vector of monthly kWh values.
            **kwargs: Additional XGBoost training params.
        """
        import xgboost as xgb

        params = {
            "objective": "reg:squarederror",
            "max_depth": 6,
            "learning_rate": 0.1,
            "n_estimators": 200,
            "subsample": 0.8,
            "colsample_bytree": 0.8,
            "reg_alpha": 0.1,
            "reg_lambda": 1.0,
            "eval_metric": "rmse",
        }
        params.update(kwargs)

        dtrain = xgb.DMatrix(X, label=y, feature_names=FEATURE_NAMES)
        num_rounds = params.pop("n_estimators", 200)
        self._model = xgb.train(params, dtrain, num_boost_round=num_rounds)
        self._model_loaded = True
        logger.info("BillPredictorModel trained for %d rounds.", num_rounds)
