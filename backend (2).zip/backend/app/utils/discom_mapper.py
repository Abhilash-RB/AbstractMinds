"""
DISCOM (Distribution Company) mapping utilities for India.

Provides lookup functions to map a user's city/state to the correct
electricity distribution company and tariff zone.

Coverage:
    Karnataka, Maharashtra, Delhi, Tamil Nadu, Andhra Pradesh, Telangana,
    Gujarat, West Bengal, Uttar Pradesh, Rajasthan, Kerala, Madhya Pradesh,
    Punjab, Haryana, Chhattisgarh, Odisha, Bihar, Jharkhand, Goa
"""

from typing import List, Literal

# ── DISCOM_MAP ──────────────────────────────────────────────────────────
# Keys are lowercased city names → values are DISCOM short-names.
# Multiple cities may share the same DISCOM.

DISCOM_MAP: dict[str, dict[str, str]] = {
    # ── Karnataka ───────────────────────────────────────────────────────
    "karnataka": {
        "bengaluru": "BESCOM",
        "bangalore": "BESCOM",
        "bengaluru rural": "BESCOM",
        "tumkur": "BESCOM",
        "kolar": "BESCOM",
        "ramanagara": "BESCOM",
        "davanagere": "BESCOM",
        "chitradurga": "BESCOM",
        "hubli": "HESCOM",
        "dharwad": "HESCOM",
        "belgaum": "HESCOM",
        "belagavi": "HESCOM",
        "haveri": "HESCOM",
        "gadag": "HESCOM",
        "uttara kannada": "HESCOM",
        "mysuru": "MESCOM",
        "mysore": "MESCOM",
        "mandya": "MESCOM",
        "hassan": "MESCOM",
        "kodagu": "MESCOM",
        "chamarajanagar": "MESCOM",
        "gulbarga": "GESCOM",
        "kalaburagi": "GESCOM",
        "raichur": "GESCOM",
        "bidar": "GESCOM",
        "yadgir": "GESCOM",
        "bellary": "GESCOM",
        "ballari": "GESCOM",
        "koppal": "GESCOM",
        "mangaluru": "CESC Mysore",
        "mangalore": "CESC Mysore",
        "udupi": "CESC Mysore",
        "shimoga": "CESC Mysore",
        "shivamogga": "CESC Mysore",
    },
    # ── Maharashtra ─────────────────────────────────────────────────────
    "maharashtra": {
        "mumbai": "Tata Power Mumbai",
        "mumbai suburban": "Adani Electricity",
        "thane": "MSEDCL",
        "pune": "MSEDCL",
        "nagpur": "MSEDCL",
        "nashik": "MSEDCL",
        "aurangabad": "MSEDCL",
        "solapur": "MSEDCL",
        "kolhapur": "MSEDCL",
        "amravati": "MSEDCL",
        "navi mumbai": "MSEDCL",
        "sangli": "MSEDCL",
        "jalgaon": "MSEDCL",
        "akola": "MSEDCL",
        "latur": "MSEDCL",
        "chandrapur": "MSEDCL",
        "nanded": "MSEDCL",
    },
    # ── Delhi ───────────────────────────────────────────────────────────
    "delhi": {
        "new delhi": "BSES Rajdhani",
        "south delhi": "BSES Rajdhani",
        "east delhi": "BSES Yamuna",
        "north east delhi": "BSES Yamuna",
        "north delhi": "TPDDL",
        "north west delhi": "TPDDL",
        "west delhi": "BSES Rajdhani",
        "central delhi": "BSES Rajdhani",
        "delhi": "BSES Rajdhani",
        "dwarka": "BSES Rajdhani",
        "rohini": "TPDDL",
        "shahdara": "BSES Yamuna",
    },
    # ── Tamil Nadu ──────────────────────────────────────────────────────
    "tamil nadu": {
        "chennai": "TANGEDCO",
        "coimbatore": "TANGEDCO",
        "madurai": "TANGEDCO",
        "tiruchirappalli": "TANGEDCO",
        "trichy": "TANGEDCO",
        "salem": "TANGEDCO",
        "erode": "TANGEDCO",
        "tirunelveli": "TANGEDCO",
        "vellore": "TANGEDCO",
        "thanjavur": "TANGEDCO",
        "dindigul": "TANGEDCO",
        "tiruppur": "TANGEDCO",
    },
    # ── Andhra Pradesh ──────────────────────────────────────────────────
    "andhra pradesh": {
        "visakhapatnam": "APEPDCL",
        "vizag": "APEPDCL",
        "srikakulam": "APEPDCL",
        "rajamahendravaram": "APEPDCL",
        "rajahmundry": "APEPDCL",
        "kakinada": "APEPDCL",
        "vijayawada": "APSPDCL",
        "guntur": "APSPDCL",
        "nellore": "APSPDCL",
        "tirupati": "APSPDCL",
        "kurnool": "APSPDCL",
        "anantapur": "APSPDCL",
        "amaravati": "APSPDCL",
        "kadapa": "APSPDCL",
    },
    # ── Telangana ───────────────────────────────────────────────────────
    "telangana": {
        "hyderabad": "TSSPDCL",
        "secunderabad": "TSSPDCL",
        "rangareddy": "TSSPDCL",
        "medchal": "TSSPDCL",
        "warangal": "TSNPDCL",
        "karimnagar": "TSNPDCL",
        "nizamabad": "TSNPDCL",
        "khammam": "TSNPDCL",
        "nalgonda": "TSNPDCL",
        "adilabad": "TSNPDCL",
        "mahbubnagar": "TSNPDCL",
    },
    # ── Gujarat ─────────────────────────────────────────────────────────
    "gujarat": {
        "ahmedabad": "UGVCL",
        "surat": "DGVCL",
        "vadodara": "MGVCL",
        "baroda": "MGVCL",
        "rajkot": "PGVCL",
        "bhavnagar": "PGVCL",
        "jamnagar": "PGVCL",
        "junagadh": "PGVCL",
        "gandhinagar": "UGVCL",
        "anand": "MGVCL",
        "nadiad": "MGVCL",
        "bharuch": "DGVCL",
        "valsad": "DGVCL",
        "navsari": "DGVCL",
        "mehsana": "UGVCL",
        "kutch": "PGVCL",
    },
    # ── West Bengal ─────────────────────────────────────────────────────
    "west bengal": {
        "kolkata": "CESC Kolkata",
        "howrah": "CESC Kolkata",
        "siliguri": "WBSEDCL",
        "durgapur": "WBSEDCL",
        "asansol": "WBSEDCL",
        "bardhaman": "WBSEDCL",
        "kharagpur": "WBSEDCL",
        "haldia": "WBSEDCL",
        "malda": "WBSEDCL",
        "medinipur": "WBSEDCL",
        "north 24 parganas": "WBSEDCL",
        "south 24 parganas": "WBSEDCL",
    },
    # ── Uttar Pradesh ───────────────────────────────────────────────────
    "uttar pradesh": {
        "lucknow": "MVVNL",
        "kanpur": "KESCO",
        "noida": "PVVNL",
        "ghaziabad": "PVVNL",
        "greater noida": "PVVNL",
        "meerut": "PVVNL",
        "agra": "DVVNL",
        "mathura": "DVVNL",
        "varanasi": "PuVVNL",
        "prayagraj": "PuVVNL",
        "allahabad": "PuVVNL",
        "gorakhpur": "PuVVNL",
        "jhansi": "DVVNL",
        "bareilly": "PVVNL",
        "aligarh": "DVVNL",
        "moradabad": "PVVNL",
        "saharanpur": "PVVNL",
        "firozabad": "DVVNL",
        "muzaffarnagar": "PVVNL",
        "sultanpur": "MVVNL",
        "faizabad": "MVVNL",
        "ayodhya": "MVVNL",
        "rae bareli": "MVVNL",
        "unnao": "MVVNL",
    },
    # ── Rajasthan ───────────────────────────────────────────────────────
    "rajasthan": {
        "jaipur": "JVVNL",
        "ajmer": "JVVNL",
        "kota": "JVVNL",
        "udaipur": "AVVNL",
        "jodhpur": "JdVVNL",
        "bikaner": "JdVVNL",
        "bharatpur": "JVVNL",
        "alwar": "JVVNL",
        "sikar": "JVVNL",
        "bhilwara": "AVVNL",
        "chittorgarh": "AVVNL",
        "pali": "JdVVNL",
        "barmer": "JdVVNL",
        "jaisalmer": "JdVVNL",
        "nagaur": "JdVVNL",
    },
    # ── Kerala ──────────────────────────────────────────────────────────
    "kerala": {
        "thiruvananthapuram": "KSEB",
        "kochi": "KSEB",
        "kozhikode": "KSEB",
        "thrissur": "KSEB",
        "kollam": "KSEB",
        "palakkad": "KSEB",
        "ernakulam": "KSEB",
    },
    # ── Madhya Pradesh ──────────────────────────────────────────────────
    "madhya pradesh": {
        "bhopal": "MPCZ",
        "indore": "MPPKVVCL",
        "gwalior": "MPEZ",
        "jabalpur": "MPEZ",
        "ujjain": "MPPKVVCL",
    },
    # ── Punjab ──────────────────────────────────────────────────────────
    "punjab": {
        "chandigarh": "PSPCL",
        "ludhiana": "PSPCL",
        "amritsar": "PSPCL",
        "jalandhar": "PSPCL",
        "patiala": "PSPCL",
    },
    # ── Haryana ─────────────────────────────────────────────────────────
    "haryana": {
        "gurugram": "DHBVN",
        "gurgaon": "DHBVN",
        "faridabad": "DHBVN",
        "hisar": "UHBVN",
        "karnal": "UHBVN",
        "panipat": "UHBVN",
        "rohtak": "UHBVN",
        "ambala": "UHBVN",
    },
    # ── Chhattisgarh ────────────────────────────────────────────────────
    "chhattisgarh": {
        "raipur": "CSPDCL",
        "bilaspur": "CSPDCL",
        "durg": "CSPDCL",
        "bhilai": "CSPDCL",
    },
    # ── Odisha ──────────────────────────────────────────────────────────
    "odisha": {
        "bhubaneswar": "TPCODL",
        "cuttack": "TPCODL",
        "rourkela": "TPNODL",
        "berhampur": "TPSODL",
        "sambalpur": "TPWODL",
    },
    # ── Bihar ───────────────────────────────────────────────────────────
    "bihar": {
        "patna": "SBPDCL",
        "gaya": "SBPDCL",
        "bhagalpur": "NBPDCL",
        "muzaffarpur": "NBPDCL",
        "darbhanga": "NBPDCL",
    },
    # ── Jharkhand ───────────────────────────────────────────────────────
    "jharkhand": {
        "ranchi": "JBVNL",
        "jamshedpur": "JBVNL",
        "dhanbad": "JBVNL",
        "bokaro": "JBVNL",
    },
    # ── Goa ─────────────────────────────────────────────────────────────
    "goa": {
        "panaji": "GoaED",
        "margao": "GoaED",
        "vasco": "GoaED",
    },
}

# ── Urban cities (major metros + state capitals + million-plus cities) ──
_URBAN_CITIES: set[str] = {
    "bengaluru", "bangalore", "mumbai", "delhi", "new delhi", "chennai",
    "kolkata", "hyderabad", "pune", "ahmedabad", "surat", "jaipur",
    "lucknow", "kanpur", "nagpur", "visakhapatnam", "vizag", "indore",
    "thane", "bhopal", "coimbatore", "patna", "vadodara", "baroda",
    "kochi", "rajkot", "ghaziabad", "noida", "greater noida",
    "gurugram", "gurgaon", "faridabad", "navi mumbai", "varanasi",
    "thiruvananthapuram", "ranchi", "mysuru", "mysore", "chandigarh",
    "jodhpur", "madurai", "raipur", "vijayawada", "secunderabad",
}

# ── Semi-urban cities ───────────────────────────────────────────────────
_SEMI_URBAN_CITIES: set[str] = {
    "hubli", "mangaluru", "mangalore", "belgaum", "belagavi",
    "nashik", "aurangabad", "solapur", "kolhapur", "amravati",
    "agra", "meerut", "bareilly", "aligarh", "udaipur", "kota",
    "siliguri", "durgapur", "asansol", "trichy", "tiruchirappalli",
    "tirupati", "warangal", "bhavnagar", "jamnagar", "jalandhar",
    "ludhiana", "amritsar", "patiala", "bhubaneswar", "cuttack",
    "jamshedpur", "dhanbad", "salem", "erode", "vellore",
    "tirunelveli", "nellore", "guntur", "kakinada", "thanjavur",
    "panaji", "margao", "hisar", "karnal", "panipat", "rohtak",
}


def get_discom(city: str, state: str) -> str:
    """
    Resolve the DISCOM for a given city and state.

    Args:
        city: City name (case-insensitive).
        state: State name (case-insensitive).

    Returns:
        DISCOM identifier string.  Falls back to the first available
        DISCOM in the state map, or ``"GENERIC_DISCOM"`` if the state
        is not mapped.
    """
    state_lower = state.strip().lower()
    city_lower = city.strip().lower()

    state_map = DISCOM_MAP.get(state_lower)
    if state_map is None:
        return "GENERIC_DISCOM"

    discom = state_map.get(city_lower)
    if discom is not None:
        return discom

    # Fallback: return the first DISCOM listed for the state
    return next(iter(state_map.values()), "GENERIC_DISCOM")


def get_tariff_zone(city: str) -> Literal["urban", "semi-urban", "rural"]:
    """
    Classify a city into a tariff zone.

    Args:
        city: City name (case-insensitive).

    Returns:
        ``"urban"``, ``"semi-urban"``, or ``"rural"``.
    """
    city_lower = city.strip().lower()
    if city_lower in _URBAN_CITIES:
        return "urban"
    if city_lower in _SEMI_URBAN_CITIES:
        return "semi-urban"
    return "rural"


def list_all_discoms() -> List[str]:
    """
    Return a de-duplicated, sorted list of every DISCOM in the map.

    Returns:
        Alphabetically sorted list of unique DISCOM names.
    """
    discoms: set[str] = set()
    for state_map in DISCOM_MAP.values():
        discoms.update(state_map.values())
    return sorted(discoms)
