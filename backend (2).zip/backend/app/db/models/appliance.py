"""
Appliance ORM model.

Stores individual appliances registered by a user, including wattage,
daily usage, schedulability, and preferred operating window.
"""

import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Enum, Float, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class ApplianceCategory(str, enum.Enum):
    """Enumeration of supported appliance categories."""

    COOLING = "cooling"
    HEATING = "heating"
    WASHING = "washing"
    EV = "ev"
    LIGHTING = "lighting"
    OTHER = "other"


class Appliance(Base):
    """A single household appliance owned by a user."""

    __tablename__ = "appliances"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        index=True,
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    category: Mapped[ApplianceCategory] = mapped_column(
        Enum(ApplianceCategory, name="appliance_category", create_constraint=True),
        nullable=False,
    )
    wattage_watts: Mapped[float] = mapped_column(Float, nullable=False)
    avg_daily_usage_hours: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    is_schedulable: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    preferred_start_hour: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    preferred_end_hour: Mapped[int] = mapped_column(Integer, default=23, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # ── Relationships ───────────────────────────────────────────────────
    user = relationship("User", back_populates="appliances")
    usage_logs = relationship(
        "UsageLog", back_populates="appliance", cascade="all, delete-orphan", lazy="selectin"
    )

    def __repr__(self) -> str:
        return f"<Appliance {self.name} ({self.wattage_watts}W)>"
