"""
PredictionLog ORM model.

Logs every ML / AI prediction made by the system for auditing, model
performance tracking, and A/B testing of model versions.
"""

import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, Enum, Float, ForeignKey, String
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class PredictionType(str, enum.Enum):
    """Types of predictions the system can generate."""

    BILL = "bill"
    DEMAND = "demand"
    ANOMALY = "anomaly"
    SCHEDULE = "schedule"


class PredictionLog(Base):
    """Immutable audit record of a single ML prediction."""

    __tablename__ = "prediction_logs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        index=True,
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    prediction_type: Mapped[PredictionType] = mapped_column(
        Enum(PredictionType, name="prediction_type", create_constraint=True),
        nullable=False,
    )
    input_features: Mapped[dict] = mapped_column(JSON, nullable=False)
    predicted_value: Mapped[dict] = mapped_column(JSON, nullable=False)
    confidence_score: Mapped[float] = mapped_column(Float, nullable=True)
    model_version: Mapped[str] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # ── Relationships ───────────────────────────────────────────────────
    user = relationship("User", back_populates="prediction_logs")

    def __repr__(self) -> str:
        return (
            f"<PredictionLog type={self.prediction_type.value} "
            f"confidence={self.confidence_score}>"
        )
