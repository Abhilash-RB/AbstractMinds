"""
UsageLog ORM model.

Records per-hour energy consumption for each appliance, including cost
at the tariff rate that was applied and whether the hour was a peak hour.
"""

import uuid
from datetime import date, datetime, timezone

from sqlalchemy import Boolean, Date, DateTime, Float, ForeignKey, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class UsageLog(Base):
    """Hourly energy usage record for a single appliance."""

    __tablename__ = "usage_logs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        index=True,
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    appliance_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("appliances.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    usage_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    hour_of_day: Mapped[int] = mapped_column(Integer, nullable=False)  # 0-23
    units_consumed_kwh: Mapped[float] = mapped_column(Float, nullable=False)
    cost_inr: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    tariff_rate_applied: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    was_peak_hour: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # ── Relationships ───────────────────────────────────────────────────
    user = relationship("User", back_populates="usage_logs")
    appliance = relationship("Appliance", back_populates="usage_logs")

    def __repr__(self) -> str:
        return (
            f"<UsageLog date={self.usage_date} hour={self.hour_of_day} "
            f"kwh={self.units_consumed_kwh}>"
        )
