"""
Tariff ORM model.

Stores DISCOM tariff structures including slab-based pricing, peak/off-peak
hour definitions, and applicable charges and taxes.  Slab data and peak hours
are stored as JSON columns to accommodate varying structures across DISCOMs.
"""

import uuid
from datetime import date, datetime, timezone

from sqlalchemy import Date, DateTime, Float, String
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base


class Tariff(Base):
    """DISCOM tariff configuration for a specific zone and effective date."""

    __tablename__ = "tariffs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        index=True,
    )
    discom_name: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True
    )
    state: Mapped[str] = mapped_column(String(128), nullable=False)
    zone: Mapped[str] = mapped_column(
        String(32), nullable=False, default="urban"
    )  # urban / rural / semi-urban
    effective_from_date: Mapped[date] = mapped_column(Date, nullable=False)

    # JSON: [{"min_units": 0, "max_units": 30, "rate_per_unit": 4.15}, …]
    slab_data: Mapped[dict] = mapped_column(JSON, nullable=False)

    # JSON: [{"start_hour": 6, "end_hour": 10, "multiplier": 1.5}, …]
    peak_hours: Mapped[dict] = mapped_column(JSON, nullable=True)

    off_peak_discount: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    fixed_charges_per_month: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    taxes_percentage: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    def __repr__(self) -> str:
        return f"<Tariff {self.discom_name} zone={self.zone} from={self.effective_from_date}>"
