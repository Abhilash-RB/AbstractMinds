"""
SQLAlchemy ORM models package.

Exports all model classes for convenient imports elsewhere:
    from app.db.models import User, Appliance, UsageLog, Tariff, PredictionLog, Alert
"""

from app.db.models.user import User
from app.db.models.appliance import Appliance, ApplianceCategory
from app.db.models.usage_log import UsageLog
from app.db.models.tariff import Tariff
from app.db.models.prediction_log import PredictionLog, PredictionType
from app.db.models.alert import Alert

__all__ = [
    "User",
    "Appliance",
    "ApplianceCategory",
    "UsageLog",
    "Tariff",
    "PredictionLog",
    "PredictionType",
    "Alert",
]
