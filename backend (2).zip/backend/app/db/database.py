"""
Async database engine, session factory, and dependency injection.

Uses SQLAlchemy 2.0 async API with asyncpg driver for PostgreSQL.
Provides:
    - async_engine : the single AsyncEngine instance
    - AsyncSessionLocal : a sessionmaker bound to the engine
    - Base : declarative base for all ORM models
    - get_db() : FastAPI dependency that yields an AsyncSession
    - create_tables() : creates all tables (for dev / startup)
"""

from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from app.config import get_settings

settings = get_settings()

# ── Async Engine ────────────────────────────────────────────────────────
async_engine = create_async_engine(
    settings.DATABASE_URL,
    echo=(settings.ENVIRONMENT == "dev"),
    pool_size=20,
    max_overflow=10,
    pool_pre_ping=True,
    pool_recycle=3600,
)

# ── Session Factory ─────────────────────────────────────────────────────
AsyncSessionLocal = async_sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


# ── Declarative Base ────────────────────────────────────────────────────
class Base(DeclarativeBase):
    """Declarative base for all ORM models."""
    pass


# ── Dependency ──────────────────────────────────────────────────────────
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency that provides an async database session.

    Yields an AsyncSession and ensures it is closed after use,
    even if the request handler raises an exception.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ── Table Creation ──────────────────────────────────────────────────────
async def create_tables() -> None:
    """
    Create all tables defined by Base.metadata.

    This is intended for development / initial startup.
    In production, use Alembic migrations instead.
    """
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
