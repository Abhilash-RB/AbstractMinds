# ThunderVolts — System Architecture Documentation

> Version 1.0 | Last Updated: 2026-04-28

---

## Overview

ThunderVolts is an AI-powered home energy optimisation platform for Indian households. It provides bill prediction, appliance scheduling, anomaly detection, and conversational energy advice via a FastAPI backend and Next.js frontend.

---

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                          CLIENT LAYER                               │
│  Next.js 16 (App Router)  ·  Mobile Browser  ·  REST / SSE         │
└────────────────────────────────┬────────────────────────────────────┘
                                 │ HTTPS
┌────────────────────────────────▼────────────────────────────────────┐
│                         FASTAPI APPLICATION                          │
│                                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │ /auth        │  │ /predictions │  │ /ai/chat     │              │
│  │ /appliances  │  │ /schedule    │  │ (SSE stream) │              │
│  │ /alerts      │  │ /anomalies   │  │              │              │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘              │
│         │                 │                  │                      │
│  ┌──────▼─────────────────▼──────────────────▼──────────────┐      │
│  │                    SERVICE LAYER                          │      │
│  │  tariff_service  ·  weather_service  ·  report_service   │      │
│  └──────────────────────────┬────────────────────────────────┘      │
│                             │                                        │
│  ┌──────────────────────────▼────────────────────────────────┐      │
│  │                     ML MODEL LAYER                        │      │
│  │  BillPredictor(XGB)  ·  DemandLSTM  ·  AnomalyIForest   │      │
│  │  ScheduleOptimizer                                        │      │
│  └──────────────────────────┬────────────────────────────────┘      │
│                             │                                        │
│  ┌──────────────────────────▼────────────────────────────────┐      │
│  │                      AI LAYER                             │      │
│  │  ClaudeAgent  ·  ContextBuilder  ·  MemoryStore(Redis)   │      │
│  │  Prompt Templates (bill, schedule, anomaly, weekly)       │      │
│  └──────────────────────────┬────────────────────────────────┘      │
│                             │                                        │
│  ┌──────────────────────────▼────────────────────────────────┐      │
│  │                   PERSISTENCE LAYER                       │      │
│  │   PostgreSQL (SQLAlchemy async)  ·  Redis (cache + SSE)  │      │
│  └───────────────────────────────────────────────────────────┘      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagrams

### A. User Bill Prediction Request

```
Client POST /predictions/bill
  │
  ▼
FastAPI router (predictions.py)
  │
  ├─► FeatureStore.get_user_features()  ──►  Redis hit? return cached
  │         │ (miss)
  │         ▼
  ├─► engineer_bill_features(user_data)
  │
  ├─► tariff_service.get_tariff(discom)  ──►  Redis | JSON file
  │
  ├─► BillPredictorModel.predict(features)  ──►  XGBoost inference
  │
  ├─► ClaudeAgent.explain_bill(context)  ──►  Anthropic API (SSE)
  │
  ├─► FeatureStore.store_user_features()  ──►  Redis (TTL 1h)
  │
  └─► Response: {predicted_units, predicted_cost, ai_explanation}
```

### B. Celery Background Jobs Data Flow

```
Redis (Broker)
  │
  ├─► [Every 1h]       refresh_demand_forecast
  │     └─► POSOCO fetch → LSTM inference → FeatureStore.store_demand_forecast()
  │
  ├─► [Daily 00:00]    refresh_tariff_cache
  │     └─► Load DISCOM JSONs → compute 24h profiles → FeatureStore.store_hourly_tariff_profile()
  │
  ├─► [Every 6h]       detect_user_anomalies
  │     └─► DB query (usage logs) → IsolationForest → create Alert in PostgreSQL → notify
  │
  ├─► [Mon 08:00]      generate_weekly_reports
  │     └─► DB aggregate → ClaudeAgent.simple_message() → store Report in DB
  │
  └─► [Sun 02:00]      retrain_anomaly_detector
        └─► DB query (30d logs) → train IsolationForest → save versioned model → update v1
```

### C. Redis Caching Strategy

```
Key Pattern                              TTL        Content
──────────────────────────────────────────────────────────────────────
tv:features:user:{user_id}             3,600s      User feature vector (JSON)
tv:features:tariff:{discom}           86,400s      24h tariff profile (JSON array)
tv:features:forecast:{region}          3,600s      24h demand forecast (JSON array)
tv:chat:session:{session_id}           7,200s      Conversation history (Redis List)
tv:chat:context:{user_id}             86,400s      User energy context (JSON)
──────────────────────────────────────────────────────────────────────
```

### D. ML Model Retraining Pipeline

```
[Weekly Sunday 2 AM IST]
        │
        ▼
PostgreSQL: SELECT usage_logs WHERE created_at > NOW() - 30d
        │
        ▼
train_anomaly.generate_normal_usage_logs() [synthetic top-up if <1000 records]
        │
        ▼
train_anomaly.inject_anomalies(contamination=0.05)
        │
        ▼
IsolationForest.fit(X_train)
        │
        ▼
Evaluate: F1 > 0.75?
   │ YES                         │ NO
   ▼                             ▼
save anomaly_iforest_v{date}.pkl  log warning, keep old model
update anomaly_iforest_v1.pkl
update anomaly_iforest_v1_meta.json
```

---

## API Versioning Strategy

- All API routes are prefixed with `/api/v1/` (configured in `main.py`)
- Breaking changes increment the version prefix: `/api/v2/`
- Non-breaking additions (new optional fields, new endpoints) are deployed without version bump
- Deprecation notices are added to response headers: `X-API-Deprecated: true`
- Old API versions remain active for 6 months after deprecation announcement

---

## Deployment Architecture (Docker Services)

```yaml
services:
  api:
    image: thundervolts-api
    build: ./backend
    ports: ["8000:8000"]
    depends_on: [postgres, redis]
    env_file: .env

  worker:
    image: thundervolts-api
    command: celery -A app.ml.data_pipeline.scheduler_cron.celery_app worker -l info
    depends_on: [redis, postgres]

  beat:
    image: thundervolts-api
    command: celery -A app.ml.data_pipeline.scheduler_cron.celery_app beat -l info
    depends_on: [redis]

  frontend:
    image: thundervolts-frontend
    build: ./frontend
    ports: ["3000:3000"]

  postgres:
    image: postgres:16-alpine
    volumes: [pgdata:/var/lib/postgresql/data]
    environment:
      POSTGRES_DB: thundervolts
      POSTGRES_USER: tv_user
      POSTGRES_PASSWORD: ${DB_PASSWORD}

  redis:
    image: redis:7-alpine
    command: redis-server --maxmemory 512mb --maxmemory-policy allkeys-lru

  nginx:
    image: nginx:alpine
    ports: ["80:80", "443:443"]
    volumes: [./nginx.conf:/etc/nginx/nginx.conf]
    depends_on: [api, frontend]

volumes:
  pgdata:
```

**Service responsibilities:**
| Service | Role |
|---|---|
| `api` | FastAPI ASGI application (uvicorn) |
| `worker` | Celery worker processing async tasks |
| `beat` | Celery beat scheduler (cron replacement) |
| `frontend` | Next.js 16 SSR/App Router server |
| `postgres` | Primary relational database (users, appliances, alerts, reports) |
| `redis` | Feature cache, Celery broker/backend, SSE pub/sub, conversation memory |
| `nginx` | Reverse proxy, SSL termination, static file serving |

---

## Monitoring and Logging Approach

### Logging
- **Framework**: Python `logging` + `uvicorn` access logs
- **Format**: JSON structured logs in production (`{"timestamp", "level", "module", "message", "trace_id"}`)
- **Levels**: DEBUG (dev) → INFO (staging) → WARNING (production)
- **Aggregation**: Logs collected by Docker `json-file` driver; forward to CloudWatch / Loki in production

### Application Monitoring
- **Health endpoint**: `GET /health` — returns DB status, Redis status, model load status
- **Metrics**: FastAPI Prometheus middleware exposes `/metrics` (request count, latency p50/p95/p99, error rate)
- **Alerting**: PagerDuty integration on error_rate > 1% or p99 latency > 2s

### ML Model Monitoring
- `evaluate_models.py` runs weekly after retraining, saves `model_health_report.json`
- If any model FAILS its threshold, a Celery task creates a `high` severity internal alert
- Model versions tracked in `saved_models/*_meta.json` files (version, trained_at, metrics)

### Database
- Slow query logging enabled (queries > 100ms logged to `slow_queries.log`)
- Connection pool monitored via `asyncpg` pool metrics
- Automated daily backups to S3 with 30-day retention

---

## Security Architecture

| Layer | Control |
|---|---|
| Authentication | JWT (HS256, 24h expiry), bcrypt password hashing (rounds=12) |
| Transport | HTTPS enforced via nginx; HSTS header |
| API | CORS restricted to frontend origin; rate limiting (100 req/min per IP) |
| Database | Row-level isolation by `user_id`; parameterised queries via SQLAlchemy |
| Redis | AUTH password required; bind to localhost only |
| Secrets | Environment variables via `.env`; never committed to VCS |
| Claude API | Anthropic key in server-side env only; never exposed to client |
