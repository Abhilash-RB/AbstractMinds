"use client";
import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { authApi, type UserProfile } from "@/lib/api";

interface AuthCtx {
  user: UserProfile | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: Parameters<typeof authApi.register>[0]) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchMe = useCallback(async (tok: string) => {
    try {
      localStorage.setItem("thundervolts_token", tok);
      const me = await authApi.me();
      setUser(me);
      setToken(tok);
    } catch {
      localStorage.removeItem("thundervolts_token");
    }
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("thundervolts_token");
    if (saved) fetchMe(saved).finally(() => setLoading(false));
    else setLoading(false);
  }, [fetchMe]);

  const login = async (email: string, password: string) => {
    const res = await authApi.login(email, password);
    await fetchMe(res.access_token);
  };

  const register = async (data: Parameters<typeof authApi.register>[0]) => {
    const res = await authApi.register(data);
    await fetchMe(res.access_token);
  };

  const logout = () => {
    localStorage.removeItem("thundervolts_token");
    setUser(null);
    setToken(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
