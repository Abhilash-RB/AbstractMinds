"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

// ── Types ─────────────────────────────────────────────────────────────────────
interface User { full_name?: string; email?: string; city?: string; discom_name?: string; }

// ── SVG Icons ─────────────────────────────────────────────────────────────────
const IcoGrid = () => <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>;
const IcoBrain = () => <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/><path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/><path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/><path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/><path d="M3.477 10.896a4 4 0 0 1 .585-.396"/><path d="M19.938 10.5a4 4 0 0 1 .585.396"/><path d="M6 18a4 4 0 0 1-1.967-.516"/><path d="M19.967 17.484A4 4 0 0 1 18 18"/></svg>;
const IcoClock = () => <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h5"/><path d="M17.5 17.5 16 16.3V14"/><circle cx="16" cy="16" r="6"/></svg>;
const IcoMsg = () => <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>;
const IcoAlert = () => <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>;
const IcoPlug = () => <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8H6a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2Z"/></svg>;
const IcoSettings = () => <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>;
const IcoLogout = () => <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>;
const IcoZap = () => <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#F5C842" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>;
const IcoMenu = () => <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>;
const IcoX = () => <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;

// ── Nav config ────────────────────────────────────────────────────────────────
const NAV = [
  { href:"/dashboard",             label:"Dashboard",    Icon:IcoGrid    },
  { href:"/dashboard/predict",     label:"Bill Predictor",Icon:IcoBrain  },
  { href:"/dashboard/schedule",    label:"Scheduler",    Icon:IcoClock   },
  { href:"/dashboard/chat",        label:"AI Advisor",   Icon:IcoMsg     },
  { href:"/dashboard/anomalies",   label:"Anomalies",    Icon:IcoAlert, badge:true },
  { href:"/dashboard/appliances",  label:"Appliances",   Icon:IcoPlug    },
];

// ── Peak widget ───────────────────────────────────────────────────────────────
function PeakWidget(){
  const [now]=useState(()=>new Date().getHours());
  const isPeak=(now>=6&&now<10)||(now>=18&&now<22);
  const rate=isPeak?7.50:3.20;
  const col=isPeak?"#F5C842":"#34d399";
  const shadow=isPeak?"0 0 16px rgba(245,200,66,0.4)":"0 0 16px rgba(52,211,153,0.35)";
  const label=isPeak?"PEAK HOUR":"OFF-PEAK";
  const sub=isPeak?"Avoid heavy appliances":"Good time to run appliances";

  // Progress within current 4-hour window
  let pct=0;
  if(isPeak){
    const windowStart=(now>=18)?18:6;
    pct=((now-windowStart)*60+new Date().getMinutes())/240;
  } else {
    const windowStart=(now>=22)?22:0;
    pct=((now-windowStart)*60+new Date().getMinutes())/480;
  }

  return(
    <div style={{margin:"0.5rem 0.75rem",background:"#0A0A0A",borderRadius:"0.875rem",
      padding:"0.75rem",border:`1px solid ${isPeak?"rgba(245,200,66,0.12)":"rgba(52,211,153,0.12)"}`}}>
      <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:4}}>
        <div style={{width:6,height:6,borderRadius:"50%",background:col,
          boxShadow:`0 0 6px ${col}`,animation:"pulse 2s ease infinite",flexShrink:0}}/>
        <span style={{fontSize:"0.55rem",letterSpacing:"0.15em",fontWeight:700,color:col}}>{label}</span>
      </div>
      <div style={{fontSize:"1.15rem",fontWeight:700,color:col,textShadow:shadow,lineHeight:1}}>
        ₹{rate.toFixed(2)}/unit
      </div>
      <div style={{fontSize:"0.6rem",color:"rgba(225,224,204,0.35)",marginTop:3}}>{sub}</div>
      <div style={{height:3,borderRadius:3,background:"rgba(255,255,255,0.06)",marginTop:8,overflow:"hidden"}}>
        <div style={{height:"100%",borderRadius:3,background:col,
          width:`${Math.min(pct*100,100).toFixed(0)}%`,transition:"width 1s"}}/>
      </div>
    </div>
  );
}

// ── Sidebar inner ─────────────────────────────────────────────────────────────
function SidebarInner({unread,onClose}:{unread:number;onClose?:()=>void}){
  const pathname=usePathname();
  const router=useRouter();

  const [user,setUser]=useState<User|null>(null);
  useEffect(()=>{
    if(typeof window==="undefined")return;
    try{ setUser(JSON.parse(localStorage.getItem("tv_user")??"null")); }catch{}
  },[]);

  const initials=(user?.full_name??"U").split(" ").map(n=>n[0]).slice(0,2).join("").toUpperCase();

  function logout(){
    if(typeof window!=="undefined"){
      localStorage.removeItem("tv_token");
      localStorage.removeItem("tv_user");
    }
    router.replace("/auth");
  }

  return(
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:"#000",
      borderRight:"1px solid rgba(255,255,255,0.06)",fontFamily:"'Almarai',sans-serif"}}>
      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}`}</style>

      {/* Logo */}
      <div style={{padding:"1.1rem 1.25rem",borderBottom:"1px solid rgba(255,255,255,0.06)",
        display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <Link href="/" style={{textDecoration:"none",display:"flex",alignItems:"center",gap:7}}>
          <IcoZap/>
          <span style={{fontSize:"0.875rem",color:"#E1E0CC",letterSpacing:"-0.01em",lineHeight:1}}>
            <strong>THUNDER</strong><span style={{fontWeight:300}}>VOLTS</span>
          </span>
        </Link>
        {onClose&&(
          <button onClick={onClose}
            style={{background:"none",border:"none",color:"rgba(225,224,204,0.3)",cursor:"pointer",display:"flex"}}>
            <IcoX/>
          </button>
        )}
      </div>

      {/* Nav */}
      <nav style={{flex:1,padding:"0.75rem 0.75rem 0"}}>
        <div style={{fontSize:"0.55rem",letterSpacing:"0.15em",color:"rgba(225,224,204,0.2)",
          fontWeight:700,textTransform:"uppercase",padding:"0 0.5rem",marginBottom:"0.5rem"}}>
          MAIN
        </div>
        {NAV.map(({href,label,Icon,badge})=>{
          const active=pathname===href;
          return(
            <Link key={href} href={href}
              onClick={onClose}
              style={{
                display:"flex",alignItems:"center",gap:"0.625rem",
                padding:"0.55rem 0.75rem",borderRadius:"0.625rem",
                textDecoration:"none",marginBottom:"0.125rem",
                position:"relative",transition:"background 0.15s, border-color 0.15s",
                background:active?"rgba(245,200,66,0.07)":"transparent",
                border:active?"1px solid rgba(245,200,66,0.14)":"1px solid transparent",
              }}>
              {/* Active accent */}
              {active&&<div style={{position:"absolute",left:0,top:"50%",transform:"translateY(-50%)",
                width:3,height:16,background:"#F5C842",borderRadius:"0 2px 2px 0"}}/>}
              <span style={{color:active?"#F5C842":"rgba(225,224,204,0.3)",
                transition:"color 0.15s",flexShrink:0,
                marginLeft:active?2:0}}>
                <Icon/>
              </span>
              <span style={{flex:1,fontSize:"0.82rem",fontWeight:active?600:400,
                color:active?"#E1E0CC":"rgba(225,224,204,0.45)"}}>
                {label}
              </span>
              {badge&&unread>0&&(
                <span style={{width:18,height:18,background:"#F5C842",borderRadius:"50%",
                  color:"#000",fontSize:"0.5rem",fontWeight:700,flexShrink:0,
                  display:"flex",alignItems:"center",justifyContent:"center"}}>
                  {unread>9?"9+":unread}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Peak widget */}
      <PeakWidget/>

      {/* Bottom */}
      <div style={{padding:"0 0.75rem 0.75rem",borderTop:"1px solid rgba(255,255,255,0.06)",paddingTop:"0.625rem"}}>
        {/* Settings */}
        <Link href="/dashboard/settings" onClick={onClose}
          style={{display:"flex",alignItems:"center",gap:"0.625rem",
            padding:"0.55rem 0.75rem",borderRadius:"0.625rem",textDecoration:"none",
            marginBottom:"0.125rem",transition:"background 0.15s",
            background:pathname==="/dashboard/settings"?"rgba(245,200,66,0.07)":"transparent",
            border:pathname==="/dashboard/settings"?"1px solid rgba(245,200,66,0.14)":"1px solid transparent"}}>
          <span style={{color:pathname==="/dashboard/settings"?"#F5C842":"rgba(225,224,204,0.3)"}}>
            <IcoSettings/>
          </span>
          <span style={{fontSize:"0.82rem",color:pathname==="/dashboard/settings"?"#E1E0CC":"rgba(225,224,204,0.45)"}}>
            Settings
          </span>
        </Link>

        {/* User row */}
        <div style={{display:"flex",alignItems:"center",gap:"0.625rem",
          padding:"0.55rem 0.75rem",borderRadius:"0.625rem",cursor:"pointer",
          transition:"background 0.15s",marginTop:"0.125rem"}}
          onMouseEnter={e=>(e.currentTarget.style.background="rgba(255,255,255,0.03)")}
          onMouseLeave={e=>(e.currentTarget.style.background="transparent")}>
          <div style={{width:28,height:28,borderRadius:"50%",flexShrink:0,
            background:"rgba(245,200,66,0.15)",border:"1px solid rgba(245,200,66,0.3)",
            display:"flex",alignItems:"center",justifyContent:"center",
            fontSize:"0.6rem",fontWeight:700,color:"#F5C842"}}>
            {initials}
          </div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:"0.75rem",color:"rgba(225,224,204,0.75)",fontWeight:600,
              overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
              {user?.full_name??"User"}
            </div>
            <div style={{fontSize:"0.58rem",color:"rgba(225,224,204,0.3)",
              overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
              {user?.discom_name??"BESCOM"} · {user?.city??"Bangalore"}
            </div>
          </div>
          <button onClick={logout}
            style={{background:"none",border:"none",cursor:"pointer",
              color:"rgba(225,224,204,0.2)",display:"flex",transition:"color 0.15s",flexShrink:0}}
            onMouseEnter={e=>(e.currentTarget.style.color="#f87171")}
            onMouseLeave={e=>(e.currentTarget.style.color="rgba(225,224,204,0.2)")}>
            <IcoLogout/>
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Exported Sidebar (desktop + mobile) ───────────────────────────────────────
export default function Sidebar({unread=0}:{unread?:number}){
  const [mobileOpen,setMobileOpen]=useState(false);

  return(
    <>
      {/* Desktop */}
      <aside style={{position:"fixed",left:0,top:0,bottom:0,width:224,zIndex:40,
        display:"flex",flexDirection:"column"}}>
        <SidebarInner unread={unread}/>
      </aside>

      {/* Mobile hamburger button */}
      <button
        onClick={()=>setMobileOpen(true)}
        style={{position:"fixed",top:14,left:14,zIndex:50,
          background:"rgba(0,0,0,0.8)",border:"1px solid rgba(255,255,255,0.08)",
          borderRadius:"0.5rem",padding:"0.4rem",cursor:"pointer",
          color:"rgba(225,224,204,0.6)",display:"none",
          fontFamily:"'Almarai',sans-serif"}}
        className="sidebar-hamburger">
        <IcoMenu/>
      </button>

      {/* Mobile drawer */}
      {mobileOpen&&(
        <>
          <div onClick={()=>setMobileOpen(false)}
            style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.65)",
              backdropFilter:"blur(4px)",zIndex:45}}/>
          <aside style={{position:"fixed",left:0,top:0,bottom:0,width:224,zIndex:50,
            animation:"slideIn 0.25s ease",display:"flex",flexDirection:"column"}}>
            <style>{`@keyframes slideIn{from{transform:translateX(-224px)}to{transform:translateX(0)}}`}</style>
            <SidebarInner unread={unread} onClose={()=>setMobileOpen(false)}/>
          </aside>
        </>
      )}

      {/* Hide hamburger on desktop via global css */}
      <style>{`
        @media(min-width:768px){.sidebar-hamburger{display:none!important}}
        @media(max-width:767px){.sidebar-hamburger{display:flex!important}}
      `}</style>
    </>
  );
}
