// ── ThunderVolts API Client ───────────────────────────────────────────
const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("thundervolts_token");
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || "Request failed");
  }
  return res.json();
}

// ── Auth ──────────────────────────────────────────────────────────────
export interface LoginResponse {
  access_token: string;
  token_type: string;
}
export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  city: string;
  state: string;
  discom_name: string;
  is_rural: boolean;
  household_size: number;
}

export const authApi = {
  login: (email: string, password: string) =>
    request<LoginResponse>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  register: (data: {
    email: string;
    password: string;
    full_name: string;
    city: string;
    discom_name: string;
    household_size: number;
    is_rural: boolean;
  }) => request<LoginResponse>("/auth/register", { method: "POST", body: JSON.stringify(data) }),
  me: () => request<UserProfile>("/auth/me"),
};

// ── Predictions ────────────────────────────────────────────────────────
export interface ApplianceItem {
  name: string;
  wattage_watts: number;
  avg_daily_usage_hours: number;
  category: string;
  is_schedulable: boolean;
  preferred_start_hour: number;
  preferred_end_hour: number;
}

export interface BillPredictRequest {
  appliances: ApplianceItem[];
  city: string;
  month: number;
  household_size: number;
  previous_month_units: number;
}

export interface BillPredictResponse {
  prediction: {
    predicted_cost_inr: number;
    predicted_units_kwh: number;
    breakdown: Record<string, number>;
    confidence_score?: number;
    model_version?: string;
  };
  ai_explanation: string;
}

export interface ScheduleRequest {
  date: string;
  appliances: ApplianceItem[];
  avoid_hours: number[];
  prefer_hours: number[];
}

export interface ScheduleResponse {
  schedule: {
    date: string;
    assignments: Array<{
      appliance_name: string;
      start_hour: number;
      end_hour: number;
      estimated_cost_inr: number;
    }>;
    total_estimated_cost_inr: number;
    total_savings_inr: number;
  };
  ai_reasoning: string;
}

export interface PeakHoursResponse {
  peak_hours: number[];
  off_peak_hours: number[];
  hourly_rates: Array<{ hour: number; rate_inr_per_unit: number }>;
}

export interface AnomalyResponse {
  anomalies: Array<{
    appliance_name: string;
    anomaly_type: string;
    description: string;
    severity: "low" | "medium" | "high";
    detected_kwh: number;
    baseline_kwh: number;
    extra_cost_inr: number;
  }>;
}

export const predictApi = {
  bill: (data: BillPredictRequest) =>
    request<BillPredictResponse>("/predictions/bill", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  schedule: (data: ScheduleRequest) =>
    request<ScheduleResponse>("/predictions/schedule", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  peakHours: () => request<PeakHoursResponse>("/predictions/peak-hours"),
  anomalies: () => request<AnomalyResponse>("/predictions/anomalies"),
};

// ── Appliances ─────────────────────────────────────────────────────────
export interface Appliance {
  id: string;
  name: string;
  wattage_watts: number;
  avg_daily_usage_hours: number;
  category: string;
  is_schedulable: boolean;
  preferred_start_hour: number;
  preferred_end_hour: number;
}

export const applianceApi = {
  list: () => request<Appliance[]>("/appliances"),
  create: (data: Omit<Appliance, "id">) =>
    request<Appliance>("/appliances", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: Partial<Appliance>) =>
    request<Appliance>(`/appliances/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) =>
    request<void>(`/appliances/${id}`, { method: "DELETE" }),
};

// ── AI Chat ─────────────────────────────────────────────────────────────
export const chatApi = {
  sendMessage: async (
    message: string,
    sessionId: string,
    onChunk: (chunk: string) => void,
    onDone: () => void
  ) => {
    const token = getToken();
    const res = await fetch(`${API_BASE}/ai/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ message, session_id: sessionId }),
    });
    const reader = res.body?.getReader();
    const decoder = new TextDecoder();
    if (!reader) return;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const text = decoder.decode(value);
      const lines = text.split("\n").filter((l) => l.startsWith("data: "));
      for (const line of lines) {
        try {
          const data = JSON.parse(line.slice(6));
          if (data.content) onChunk(data.content);
          if (data.done) onDone();
        } catch {}
      }
    }
  },
};
