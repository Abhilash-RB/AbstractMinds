"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    // Auth guard — read from localStorage key written by auth page
    const token =
      localStorage.getItem("tv_token") ||
      localStorage.getItem("thundervolts_token");

    if (!token) {
      router.replace("/auth");
      return;
    }

    setReady(true);

    // Fetch unread alert count for badge
    fetch("/api/v1/alerts/count", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.ok ? r.json() : null)
      .then((d) => { if (d?.unread_count != null) setUnread(d.unread_count); })
      .catch(() => {
        // Demo fallback — show 2 unread alerts
        setUnread(2);
      });
  }, [router]);

  // Loading / redirect state — show minimal spinner
  if (!ready) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#000",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: "'Almarai', sans-serif",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <svg
            style={{ animation: "spin 1s linear infinite", display: "block", margin: "0 auto 1rem" }}
            width={28}
            height={28}
            viewBox="0 0 24 24"
            fill="none"
            stroke="#F5C842"
            strokeWidth={2.5}
            strokeLinecap="round"
          >
            <path d="M21 12a9 9 0 1 1-6.219-8.56" />
          </svg>
          <div style={{ fontSize: "0.75rem", color: "rgba(225,224,204,0.25)" }}>
            Loading ThunderVolts…
          </div>
        </div>
        <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#000",
        display: "flex",
        fontFamily: "'Almarai', sans-serif",
      }}
    >
      {/* Fixed left sidebar — 224px wide on desktop */}
      <Sidebar unread={unread} />

      {/* Main content — offset by sidebar width on desktop */}
      <main
        style={{
          flex: 1,
          marginLeft: 224,
          minHeight: "100vh",
          background: "#000",
          overflowX: "hidden",
        }}
        className="dashboard-main"
      >
        {children}
      </main>

      {/* Mobile: collapse sidebar margin */}
      <style>{`
        @media(max-width:767px){
          .dashboard-main{margin-left:0!important}
        }
      `}</style>
    </div>
  );
}
