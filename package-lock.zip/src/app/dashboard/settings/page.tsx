"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// ── Styles ────────────────────────────────────────────────────────────────────
const NOISE=`url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E")`;
const CARD:React.CSSProperties={background:`${NOISE}, #1A1A1A`,border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.875rem",padding:"1.5rem",marginBottom:"1rem"};
const MUTED:React.CSSProperties={color:"rgba(225,224,204,0.4)",fontSize:"0.72rem"};
const INPUT_S:React.CSSProperties={width:"100%",background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:"0.625rem",padding:"0.65rem 1rem",color:"#E1E0CC",fontSize:"0.85rem",outline:"none",boxSizing:"border-box",fontFamily:"'Almarai',sans-serif"};
const SEL_S:React.CSSProperties={...INPUT_S,appearance:"none",cursor:"pointer"};
const LBL:React.CSSProperties={...MUTED,display:"block",marginBottom:5};
const SEC:React.CSSProperties={fontSize:"0.6rem",letterSpacing:"0.1em",textTransform:"uppercase",color:"rgba(245,200,66,0.6)",fontWeight:700,display:"block",marginBottom:"0.875rem"};

const STATES=["Karnataka","Maharashtra","Delhi","Tamil Nadu","Telangana","Andhra Pradesh","Gujarat","West Bengal","Uttar Pradesh","Rajasthan","Punjab","Haryana","Kerala","Madhya Pradesh"];
const DISCOMS=["BESCOM","HESCOM","MESCOM","MSEDCL","Tata Power","BSES Rajdhani","BSES Yamuna","TPDDL","TANGEDCO","TSSPDCL","TSNPDCL","APEPDCL","KSEB","PSPCL"];

// ── Section header ────────────────────────────────────────────────────────────
function SectionHead({title,sub}:{title:string;sub:string}){
  return(
    <div style={{marginBottom:"1.25rem"}}>
      <div style={{fontSize:"0.92rem",fontWeight:600,color:"#E1E0CC",marginBottom:3}}>{title}</div>
      <div style={MUTED}>{sub}</div>
    </div>
  );
}

// ── Toggle switch ─────────────────────────────────────────────────────────────
function Toggle({on,onChange,label,sub}:{on:boolean;onChange:(v:boolean)=>void;label:string;sub?:string}){
  return(
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",
      padding:"0.75rem 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
      <div>
        <div style={{fontSize:"0.82rem",color:"#E1E0CC"}}>{label}</div>
        {sub&&<div style={MUTED}>{sub}</div>}
      </div>
      <div onClick={()=>onChange(!on)}
        style={{width:40,height:22,borderRadius:11,background:on?"#F5C842":"rgba(255,255,255,0.1)",
          position:"relative",cursor:"pointer",transition:"background 0.2s",flexShrink:0}}>
        <div style={{position:"absolute",top:3,left:on?18:3,width:16,height:16,borderRadius:"50%",
          background:on?"#000":"rgba(255,255,255,0.5)",transition:"left 0.2s"}}/>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function SettingsPage(){
  const router=useRouter();

  // Load user from localStorage (matches auth page token key)
  const [user,setUser]=useState<{full_name?:string;email?:string;city?:string;discom_name?:string}|null>(null);
  useEffect(()=>{
    if(typeof window==="undefined") return;
    try{ setUser(JSON.parse(localStorage.getItem("tv_user")??"null")); }catch{}
  },[]);

  const [name,setName]=useState("Arjun Sharma");
  const [city,setCity]=useState("Bangalore");
  const [state,setState]=useState("Karnataka");
  const [discom,setDiscom]=useState("BESCOM");
  const [isRural,setIsRural]=useState(false);

  // Sync user data into form once loaded
  useEffect(()=>{
    if(user){
      if(user.full_name) setName(user.full_name);
      if(user.city) setCity(user.city);
      if(user.discom_name) setDiscom(user.discom_name);
    }
  },[user]);

  const [notifPeak,setNotifPeak]=useState(true);
  const [notifAnomaly,setNotifAnomaly]=useState(true);
  const [notifWeekly,setNotifWeekly]=useState(true);
  const [notifBill,setNotifBill]=useState(false);

  const [darkMode,setDarkMode]=useState(true);
  const [compactView,setCompactView]=useState(false);
  const [aiInsights,setAiInsights]=useState(true);

  const [saving,setSaving]=useState(false);
  const [saved,setSaved]=useState(false);
  const [activeTab,setActiveTab]=useState<"profile"|"notifications"|"display"|"account">("profile");

  async function save(){
    setSaving(true);
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    try{
      await fetch("/api/v1/auth/me",{
        method:"PATCH",
        headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},
        body:JSON.stringify({full_name:name,city,state,discom_name:discom,is_rural:isRural}),
      });
    }catch{}
    setSaving(false);setSaved(true);
    setTimeout(()=>setSaved(false),2500);
  }

  function handleLogout(){
    if(typeof window!=="undefined"){
      localStorage.removeItem("tv_token");
      localStorage.removeItem("tv_user");
      localStorage.removeItem("thundervolts_token");
    }
    router.replace("/auth");
  }

  const TABS=[
    {id:"profile",label:"Profile"},
    {id:"notifications",label:"Notifications"},
    {id:"display",label:"Display"},
    {id:"account",label:"Account"},
  ] as const;

  return(
    <div style={{background:"#000",minHeight:"100vh",color:"#E1E0CC",
      fontFamily:"'Almarai',sans-serif",padding:"1.5rem"}}>
      <style>{`
        input,select{font-family:'Almarai',sans-serif}
        input::placeholder{color:rgba(225,224,204,0.2)}
        select option{background:#111}
        @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
      `}</style>

      {/* Breadcrumb + header */}
      <div style={{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.875rem"}}>
        <Link href="/dashboard" style={{...MUTED,textDecoration:"none"}}>Dashboard</Link>
        <span style={{color:"rgba(225,224,204,0.2)"}}>›</span>
        <span style={{...MUTED,color:"rgba(225,224,204,0.6)"}}>Settings</span>
      </div>
      <div style={{marginBottom:"1.5rem"}}>
        <h1 style={{fontSize:"1.5rem",fontWeight:700,color:"#E1E0CC",margin:0}}>Settings</h1>
        <p style={{...MUTED,marginTop:3}}>Manage your profile, notifications, and preferences</p>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"200px 1fr",gap:"1rem",alignItems:"start"}}>

        {/* Sidebar tabs */}
        <div style={{...CARD,padding:"0.5rem"}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setActiveTab(t.id)}
              style={{width:"100%",textAlign:"left",padding:"0.6rem 0.875rem",
                borderRadius:"0.5rem",border:"none",cursor:"pointer",
                fontSize:"0.82rem",fontFamily:"'Almarai',sans-serif",transition:"all 0.15s",
                background:activeTab===t.id?"rgba(245,200,66,0.08)":"transparent",
                color:activeTab===t.id?"#F5C842":"rgba(225,224,204,0.5)",
                borderLeft:activeTab===t.id?"2px solid #F5C842":"2px solid transparent",
                display:"block",marginBottom:2}}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div style={{animation:"fadeUp 0.25s ease"}}>

          {/* PROFILE */}
          {activeTab==="profile"&&(
            <div style={CARD}>
              <SectionHead title="Profile Information" sub="Update your personal details and energy setup"/>
              <span style={SEC}>Personal</span>
              <div style={{marginBottom:"0.875rem"}}>
                <label style={LBL}>Full Name</label>
                <input value={name} onChange={e=>setName(e.target.value)} style={INPUT_S} placeholder="Your name"/>
              </div>
              <div style={{marginBottom:"0.875rem"}}>
                <label style={LBL}>Email</label>
                <input value={user?.email??"demo@thundervolts.in"} disabled
                  style={{...INPUT_S,opacity:0.5,cursor:"not-allowed"}}/>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:"0.875rem"}}>
                <div>
                  <label style={LBL}>City</label>
                  <input value={city} onChange={e=>setCity(e.target.value)} style={INPUT_S} placeholder="Bangalore"/>
                </div>
                <div>
                  <label style={LBL}>State</label>
                  <select value={state} onChange={e=>setState(e.target.value)} style={SEL_S}>
                    {STATES.map(s=><option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div style={{marginBottom:"0.875rem"}}>
                <label style={LBL}>DISCOM (Electricity Provider)</label>
                <select value={discom} onChange={e=>setDiscom(e.target.value)} style={SEL_S}>
                  {DISCOMS.map(d=><option key={d}>{d}</option>)}
                </select>
              </div>
              <div style={{marginBottom:"1.25rem"}}>
                <label style={LBL}>Area Type</label>
                <div style={{display:"flex",gap:6}}>
                  {["Urban","Semi-Urban","Rural"].map(a=>(
                    <button key={a} onClick={()=>setIsRural(a==="Rural")}
                      style={{padding:"6px 16px",borderRadius:999,border:"1px solid",fontSize:"0.75rem",
                        cursor:"pointer",fontFamily:"'Almarai',sans-serif",
                        background:(a==="Rural"&&isRural)||(a!=="Rural"&&!isRural&&a==="Urban")?
                          "rgba(245,200,66,0.1)":"transparent",
                        borderColor:(a==="Rural"&&isRural)||(a!=="Rural"&&!isRural&&a==="Urban")?
                          "rgba(245,200,66,0.35)":"rgba(255,255,255,0.08)",
                        color:(a==="Rural"&&isRural)||(a!=="Rural"&&!isRural&&a==="Urban")?
                          "#F5C842":"rgba(225,224,204,0.4)"}}>
                      {a}
                    </button>
                  ))}
                </div>
              </div>
              <button onClick={save} disabled={saving}
                style={{background:saved?"#34d399":"#F5C842",color:"#000",border:"none",
                  borderRadius:"0.625rem",padding:"0.7rem 1.5rem",fontWeight:700,
                  fontSize:"0.85rem",cursor:"pointer",fontFamily:"'Almarai',sans-serif",
                  transition:"background 0.3s",opacity:saving?0.8:1}}>
                {saving?"Saving…":saved?"✓ Saved":"Save Changes"}
              </button>
            </div>
          )}

          {/* NOTIFICATIONS */}
          {activeTab==="notifications"&&(
            <div style={CARD}>
              <SectionHead title="Notification Preferences" sub="Control what alerts ThunderVolts sends you"/>
              <span style={SEC}>Alerts</span>
              <Toggle on={notifPeak} onChange={setNotifPeak}
                label="Peak Hour Warnings" sub="Alert 30 min before peak rates begin"/>
              <Toggle on={notifAnomaly} onChange={setNotifAnomaly}
                label="Anomaly Alerts" sub="Notify when unusual appliance usage is detected"/>
              <Toggle on={notifBill} onChange={setNotifBill}
                label="Bill Threshold Alert" sub="Warn when estimated bill exceeds ₹2,000"/>
              <div style={{marginTop:"1rem"}}/>
              <span style={SEC}>Reports</span>
              <Toggle on={notifWeekly} onChange={setNotifWeekly}
                label="Weekly Energy Report" sub="AI-generated summary every Monday morning"/>
            </div>
          )}

          {/* DISPLAY */}
          {activeTab==="display"&&(
            <div style={CARD}>
              <SectionHead title="Display Preferences" sub="Customize how your dashboard looks"/>
              <span style={SEC}>Appearance</span>
              <Toggle on={darkMode} onChange={setDarkMode}
                label="Dark Mode" sub="Always active in ThunderVolts"/>
              <Toggle on={compactView} onChange={setCompactView}
                label="Compact View" sub="Smaller cards and reduced padding"/>
              <Toggle on={aiInsights} onChange={setAiInsights}
                label="AI Insights on Dashboard" sub="Show AI tip card on main dashboard"/>
            </div>
          )}

          {/* ACCOUNT */}
          {activeTab==="account"&&(
            <div>
              <div style={CARD}>
                <SectionHead title="Account" sub="Manage your ThunderVolts account"/>
                <span style={SEC}>Security</span>
                <div style={{marginBottom:"0.875rem"}}>
                  <label style={LBL}>New Password</label>
                  <input type="password" placeholder="Leave blank to keep current"
                    style={INPUT_S}/>
                </div>
                <div style={{marginBottom:"1.25rem"}}>
                  <label style={LBL}>Confirm Password</label>
                  <input type="password" placeholder="Repeat new password" style={INPUT_S}/>
                </div>
                <button style={{background:"rgba(245,200,66,0.08)",border:"1px solid rgba(245,200,66,0.2)",
                  borderRadius:"0.625rem",padding:"0.65rem 1.25rem",color:"#F5C842",
                  fontWeight:600,fontSize:"0.82rem",cursor:"pointer",fontFamily:"'Almarai',sans-serif"}}>
                  Update Password
                </button>
              </div>

              <div style={{...CARD,border:"1px solid rgba(248,113,113,0.15)",
                background:`${NOISE}, rgba(248,113,113,0.03)`}}>
                <span style={{...SEC,color:"rgba(248,113,113,0.6)"}}>Danger Zone</span>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",
                  marginBottom:"0.875rem"}}>
                  <div>
                    <div style={{fontSize:"0.82rem",color:"#E1E0CC"}}>Sign Out</div>
                    <div style={MUTED}>Log out of this device</div>
                  </div>
                  <button onClick={handleLogout}
                    style={{background:"rgba(248,113,113,0.1)",border:"1px solid rgba(248,113,113,0.25)",
                      borderRadius:"0.5rem",padding:"0.5rem 1rem",color:"#f87171",
                      fontSize:"0.78rem",fontWeight:600,cursor:"pointer",fontFamily:"'Almarai',sans-serif"}}>
                    Sign Out
                  </button>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",
                  paddingTop:"0.875rem",borderTop:"1px solid rgba(255,255,255,0.04)"}}>
                  <div>
                    <div style={{fontSize:"0.82rem",color:"#f87171"}}>Delete Account</div>
                    <div style={MUTED}>Permanently delete all your data</div>
                  </div>
                  <button style={{background:"rgba(248,113,113,0.08)",border:"1px solid rgba(248,113,113,0.2)",
                    borderRadius:"0.5rem",padding:"0.5rem 1rem",color:"rgba(248,113,113,0.7)",
                    fontSize:"0.78rem",cursor:"pointer",fontFamily:"'Almarai',sans-serif"}}>
                    Delete
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
