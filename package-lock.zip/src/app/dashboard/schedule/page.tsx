"use client";
import { useState, useRef } from "react";
import Link from "next/link";

// ── Types & constants ─────────────────────────────────────────────────────────
interface HourRate { hour: number; rate: number; is_peak: boolean; }
interface Scheduled { id: string; icon: string; name: string; watts: number; duration: number; startHour: number; prefStart: number; savings: number; reason: string; }

const HOURS: HourRate[] = Array.from({length:24},(_,h)=>({
  hour:h,
  rate:(h>=6&&h<10)||(h>=18&&h<22)?7.50:h>=10&&h<18?5.50:3.50,
  is_peak:(h>=6&&h<10)||(h>=18&&h<22),
}));

const APPLIANCES_INIT = [
  {id:"ac",   icon:"❄️", name:"AC 1.5T",      watts:1500, duration:6,  prefStart:14, on:true},
  {id:"gey",  icon:"🚿", name:"Geyser",        watts:2000, duration:1,  prefStart:7,  on:true},
  {id:"wash", icon:"🫧", name:"Washer",         watts:800,  duration:2,  prefStart:9,  on:true},
  {id:"ev",   icon:"🔌", name:"EV Charger",     watts:3300, duration:5,  prefStart:21, on:false},
];

const DEMO_SCHEDULE: Scheduled[] = [
  {id:"ac",  icon:"❄️",name:"AC 1.5T", watts:1500,duration:6,startHour:23,prefStart:14,savings:24.30,reason:"Off-peak rate ₹3.50 vs peak ₹7.50 — saves ₹24"},
  {id:"gey", icon:"🚿",name:"Geyser",  watts:2000,duration:1,startHour:5, prefStart:7, savings:8.00, reason:"Cheapest window (₹3.50) just before morning peak at 6 AM"},
  {id:"wash",icon:"🫧",name:"Washer",  watts:800, duration:2,startHour:11,prefStart:9, savings:7.84, reason:"Shoulder rate ₹5.50 avoids ₹7.50 peak — saves ₹7.84"},
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const NOISE=`url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E")`;
const CARD:React.CSSProperties={background:`${NOISE}, #1A1A1A`,border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.875rem",padding:"1.25rem"};
const MUTED:React.CSSProperties={color:"rgba(225,224,204,0.4)",fontSize:"0.72rem"};
const SEC_LBL:React.CSSProperties={fontSize:"0.6rem",letterSpacing:"0.1em",textTransform:"uppercase",color:"rgba(245,200,66,0.6)",fontWeight:700,display:"block",marginBottom:"0.6rem"};

function fmt(h:number){return h===0?"12AM":h<12?`${h}AM`:h===12?"12PM":h===23?"11PM":`${h-12}PM`;}

// ── Rate bar chart ────────────────────────────────────────────────────────────
function RateBars({rates}:{rates:HourRate[]}){
  const [tip,setTip]=useState<{h:number;r:number;x:number}|null>(null);
  const maxR=Math.max(...rates.map(r=>r.rate));
  return(
    <div style={{position:"relative"}}>
      <div style={{display:"flex",gap:3,alignItems:"flex-end",height:60}}>
        {rates.map((r,i)=>{
          const pct=r.rate/maxR;
          const col=r.is_peak?"rgba(245,200,66,0.82)":r.rate<4?"rgba(52,211,153,0.45)":"rgba(245,200,66,0.3)";
          return(
            <div key={r.hour} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",position:"relative"}}
              onMouseEnter={e=>{const b=(e.currentTarget as HTMLElement).getBoundingClientRect();setTip({h:r.hour,r:r.rate,x:i});}}
              onMouseLeave={()=>setTip(null)}>
              {/* PEAK badge */}
              {(r.hour===6||r.hour===18)&&(
                <span style={{position:"absolute",top:-16,fontSize:"0.45rem",color:"#F5C842",fontWeight:700,letterSpacing:"0.06em",whiteSpace:"nowrap"}}>PEAK</span>
              )}
              <div style={{width:"100%",background:col,borderRadius:"2px 2px 0 0",
                height:`${Math.max(pct*56,4)}px`,transition:"height 0.3s"}}/>
            </div>
          );
        })}
      </div>
      {/* Hour labels */}
      <div style={{display:"flex",marginTop:4}}>
        {[0,3,6,9,12,15,18,21].map(h=>(
          <div key={h} style={{flex:3,...MUTED,fontSize:"0.55rem",textAlign:"left",minWidth:0}}>
            {fmt(h)}
          </div>
        ))}
      </div>
      {/* Tooltip */}
      {tip&&(
        <div style={{position:"absolute",top:-36,left:`${(tip.x/24)*100}%`,transform:"translateX(-50%)",
          background:"#1A1A1A",border:"1px solid rgba(245,200,66,0.3)",borderRadius:6,
          padding:"4px 8px",fontSize:"0.65rem",color:"#E1E0CC",whiteSpace:"nowrap",zIndex:10,pointerEvents:"none"}}>
          {fmt(tip.h)} · <span style={{color:"#F5C842"}}>₹{tip.r.toFixed(2)}/unit</span>
        </div>
      )}
    </div>
  );
}

// ── Gantt chart ───────────────────────────────────────────────────────────────
function GanttChart({schedule,rates}:{schedule:Scheduled[];rates:HourRate[]}){
  const [tip,setTip]=useState<{s:Scheduled;mx:number;my:number}|null>(null);
  const W=100, ROW=40, PAD_Y=24, PAD_X=0;
  const viewH=PAD_Y+schedule.length*ROW+PAD_Y;
  const toX=(h:number)=>PAD_X+(h/24)*W;
  const peakZones=[[6,10],[18,22]];
  const xLabels=[0,3,6,9,12,15,18,21,24];

  return(
    <div style={{position:"relative",overflowX:"auto"}}>
      <svg viewBox={`0 0 ${W} ${viewH}`} width="100%" preserveAspectRatio="none"
        style={{display:"block",minWidth:480}}>
        {/* Peak zone shading */}
        {peakZones.map(([s,e],i)=>(
          <rect key={i} x={toX(s)} y={0} width={toX(e)-toX(s)} height={viewH}
            fill="rgba(245,200,66,0.06)"/>
        ))}
        {/* PEAK labels */}
        {peakZones.map(([s],i)=>(
          <text key={i} x={toX(s)+0.5} y={10} fill="rgba(245,200,66,0.4)"
            fontSize={2.2} fontWeight={700} letterSpacing={0.3}>PEAK</text>
        ))}
        {/* X-axis hour lines */}
        {xLabels.map(h=>(
          <g key={h}>
            <line x1={toX(h)} y1={PAD_Y-4} x2={toX(h)} y2={viewH-PAD_Y+4}
              stroke="rgba(255,255,255,0.04)" strokeWidth={0.3}/>
            <text x={toX(h)} y={viewH-PAD_Y+10} fill="rgba(225,224,204,0.25)"
              fontSize={2.2} textAnchor="middle">{h===0?"12AM":h===12?"12PM":h<12?`${h}AM`:h===24?"12AM":`${h-12}PM`}</text>
          </g>
        ))}
        {/* Rows */}
        {schedule.map((s,rowIdx)=>{
          const y=PAD_Y+rowIdx*ROW;
          const bx=toX(s.startHour);
          const bw=toX(s.startHour+s.duration)-bx;
          const px=toX(s.prefStart);
          const pw=toX(s.prefStart+s.duration)-px;
          return(
            <g key={s.id}>
              {/* Row label */}
              <text x={0.5} y={y+ROW/2+1} fill="rgba(225,224,204,0.5)" fontSize={2.8} dominantBaseline="middle">{s.name}</text>
              {/* Track */}
              <rect x={toX(0)} y={y+4} width={W} height={ROW-8} rx={1.5} fill="rgba(255,255,255,0.025)"/>
              {/* Preferred time ghost */}
              <rect x={px} y={y+6} width={pw} height={ROW-12} rx={1.2}
                fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth={0.4} strokeDasharray="1.5,1"/>
              {/* Optimised block */}
              <rect x={bx} y={y+5} width={bw} height={ROW-10} rx={1.5}
                fill="rgba(245,200,66,0.78)" style={{cursor:"pointer"}}
                onMouseEnter={(e)=>setTip({s,mx:e.clientX,my:e.clientY})}
                onMouseLeave={()=>setTip(null)}/>
              <text x={bx+bw/2} y={y+ROW/2+1} fill="#000" fontSize={2.4} textAnchor="middle"
                dominantBaseline="middle" fontWeight={700} style={{pointerEvents:"none"}}>
                {s.icon} {fmt(s.startHour)}
              </text>
            </g>
          );
        })}
      </svg>
      {/* SVG-external tooltip */}
      {tip&&(
        <div style={{position:"fixed",top:tip.my-60,left:tip.mx-80,
          background:"#1A1A1A",border:"1px solid rgba(245,200,66,0.3)",borderRadius:8,
          padding:"8px 12px",fontSize:"0.7rem",color:"#E1E0CC",zIndex:50,
          boxShadow:"0 4px 24px rgba(0,0,0,0.6)",pointerEvents:"none",maxWidth:220}}>
          <div style={{fontWeight:700,marginBottom:3}}>{tip.s.icon} {tip.s.name}</div>
          <div style={{color:"rgba(225,224,204,0.5)"}}>
            {fmt(tip.s.startHour)} → {fmt((tip.s.startHour+tip.s.duration)%24)}
          </div>
          <div style={{color:"#34d399",marginTop:2}}>Saves ₹{tip.s.savings.toFixed(2)}</div>
        </div>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function SchedulePage(){
  const today=new Date();
  const [dayOffset,setDayOffset]=useState(0);
  const [appliances,setAppliances]=useState(APPLIANCES_INIT);
  const [loading,setLoading]=useState(false);
  const [schedule,setSchedule]=useState<Scheduled[]>(DEMO_SCHEDULE);
  const [optimised,setOptimised]=useState(false);

  const displayDate=new Date(today);
  displayDate.setDate(today.getDate()+dayOffset);
  const dateStr=displayDate.toLocaleDateString("en-IN",{weekday:"short",day:"numeric",month:"short"});

  function toggleAppl(id:string){
    setAppliances(a=>a.map(x=>x.id===id?{...x,on:!x.on}:x));
  }

  async function optimise(){
    setLoading(true);
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    const body={
      appliances:appliances.filter(a=>a.on).map(a=>({
        name:a.name,wattage_watts:a.watts,avg_daily_usage_hours:a.duration,
        is_schedulable:true,preferred_start_hour:a.prefStart,preferred_end_hour:23,
      })),
      date:displayDate.toISOString().split("T")[0],
    };
    try{
      const r=await fetch("/api/v1/predictions/schedule",{
        method:"POST",
        headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},
        body:JSON.stringify(body),
      });
      if(r.ok){const d=await r.json();if(d.schedule)setSchedule(d.schedule);}
      else setSchedule(DEMO_SCHEDULE);
    }catch{setSchedule(DEMO_SCHEDULE);}
    setLoading(false);
    setOptimised(true);
  }

  const totalSavings=schedule.filter(s=>appliances.find(a=>a.id===s.id)?.on).reduce((acc,s)=>acc+s.savings,0);

  return(
    <div style={{background:"#000",minHeight:"100vh",color:"#E1E0CC",fontFamily:"'Almarai',sans-serif",padding:"1.5rem"}}>

      {/* Page header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"1.25rem"}}>
        <div>
          <div style={{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.2rem"}}>
            <Link href="/dashboard" style={{...MUTED,textDecoration:"none"}}>Dashboard</Link>
            <span style={{color:"rgba(225,224,204,0.2)"}}>›</span>
            <span style={{...MUTED,color:"rgba(225,224,204,0.6)"}}>Scheduler</span>
          </div>
          <h1 style={{fontSize:"1.5rem",fontWeight:700,color:"#E1E0CC",margin:0}}>Appliance Scheduler</h1>
          <p style={{...MUTED,marginTop:3}}>AI-optimized schedule to minimize your electricity cost</p>
        </div>
        {/* Date selector */}
        <div style={{display:"flex",alignItems:"center",gap:6,background:"#1A1A1A",
          border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.625rem",padding:"6px 10px"}}>
          <button onClick={()=>setDayOffset(d=>d-1)}
            style={{background:"none",border:"none",color:"rgba(225,224,204,0.4)",cursor:"pointer",padding:"0 4px",fontSize:"0.9rem"}}>‹</button>
          <span style={{fontSize:"0.78rem",color:"#E1E0CC",fontWeight:600,minWidth:90,textAlign:"center"}}>{dateStr}</span>
          <button onClick={()=>setDayOffset(d=>Math.min(0,d+1))}
            style={{background:"none",border:"none",color:"rgba(225,224,204,0.4)",cursor:"pointer",padding:"0 4px",fontSize:"0.9rem"}}>›</button>
        </div>
      </div>

      {/* Rate bar */}
      <div style={{...CARD,marginBottom:"1rem"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.75rem"}}>
          <span style={{fontSize:"0.82rem",fontWeight:600,color:"#E1E0CC"}}>Today's Rate Profile</span>
          <div style={{display:"flex",gap:"0.75rem"}}>
            {[{c:"rgba(52,211,153,0.5)",l:"Off-peak ₹3.50"},{c:"rgba(245,200,66,0.4)",l:"Shoulder ₹5.50"},{c:"rgba(245,200,66,0.85)",l:"Peak ₹7.50"}].map(({c,l})=>(
              <span key={l} style={{display:"flex",alignItems:"center",gap:4,...MUTED,fontSize:"0.6rem"}}>
                <span style={{width:8,height:8,borderRadius:2,background:c,display:"inline-block"}}/>
                {l}
              </span>
            ))}
          </div>
        </div>
        <RateBars rates={HOURS}/>
      </div>

      {/* Middle grid */}
      <div style={{display:"grid",gridTemplateColumns:"220px 1fr",gap:"1rem",alignItems:"start"}}>

        {/* Left — Appliance panel */}
        <div style={CARD}>
          <span style={SEC_LBL}>Select Appliances</span>

          {appliances.map(a=>(
            <div key={a.id} onClick={()=>toggleAppl(a.id)}
              style={{display:"flex",alignItems:"center",gap:"0.6rem",
                background:a.on?"rgba(245,200,66,0.04)":"rgba(0,0,0,0.4)",
                border:`1px solid ${a.on?"rgba(245,200,66,0.3)":"rgba(255,255,255,0.04)"}`,
                borderRadius:"0.625rem",padding:"0.6rem 0.75rem",marginBottom:"0.5rem",cursor:"pointer",
                transition:"all 0.2s"}}>
              <div style={{width:32,height:32,borderRadius:"0.4rem",background:"rgba(255,255,255,0.04)",
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.1rem",flexShrink:0}}>
                {a.icon}
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:"0.8rem",color:a.on?"#E1E0CC":"rgba(225,224,204,0.4)"}}>{a.name}</div>
                <div style={{fontSize:"0.65rem",color:"rgba(225,224,204,0.3)"}}>{a.watts}W · {a.duration}h</div>
              </div>
              {/* Toggle switch */}
              <div style={{width:32,height:18,borderRadius:9,
                background:a.on?"#F5C842":"rgba(255,255,255,0.1)",
                position:"relative",transition:"background 0.2s",flexShrink:0}}>
                <div style={{position:"absolute",top:2,
                  left:a.on?14:2,width:14,height:14,borderRadius:"50%",
                  background:a.on?"#000":"rgba(255,255,255,0.5)",transition:"left 0.2s"}}/>
              </div>
            </div>
          ))}

          {/* Optimise button */}
          <button onClick={optimise} disabled={loading||!appliances.some(a=>a.on)}
            style={{width:"100%",background:"#F5C842",color:"#000",border:"none",
              borderRadius:"0.625rem",padding:"0.75rem",fontSize:"0.85rem",fontWeight:700,
              cursor:loading?"not-allowed":"pointer",marginTop:"0.875rem",
              boxShadow:"0 0 24px rgba(245,200,66,0.2)",
              display:"flex",alignItems:"center",justifyContent:"center",gap:"0.5rem",
              opacity:appliances.some(a=>a.on)?1:0.5}}>
            {loading?(
              <>
                <svg style={{animation:"spin 1s linear infinite"}} width={14} height={14} viewBox="0 0 24 24"
                  fill="none" stroke="#000" strokeWidth={2.5} strokeLinecap="round">
                  <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
                </svg>
                Optimizing...
              </>
            ):(
              <>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                Optimize Schedule
              </>
            )}
          </button>
          <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>

          {/* Savings summary */}
          <div style={{background:"rgba(0,0,0,0.4)",borderRadius:"0.625rem",padding:"0.75rem",marginTop:"0.625rem",
            border:"1px solid rgba(255,255,255,0.04)"}}>
            <div style={{...MUTED,marginBottom:4}}>Estimated savings today:</div>
            <div style={{fontSize:"1.4rem",fontWeight:700,color:"#F5C842",
              textShadow:"0 0 20px rgba(245,200,66,0.4)",lineHeight:1}}>
              ₹{totalSavings.toFixed(2)}
            </div>
            <div style={{fontSize:"0.6rem",color:"rgba(225,224,204,0.3)",marginTop:3}}>vs running at preferred times</div>
          </div>

          {/* Monthly projection */}
          <div style={{marginTop:"0.5rem",padding:"0.6rem 0.75rem",
            background:"rgba(52,211,153,0.04)",border:"1px solid rgba(52,211,153,0.12)",borderRadius:"0.625rem"}}>
            <div style={{fontSize:"0.6rem",color:"rgba(52,211,153,0.6)",fontWeight:700,letterSpacing:"0.08em",marginBottom:2}}>MONTHLY PROJECTION</div>
            <div style={{fontSize:"1rem",fontWeight:700,color:"#34d399"}}>₹{(totalSavings*30).toFixed(0)}/month</div>
            <div style={{fontSize:"0.6rem",color:"rgba(225,224,204,0.3)"}}>if you follow this schedule daily</div>
          </div>
        </div>

        {/* Right — Gantt */}
        <div style={CARD}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.875rem"}}>
            <div>
              <div style={{fontSize:"0.82rem",fontWeight:600,color:"#E1E0CC"}}>Optimized Schedule</div>
              <div style={{fontSize:"0.68rem",color:"rgba(225,224,204,0.3)"}}>AI-recommended run times</div>
            </div>
            <div style={{display:"flex",gap:"0.625rem"}}>
              {[{c:"rgba(245,200,66,0.8)",l:"Scheduled"},{c:"none",b:"rgba(255,255,255,0.15)",l:"Preferred",dash:true}].map(({c,l,b,dash})=>(
                <span key={l} style={{display:"flex",alignItems:"center",gap:4,...MUTED,fontSize:"0.6rem"}}>
                  <svg width={14} height={6}>
                    <rect x={0} y={1} width={14} height={4} rx={2}
                      fill={c==="none"?"transparent":c}
                      stroke={b??"transparent"}
                      strokeWidth={dash?1:0}
                      strokeDasharray={dash?"2,1":undefined}/>
                  </svg>
                  {l}
                </span>
              ))}
            </div>
          </div>

          {schedule.length===0?(
            <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:160,
              color:"rgba(225,224,204,0.2)",fontSize:"0.82rem"}}>
              Select appliances and click Optimize
            </div>
          ):(
            <>
              <GanttChart schedule={schedule.filter(s=>appliances.find(a=>a.id===s.id)?.on)} rates={HOURS}/>

              {/* AI reasoning */}
              <div style={{background:"rgba(0,0,0,0.4)",borderRadius:"0.625rem",padding:"0.875rem",marginTop:"1rem",
                border:"1px solid rgba(255,255,255,0.04)"}}>
                <div style={{fontSize:"0.6rem",color:"#F5C842",fontWeight:700,letterSpacing:"0.1em",
                  textTransform:"uppercase",marginBottom:"0.625rem"}}>⚡ Why this schedule?</div>
                <div style={{display:"flex",flexDirection:"column",gap:"0.45rem"}}>
                  {schedule.filter(s=>appliances.find(a=>a.id===s.id)?.on).map(s=>(
                    <div key={s.id} style={{fontSize:"0.72rem",color:"rgba(225,224,204,0.5)",
                      display:"flex",alignItems:"flex-start",gap:"0.5rem",lineHeight:1.5}}>
                      <span style={{flexShrink:0}}>{s.icon}</span>
                      <span>
                        <strong style={{color:"rgba(225,224,204,0.7)"}}>{s.name}</strong>
                        {" → "}{fmt(s.startHour)}: {s.reason}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Apply button */}
              {optimised&&(
                <div style={{marginTop:"1rem",display:"flex",gap:"0.75rem",justifyContent:"flex-end"}}>
                  <button style={{padding:"0.55rem 1.25rem",background:"none",
                    border:"1px solid rgba(255,255,255,0.08)",borderRadius:"0.5rem",
                    color:"rgba(225,224,204,0.5)",fontSize:"0.78rem",cursor:"pointer"}}>
                    Adjust Manually
                  </button>
                  <button style={{padding:"0.55rem 1.25rem",background:"#F5C842",
                    border:"none",borderRadius:"0.5rem",
                    color:"#000",fontSize:"0.78rem",fontWeight:700,cursor:"pointer",
                    boxShadow:"0 0 20px rgba(245,200,66,0.2)"}}>
                    Apply Schedule ✓
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
