"use client";
import { useState, useEffect, useRef } from "react";
import Link from "next/link";

// ── Constants ────────────────────────────────────────────────────────────────
const CITIES = ["Bangalore","Mumbai","Delhi","Chennai","Hyderabad","Pune","Kolkata",
  "Ahmedabad","Jaipur","Lucknow","Bhopal","Nagpur","Patna","Indore","Surat",
  "Kochi","Coimbatore","Visakhapatnam","Chandigarh","Bhubaneswar"];
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const SLABS = [
  {range:"0 – 100 units",rate:"₹3.50",maxUnits:100},
  {range:"101 – 200 units",rate:"₹5.50",maxUnits:100},
  {range:"201 – 500 units",rate:"₹7.25",maxUnits:300},
  {range:"500+ units",rate:"₹8.50",maxUnits:Infinity},
];

const INIT_APPLIANCES = [
  {id:"ac",   icon:"❄️",name:"Air Conditioner",watts:1500,hours:6,  checked:true},
  {id:"gey",  icon:"🚿",name:"Geyser",         watts:2000,hours:0.5,checked:true},
  {id:"wash", icon:"🫧",name:"Washing Machine", watts:800, hours:0.3,checked:true},
  {id:"fridge",icon:"🧊",name:"Refrigerator",  watts:150, hours:24, checked:true},
  {id:"tv",   icon:"📺",name:"Television",      watts:100, hours:4,  checked:true},
  {id:"light",icon:"💡",name:"Lights",          watts:200, hours:6,  checked:true},
];

const DEMO_RESULT = {
  predicted_cost_inr:1420,
  predicted_units:214,
  confidence_low:1280,
  confidence_high:1560,
  breakdown:[
    {name:"AC",cost:680,units:108},
    {name:"Geyser",cost:300,units:36},
    {name:"Fridge",cost:180,units:108},
    {name:"Lights",cost:142,units:72},
    {name:"Washer",cost:82,units:7},
    {name:"TV",cost:36,units:12},
  ],
  ai_explanation:"Your Air Conditioner is your biggest cost driver at ₹680 this month — that's 48% of your total bill. Running it during peak hours (6–10 AM and 6–10 PM) costs you ₹7.50/unit instead of ₹3.50/unit. Shifting just 2 hours of AC usage to after 10 PM could save you ₹140 this month.",
  savings_possible:340,
};

// ── Styles ────────────────────────────────────────────────────────────────────
const NOISE = `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E")`;
const CARD: React.CSSProperties = {
  background:`${NOISE}, #1A1A1A`,
  border:"1px solid rgba(255,255,255,0.06)",
  borderRadius:"0.875rem",
  padding:"1.5rem",
};
const INPUT_BASE: React.CSSProperties = {
  width:"100%",background:"#000",border:"1px solid rgba(255,255,255,0.08)",
  borderRadius:"0.625rem",padding:"0.7rem 1rem",color:"#E1E0CC",
  fontSize:"0.875rem",outline:"none",boxSizing:"border-box",
};
const SECTION_LABEL: React.CSSProperties = {
  fontSize:"0.6rem",letterSpacing:"0.1em",textTransform:"uppercase",
  color:"rgba(245,200,66,0.6)",fontWeight:700,marginBottom:"0.75rem",display:"block",
};
const MUTED: React.CSSProperties = {color:"rgba(225,224,204,0.4)",fontSize:"0.75rem"};

// ── Typewriter hook ───────────────────────────────────────────────────────────
function useTypewriter(text:string, active:boolean, speed=18){
  const [displayed,setDisplayed]=useState("");
  useEffect(()=>{
    if(!active){setDisplayed("");return;}
    setDisplayed("");
    let i=0;
    const iv=setInterval(()=>{
      i++;setDisplayed(text.slice(0,i));
      if(i>=text.length)clearInterval(iv);
    },speed);
    return()=>clearInterval(iv);
  },[text,active]);
  return displayed;
}

// ── BreakdownChart ────────────────────────────────────────────────────────────
function BreakdownChart({items,total,show}:{items:typeof DEMO_RESULT.breakdown;total:number;show:boolean}){
  return(
    <div style={{display:"flex",flexDirection:"column",gap:"0.5rem"}}>
      {items.map((item,i)=>{
        const pct=total>0?(item.cost/total)*100:0;
        return(
          <div key={item.name} style={{display:"grid",gridTemplateColumns:"80px 1fr 56px",alignItems:"center",gap:"0.75rem"}}>
            <div style={{fontSize:"0.72rem",color:"rgba(225,224,204,0.6)",textAlign:"right",whiteSpace:"nowrap"}}>{item.name}</div>
            <div style={{height:8,borderRadius:4,background:"rgba(255,255,255,0.04)",overflow:"hidden"}}>
              <div style={{
                height:"100%",borderRadius:4,background:"linear-gradient(to right,#F5C842,rgba(245,200,66,0.6))",
                width:show?`${pct}%`:"0%",
                transition:`width 0.8s ease ${i*0.1}s`,
              }}/>
            </div>
            <div style={{fontSize:"0.72rem",color:"#F5C842",textAlign:"right",fontWeight:600}}>₹{item.cost}</div>
          </div>
        );
      })}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function PredictPage(){
  const curMonth=new Date().getMonth();
  const [city,setCity]=useState("Bangalore");
  const [month,setMonth]=useState(curMonth);
  const [members,setMembers]=useState(3);
  const [appliances,setAppliances]=useState(INIT_APPLIANCES);
  const [prevUnits,setPrevUnits]=useState("");
  const [loading,setLoading]=useState(false);
  const [result,setResult]=useState<typeof DEMO_RESULT|null>(null);
  const [showAnim,setShowAnim]=useState(false);

  const aiText=useTypewriter(result?.ai_explanation??"",showAnim);

  function updateAppl(id:string,field:string,val:unknown){
    setAppliances(a=>a.map(x=>x.id===id?{...x,[field]:val}:x));
  }

  async function predict(){
    setLoading(true);
    const body={
      city,month:month+1,household_size:members,
      previous_month_units:prevUnits?parseFloat(prevUnits):null,
      appliances:appliances.filter(a=>a.checked).map(a=>({
        name:a.name,wattage_watts:a.watts,
        avg_daily_usage_hours:a.hours,
        category:"other",is_schedulable:true,
      })),
    };
    try{
      const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
      const res=await fetch("/api/v1/predictions/bill",{
        method:"POST",headers:{"Content-Type":"application/json",
          ...(token?{Authorization:`Bearer ${token}`}:{})},
        body:JSON.stringify(body),
      });
      if(res.ok){
        const d=await res.json();
        setResult({...DEMO_RESULT,...d});
      } else { setResult(DEMO_RESULT); }
    } catch{ setResult(DEMO_RESULT); }
    setLoading(false);
    setTimeout(()=>setShowAnim(true),300);
  }

  // Slab active detection
  const units=result?.predicted_units??0;
  function getSlabIdx(u:number){
    if(u<=100)return 0;
    if(u<=200)return 1;
    if(u<=500)return 2;
    return 3;
  }
  const activeSlabIdx=getSlabIdx(units);

  return(
    <div style={{background:"#000",minHeight:"100vh",color:"#E1E0CC",fontFamily:"'Almarai',sans-serif",padding:"1.5rem"}}>

      {/* Header */}
      <div style={{marginBottom:"1.5rem"}}>
        <div style={{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.25rem"}}>
          <Link href="/dashboard" style={{color:"rgba(225,224,204,0.3)",textDecoration:"none",fontSize:"0.8rem"}}>Dashboard</Link>
          <span style={{color:"rgba(225,224,204,0.2)"}}>›</span>
          <span style={{color:"rgba(225,224,204,0.6)",fontSize:"0.8rem"}}>Bill Predictor</span>
        </div>
        <h1 style={{fontSize:"1.6rem",fontWeight:700,color:"#E1E0CC",margin:0}}>Bill Predictor</h1>
        <p style={{...MUTED,marginTop:4}}>Estimate your next electricity bill before it arrives</p>
      </div>

      {/* Two-column layout */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem",alignItems:"start"}}>

        {/* ── LEFT — Input Form ── */}
        <div style={CARD}>

          {/* Section: Setup */}
          <span style={SECTION_LABEL}>Your Setup</span>

          {/* City */}
          <div style={{marginBottom:"1rem"}}>
            <label style={{...MUTED,display:"block",marginBottom:6}}>City</label>
            <select value={city} onChange={e=>setCity(e.target.value)}
              style={{...INPUT_BASE,appearance:"none",cursor:"pointer"}}>
              {CITIES.map(c=><option key={c} value={c} style={{background:"#111"}}>{c}</option>)}
            </select>
          </div>

          {/* Month pills */}
          <div style={{marginBottom:"1rem"}}>
            <label style={{...MUTED,display:"block",marginBottom:6}}>Billing Month</label>
            <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
              {MONTHS.map((m,i)=>(
                <button key={m} onClick={()=>setMonth(i)}
                  style={{padding:"5px 11px",borderRadius:999,fontSize:"0.72rem",cursor:"pointer",border:"none",
                    fontWeight:month===i?600:400,
                    background:month===i?"#F5C842":"rgba(255,255,255,0.04)",
                    color:month===i?"#000":"rgba(225,224,204,0.5)"}}>
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* Household size stepper */}
          <div style={{marginBottom:"1.25rem"}}>
            <label style={{...MUTED,display:"block",marginBottom:6}}>Household Members</label>
            <div style={{display:"flex",alignItems:"center",gap:"0.75rem",background:"#000",
              borderRadius:"0.625rem",padding:"0.5rem 0.75rem",border:"1px solid rgba(255,255,255,0.08)",
              width:"fit-content"}}>
              <button onClick={()=>setMembers(m=>Math.max(1,m-1))}
                style={{width:28,height:28,borderRadius:"50%",background:"rgba(245,200,66,0.12)",
                  border:"1px solid rgba(245,200,66,0.3)",color:"#F5C842",cursor:"pointer",
                  fontSize:"1.1rem",lineHeight:1,display:"flex",alignItems:"center",justifyContent:"center"}}>−</button>
              <span style={{color:"#E1E0CC",fontWeight:700,fontSize:"1rem",minWidth:24,textAlign:"center"}}>{members}</span>
              <button onClick={()=>setMembers(m=>Math.min(8,m+1))}
                style={{width:28,height:28,borderRadius:"50%",background:"rgba(245,200,66,0.12)",
                  border:"1px solid rgba(245,200,66,0.3)",color:"#F5C842",cursor:"pointer",
                  fontSize:"1.1rem",lineHeight:1,display:"flex",alignItems:"center",justifyContent:"center"}}>+</button>
              <span style={MUTED}>members</span>
            </div>
          </div>

          {/* Section: Appliances */}
          <span style={{...SECTION_LABEL,marginTop:"0.25rem"}}>Your Appliances</span>

          <div style={{display:"flex",flexDirection:"column",gap:"0.65rem",marginBottom:"1rem"}}>
            {appliances.map(a=>(
              <div key={a.id} style={{background:"rgba(0,0,0,0.4)",borderRadius:"0.5rem",
                padding:"0.75rem",border:"1px solid rgba(255,255,255,0.04)"}}>
                {/* Row 1: checkbox + name + wattage */}
                <div style={{display:"flex",alignItems:"center",gap:"0.6rem",marginBottom:a.checked?"0.6rem":0}}>
                  <input type="checkbox" checked={a.checked}
                    onChange={e=>updateAppl(a.id,"checked",e.target.checked)}
                    style={{accentColor:"#F5C842",width:15,height:15,cursor:"pointer",flexShrink:0}}/>
                  <span style={{fontSize:"1rem"}}>{a.icon}</span>
                  <span style={{flex:1,fontSize:"0.8rem",color:a.checked?"#E1E0CC":"rgba(225,224,204,0.3)"}}>{a.name}</span>
                  {a.checked&&(
                    <div style={{display:"flex",alignItems:"center",gap:4}}>
                      <input type="number" value={a.watts}
                        onChange={e=>updateAppl(a.id,"watts",parseInt(e.target.value)||0)}
                        style={{width:64,background:"#000",border:"1px solid rgba(255,255,255,0.08)",
                          borderRadius:6,padding:"3px 6px",color:"#F5C842",fontSize:"0.75rem",
                          textAlign:"right",outline:"none"}}/>
                      <span style={MUTED}>W</span>
                    </div>
                  )}
                </div>
                {/* Row 2: hours slider */}
                {a.checked&&(
                  <div style={{display:"flex",alignItems:"center",gap:"0.6rem",paddingLeft:22}}>
                    <input type="range" min={0} max={24} step={0.5} value={a.hours}
                      onChange={e=>updateAppl(a.id,"hours",parseFloat(e.target.value))}
                      style={{flex:1,accentColor:"#F5C842",height:3,cursor:"pointer"}}/>
                    <span style={{...MUTED,minWidth:36,textAlign:"right"}}>{a.hours}h/d</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Previous month units */}
          <div style={{marginBottom:"1.5rem"}}>
            <label style={{...MUTED,display:"block",marginBottom:6}}>Previous Month Units</label>
            <div style={{position:"relative"}}>
              <input type="number" value={prevUnits} onChange={e=>setPrevUnits(e.target.value)}
                placeholder="Leave blank if first month"
                style={{...INPUT_BASE,paddingRight:"3.5rem"}}/>
              <span style={{position:"absolute",right:"1rem",top:"50%",transform:"translateY(-50%)",
                ...MUTED}}>kWh</span>
            </div>
          </div>

          {/* Submit */}
          <button onClick={predict} disabled={loading}
            style={{width:"100%",background:"#F5C842",color:"#000",border:"none",
              borderRadius:"0.625rem",padding:"0.9rem",fontSize:"0.9rem",fontWeight:700,
              cursor:loading?"not-allowed":"pointer",
              boxShadow:loading?"none":"0 0 30px rgba(245,200,66,0.25)",
              opacity:loading?0.8:1,transition:"box-shadow 0.2s,opacity 0.2s",
              display:"flex",alignItems:"center",justifyContent:"center",gap:"0.5rem"}}>
            {loading?(
              <>
                <svg style={{animation:"spin 1s linear infinite"}} width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth={2.5} strokeLinecap="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                Calculating...
              </>
            ):"⚡ Predict My Bill"}
          </button>
          <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
        </div>

        {/* ── RIGHT — Results ── */}
        <div style={CARD}>
          {!result?(
            /* Empty state */
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
              minHeight:420,gap:"0.75rem",textAlign:"center"}}>
              <svg width={64} height={64} viewBox="0 0 24 24" fill="none" stroke="rgba(225,224,204,0.08)"
                strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2a10 10 0 1 0 10 10"/><path d="M12 6v6l4 2"/><path d="M22 2 12 12"/><circle cx="19" cy="5" r="3"/>
              </svg>
              <div style={{color:"rgba(225,224,204,0.2)",fontSize:"0.875rem",maxWidth:200,lineHeight:1.5}}>
                Fill in your details and click <strong style={{color:"rgba(225,224,204,0.35)"}}>Predict My Bill</strong> to see your estimate
              </div>
            </div>
          ):(
            /* Results */
            <div style={{animation:"fadeUp 0.4s ease"}}>
              <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}`}</style>

              {/* Big number */}
              <div style={{textAlign:"center",marginBottom:"1.5rem",paddingBottom:"1.25rem",
                borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
                <div style={{fontSize:"0.65rem",letterSpacing:"0.1em",textTransform:"uppercase",
                  color:"rgba(225,224,204,0.4)",marginBottom:"0.5rem"}}>Estimated Bill for {MONTHS[month]}</div>
                <div style={{fontSize:"3.25rem",fontWeight:700,color:"#E1E0CC",lineHeight:1,
                  textShadow:"0 0 30px rgba(245,200,66,0.45)"}}>
                  ₹{result.predicted_cost_inr.toLocaleString()}
                </div>
                <div style={{fontSize:"0.72rem",color:"rgba(225,224,204,0.3)",marginTop:"0.4rem"}}>
                  Likely between ₹{result.confidence_low.toLocaleString()} — ₹{result.confidence_high.toLocaleString()}
                </div>
                <div style={{fontSize:"0.7rem",color:"rgba(225,224,204,0.35)",marginTop:"0.2rem"}}>
                  ~{result.predicted_units} kWh estimated consumption
                </div>
              </div>

              {/* Breakdown chart */}
              <div style={{marginBottom:"1.25rem"}}>
                <span style={SECTION_LABEL}>Cost Breakdown</span>
                <BreakdownChart items={result.breakdown} total={result.predicted_cost_inr} show={true}/>
              </div>

              {/* Slab table */}
              <div style={{marginBottom:"1.25rem"}}>
                <span style={SECTION_LABEL}>Your Tariff Slabs (BESCOM)</span>
                <div style={{border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.5rem",overflow:"hidden"}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 80px 80px 60px",
                    padding:"0.45rem 0.75rem",background:"rgba(255,255,255,0.02)",
                    fontSize:"0.6rem",color:"rgba(225,224,204,0.3)",fontWeight:700,
                    letterSpacing:"0.05em",textTransform:"uppercase"}}>
                    <span>Units Range</span><span style={{textAlign:"center"}}>Rate/unit</span>
                    <span style={{textAlign:"center"}}>Your Usage</span>
                    <span style={{textAlign:"right"}}>Cost</span>
                  </div>
                  {SLABS.map((s,i)=>{
                    const active=i===activeSlabIdx;
                    const used=i===0?Math.min(units,100):
                      i===1?Math.max(0,Math.min(units-100,100)):
                      i===2?Math.max(0,Math.min(units-200,300)):
                      Math.max(0,units-500);
                    const cost=used*parseFloat(s.rate.replace("₹",""));
                    return(
                      <div key={i} style={{display:"grid",gridTemplateColumns:"1fr 80px 80px 60px",
                        padding:"0.55rem 0.75rem",fontSize:"0.72rem",
                        borderLeft:active?"2px solid #F5C842":"2px solid transparent",
                        background:active?"rgba(245,200,66,0.05)":"transparent",
                        color:active?"rgba(225,224,204,0.8)":"rgba(225,224,204,0.45)",
                        borderTop:"1px solid rgba(255,255,255,0.04)"}}>
                        <span>{s.range}</span>
                        <span style={{textAlign:"center",color:active?"#F5C842":undefined}}>{s.rate}</span>
                        <span style={{textAlign:"center"}}>{Math.max(0,used).toFixed(0)} kWh</span>
                        <span style={{textAlign:"right",color:active?"#F5C842":undefined}}>₹{Math.max(0,cost).toFixed(0)}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* AI explanation */}
              <div style={{background:"rgba(0,0,0,0.4)",borderRadius:"0.625rem",padding:"1rem",marginBottom:"1rem",
                border:"1px solid rgba(255,255,255,0.04)"}}>
                <div style={{fontSize:"0.6rem",letterSpacing:"0.1em",textTransform:"uppercase",
                  color:"#F5C842",fontWeight:700,marginBottom:"0.5rem"}}>⚡ AI Insight</div>
                <p style={{fontSize:"0.8rem",color:"rgba(225,224,204,0.6)",lineHeight:1.7,margin:0}}>
                  {aiText}<span style={{opacity:0.4,animation:"blink 1s steps(1) infinite"}}>|</span>
                </p>
                <style>{`@keyframes blink{0%,100%{opacity:0.4}50%{opacity:0}}`}</style>
              </div>

              {/* Savings card */}
              <div style={{background:"rgba(52,211,153,0.05)",border:"1px solid rgba(52,211,153,0.2)",
                borderRadius:"0.625rem",padding:"1rem",display:"flex",alignItems:"center",
                justifyContent:"space-between",gap:"0.75rem"}}>
                <div>
                  <div style={{fontSize:"0.65rem",color:"rgba(52,211,153,0.7)",fontWeight:700,
                    letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:4}}>
                    Savings Opportunity
                  </div>
                  <div style={{fontSize:"0.78rem",color:"rgba(225,224,204,0.5)",marginBottom:4}}>
                    Shift peak usage to off-peak hours
                  </div>
                  <div style={{fontSize:"1.5rem",fontWeight:700,color:"#34d399",
                    textShadow:"0 0 20px rgba(52,211,153,0.4)"}}>
                    ₹{result.savings_possible}/month
                  </div>
                </div>
                <Link href="/dashboard/schedule"
                  style={{background:"rgba(52,211,153,0.12)",border:"1px solid rgba(52,211,153,0.3)",
                    borderRadius:"0.5rem",padding:"0.6rem 1rem",color:"#34d399",textDecoration:"none",
                    fontSize:"0.78rem",fontWeight:600,whiteSpace:"nowrap",flexShrink:0}}>
                  Optimize →
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
