"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

// ── Types ─────────────────────────────────────────────────────────────────────
interface HourlyRate { hour: number; rate_inr_per_unit: number; is_peak: boolean; }
interface Anomaly { title: string; desc: string; time: string; severity: "high"|"medium"|"low"; }

// ── Demo data ─────────────────────────────────────────────────────────────────
const DEMO_RATES: HourlyRate[] = Array.from({length:24},(_,h)=>({
  hour:h,
  rate_inr_per_unit: (h>=6&&h<10)||(h>=18&&h<22) ? 7.50 : h>=10&&h<18 ? 5.50 : 3.50,
  is_peak: (h>=6&&h<10)||(h>=18&&h<22),
}));

const DEMO_ANOMALIES: Anomaly[] = [
  {title:"Geyser running 3× longer",desc:"Continuous run detected — 2.4h vs normal 40 min",time:"2h ago",severity:"high"},
  {title:"AC spike outside hours",desc:"Usage detected at 3 AM, outside normal schedule",time:"5h ago",severity:"medium"},
  {title:"Washer extra cycle",desc:"Second cycle ran outside preferred window",time:"1d ago",severity:"low"},
];

const APPLIANCES = [
  {icon:"❄️",name:"AC 1.5T",watts:"1500W",cost:"₹28.40",status:"Running"},
  {icon:"🚿",name:"Geyser",watts:"2000W",cost:"₹4.20",status:"Scheduled"},
  {icon:"🫧",name:"Washer",watts:"800W",cost:"₹2.10",status:"Scheduled"},
  {icon:"💡",name:"Lights",watts:"200W",cost:"₹0.80",status:"Running"},
];

// ── Noise texture ─────────────────────────────────────────────────────────────
const NOISE = `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E")`;
const CARD: React.CSSProperties = {
  background:`${NOISE}, #1A1A1A`,
  border:"1px solid rgba(255,255,255,0.06)",
  borderRadius:"0.75rem",
  padding:"1.25rem",
};
const GLOW = "0 0 20px rgba(245,200,66,0.4)";

// ── Sub-components ────────────────────────────────────────────────────────────
function Badge({label,type}:{label:string;type:"peak"|"off"|"scheduled"|"running"|"idle"}){
  const styles:{[k:string]:React.CSSProperties} = {
    peak:{background:"rgba(245,200,66,0.1)",border:"1px solid rgba(245,200,66,0.3)",color:"#F5C842"},
    off:{background:"rgba(52,211,153,0.1)",border:"1px solid rgba(52,211,153,0.3)",color:"#34d399"},
    scheduled:{background:"rgba(245,200,66,0.1)",border:"1px solid rgba(245,200,66,0.3)",color:"#F5C842"},
    running:{background:"rgba(52,211,153,0.1)",border:"1px solid rgba(52,211,153,0.3)",color:"#34d399"},
    idle:{background:"rgba(255,255,255,0.04)",border:"1px solid transparent",color:"rgba(225,224,204,0.3)"},
  };
  return <span style={{...styles[type],fontSize:"0.6rem",padding:"2px 8px",borderRadius:"999px",fontWeight:600,letterSpacing:"0.06em"}}>{label}</span>;
}

function Sparkline(){
  const pts=[12,18,14,22,16,28,20];
  const max=Math.max(...pts), min=Math.min(...pts);
  const W=60,H=20;
  const px=(i:number)=>(i/(pts.length-1))*W;
  const py=(v:number)=>H-((v-min)/(max-min+1))*H;
  const d=pts.map((v,i)=>`${i===0?"M":"L"}${px(i)},${py(v)}`).join(" ");
  return(
    <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{display:"block"}}>
      <path d={d} fill="none" stroke="rgba(245,200,66,0.6)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function Donut({pct}:{pct:number}){
  const r=18,cx=24,cy=24,circ=2*Math.PI*r;
  return(
    <svg width={48} height={48} viewBox="0 0 48 48">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={5}/>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#F5C842" strokeWidth={5}
        strokeDasharray={`${circ*pct} ${circ*(1-pct)}`}
        strokeDashoffset={circ*0.25} strokeLinecap="round"/>
    </svg>
  );
}

function RateChart({rates,now}:{rates:HourlyRate[];now:number}){
  const W=600,H=160,PAD=24;
  const maxR=Math.max(...rates.map(r=>r.rate_inr_per_unit));
  const minR=Math.min(...rates.map(r=>r.rate_inr_per_unit));
  const toX=(h:number)=>PAD+(h/23)*(W-PAD*2);
  const toY=(v:number)=>H-PAD-((v-minR)/(maxR-minR+0.5))*(H-PAD*2);
  const pathD=rates.map((r,i)=>`${i===0?"M":"L"}${toX(r.hour)},${toY(r.rate_inr_per_unit)}`).join(" ");
  const areaD=`${pathD} L${toX(23)},${H-PAD} L${toX(0)},${H-PAD} Z`;
  const nowX=toX(now);
  const yLabels=[3.5,5.5,7.5];
  const xLabels=["0","3","6","9","12","15","18","21","23"];

  return(
    <svg viewBox={`0 0 ${W} ${H+20}`} width="100%" style={{overflow:"visible"}}>
      {/* Peak bands */}
      {[[6,10],[18,22]].map(([s,e],i)=>(
        <rect key={i} x={toX(s)} y={PAD} width={toX(e)-toX(s)} height={H-PAD*2}
          fill="rgba(245,200,66,0.07)" rx={2}/>
      ))}
      {/* Y grid */}
      {yLabels.map(v=>(
        <g key={v}>
          <line x1={PAD} y1={toY(v)} x2={W-PAD} y2={toY(v)} stroke="rgba(255,255,255,0.04)" strokeWidth={0.5}/>
          <text x={PAD-4} y={toY(v)+3} fill="rgba(225,224,204,0.3)" fontSize={8} textAnchor="end">₹{v}</text>
        </g>
      ))}
      {/* Area fill */}
      <defs>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F5C842" stopOpacity="0.2"/>
          <stop offset="100%" stopColor="#F5C842" stopOpacity="0.01"/>
        </linearGradient>
      </defs>
      <path d={areaD} fill="url(#areaGrad)"/>
      {/* Line */}
      <path d={pathD} fill="none" stroke="#F5C842" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"/>
      {/* Current time */}
      <line x1={nowX} y1={PAD} x2={nowX} y2={H-PAD} stroke="rgba(255,255,255,0.3)" strokeWidth={1} strokeDasharray="3,3"/>
      <circle cx={nowX} cy={PAD} r={3} fill="#F5C842"/>
      {/* X labels */}
      {xLabels.map(l=>{
        const h=parseInt(l);
        return <text key={l} x={toX(h)} y={H+16} fill="rgba(225,224,204,0.3)" fontSize={8} textAnchor="middle">{h===0?"12AM":h<12?`${h}AM`:h===12?"12PM":h===23?"11PM":`${h-12}PM`}</text>;
      })}
    </svg>
  );
}

// ── Page ─────────────────────────────────────────────────────────────────────
export default function DashboardPage(){
  const [rates,setRates]=useState<HourlyRate[]>(DEMO_RATES);
  const [anomalies,setAnomalies]=useState<Anomaly[]>(DEMO_ANOMALIES);
  const [mounted,setMounted]=useState(false);
  const [activeTab,setActiveTab]=useState<"Rate"|"Usage"|"Cost">("Rate");

  const now=mounted ? new Date().getHours() : 9;
  const currentRate=rates.find(r=>r.hour===now);
  const isPeak=currentRate?.is_peak??false;
  const monthPct=mounted ? new Date().getDate()/31 : 0.45;

  useEffect(()=>{
    setMounted(true);
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    if(token){
      fetch("/api/v1/predictions/peak-hours",{headers:{Authorization:`Bearer ${token}`}})
        .then(r=>r.ok?r.json():null).then(d=>{if(d?.hourly_rates)setRates(d.hourly_rates);}).catch(()=>{});
    }
  },[]);

  const statusType=(s:string)=>s==="Running"?"running":s==="Scheduled"?"scheduled":"idle";
  const sevColor:{[k:string]:string}={high:"#f87171",medium:"#F5C842",low:"rgba(225,224,204,0.4)"};

  const cs:React.CSSProperties={color:"#E1E0CC"};
  const muted:React.CSSProperties={color:"rgba(225,224,204,0.4)",fontSize:"0.7rem"};

  return(
    <div style={{background:"#000",minHeight:"100vh",color:"#E1E0CC",fontFamily:"'Almarai',sans-serif"}}>

      {/* Top Bar */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"1rem 1.5rem",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
        <div>
          <div style={{fontSize:"1.1rem",fontWeight:500,...cs}}>Good {now<12?"morning":now<17?"afternoon":"evening"}, Arjun ⚡</div>
          <div style={muted}>Your BESCOM tariff is active · Peak hours today: 6–10 AM, 6–10 PM</div>
        </div>
        <div style={{display:"flex",gap:"0.75rem",alignItems:"center"}}>
          {/* Bell */}
          <button style={{position:"relative",background:"none",border:"none",cursor:"pointer",color:"rgba(225,224,204,0.4)",padding:4}}>
            <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
            <span style={{position:"absolute",top:0,right:0,width:16,height:16,background:"#F5C842",borderRadius:"50%",color:"#000",fontSize:8,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700}}>2</span>
          </button>
          {/* Settings */}
          <Link href="/dashboard/settings" style={{color:"rgba(225,224,204,0.4)",display:"flex"}}>
            <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
          </Link>
          {/* Avatar */}
          <div style={{width:32,height:32,borderRadius:"50%",background:"rgba(245,200,66,0.15)",border:"1px solid rgba(245,200,66,0.3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:700,color:"#F5C842"}}>AR</div>
        </div>
      </div>

      <div style={{padding:"1.25rem 1.5rem",display:"flex",flexDirection:"column",gap:"1rem"}}>

        {/* ROW 1 — KPI Cards */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"0.875rem"}}>

          {/* Card 1 — Bill */}
          <div style={CARD}>
            <div style={{display:"flex",alignItems:"center",gap:6,...muted,marginBottom:"0.6rem"}}>
              <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="#F5C842" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
              Estimated Bill
            </div>
            <div style={{fontSize:"1.9rem",fontWeight:700,textShadow:GLOW,...cs,lineHeight:1}}>₹1,240</div>
            <div style={{fontSize:"0.7rem",color:"#34d399",marginTop:"0.35rem",display:"flex",alignItems:"center",gap:4}}>
              <span>↓</span> ₹180 less than last month
            </div>
            <div style={{marginTop:"0.7rem",height:3,borderRadius:3,background:"rgba(255,255,255,0.08)",overflow:"hidden"}}>
              <div style={{height:"100%",width:`${(monthPct*100).toFixed(0)}%`,background:"linear-gradient(to right,#F5C842,rgba(245,200,66,0.4))",borderRadius:3}}/>
            </div>
            <div style={{...muted,marginTop:3}}>{(monthPct*100).toFixed(0)}% of month elapsed</div>
          </div>

          {/* Card 2 — Today */}
          <div style={CARD}>
            <div style={{display:"flex",alignItems:"center",gap:6,...muted,marginBottom:"0.6rem"}}>
              <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="#F5C842" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
              Today's Usage
            </div>
            <div style={{fontSize:"1.9rem",fontWeight:700,textShadow:GLOW,...cs,lineHeight:1}}>₹42.30</div>
            <div style={{...muted,marginTop:"0.35rem"}}>8.4 kWh consumed</div>
            <div style={{marginTop:"0.7rem"}}>
              <Sparkline/>
            </div>
            <div style={{...muted,marginTop:3}}>7-day cost trend</div>
          </div>

          {/* Card 3 — Peak Alert */}
          <div style={CARD}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"0.6rem"}}>
              <div style={{display:"flex",alignItems:"center",gap:6,...muted}}>
                <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="#F5C842" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                Current Rate
              </div>
              {isPeak
                ? <Badge label="PEAK ⚡" type="peak"/>
                : <Badge label="CHEAP NOW" type="off"/>}
            </div>
            <div style={{fontSize:"1.9rem",fontWeight:700,lineHeight:1,
              textShadow:isPeak?GLOW:"0 0 20px rgba(52,211,153,0.4)",
              color:isPeak?"#F5C842":"#34d399"}}>
              {currentRate?`₹${currentRate.rate_inr_per_unit.toFixed(2)}/unit`:"₹7.50/unit"}
            </div>
            <div style={{...muted,marginTop:"0.35rem"}}>
              {isPeak ? "Peak until 10 PM" : "Off-peak until 6 AM"}
            </div>
            <div style={{marginTop:"0.7rem",display:"flex",gap:2}}>
              {DEMO_RATES.map(r=>(
                <div key={r.hour} style={{flex:1,height:16,borderRadius:1,
                  background:r.hour===now?"#fff":r.is_peak?"rgba(245,200,66,0.5)":"rgba(52,211,153,0.25)",
                  opacity:r.hour===now?1:0.7}}/>
              ))}
            </div>
          </div>

          {/* Card 4 — Savings */}
          <div style={CARD}>
            <div style={{display:"flex",alignItems:"center",gap:6,...muted,marginBottom:"0.6rem"}}>
              <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="#34d399" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
              Savings vs Peak
            </div>
            <div style={{display:"flex",alignItems:"center",gap:"0.75rem"}}>
              <div style={{fontSize:"1.9rem",fontWeight:700,color:"#34d399",textShadow:"0 0 20px rgba(52,211,153,0.4)",lineHeight:1}}>₹340</div>
              <Donut pct={0.22}/>
            </div>
            <div style={{...muted,marginTop:"0.35rem"}}>By shifting 3 appliances</div>
            <div style={{...muted,marginTop:"0.15rem"}}>22% of your bill saved</div>
          </div>
        </div>

        {/* ROW 2 — Chart + Quick Actions */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 280px",gap:"0.875rem"}}>

          {/* Rate Timeline */}
          <div style={CARD}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1rem"}}>
              <div style={{fontWeight:600,...cs}}>Today's Tariff Rate</div>
              <div style={{display:"flex",gap:4}}>
                {(["Rate","Usage","Cost"] as const).map(t=>(
                  <button key={t} onClick={()=>setActiveTab(t)}
                    style={{padding:"4px 12px",borderRadius:999,fontSize:"0.7rem",fontWeight:600,cursor:"pointer",border:"1px solid",
                      background:activeTab===t?"rgba(245,200,66,0.1)":"transparent",
                      borderColor:activeTab===t?"rgba(245,200,66,0.3)":"transparent",
                      color:activeTab===t?"#F5C842":"rgba(225,224,204,0.3)"}}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <RateChart rates={rates} now={now}/>
            <div style={{display:"flex",gap:"1rem",marginTop:"0.5rem"}}>
              {[{c:"rgba(245,200,66,0.5)",l:"Peak hours"},
                {c:"rgba(52,211,153,0.4)",l:"Off-peak"},
                {c:"rgba(255,255,255,0.25)",l:"Now"}].map(({c,l})=>(
                <span key={l} style={{display:"flex",alignItems:"center",gap:5,fontSize:"0.65rem",color:"rgba(225,224,204,0.4)"}}>
                  <span style={{width:8,height:8,borderRadius:2,background:c,display:"inline-block"}}/>
                  {l}
                </span>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div style={CARD}>
            <div style={{fontWeight:600,...cs,marginBottom:"0.875rem"}}>Smart Actions</div>
            {[
              {icon:"🗓",title:"Optimize Today",desc:"Schedule 4 appliances cheaply",href:"/dashboard/schedule"},
              {icon:"📊",title:"Predict Next Bill",desc:"Based on current usage",href:"/dashboard/predict"},
              {icon:"🤖",title:"Ask AI Advisor",desc:"Get personalized tips",href:"/dashboard/chat"},
            ].map(a=>(
              <Link key={a.href} href={a.href} style={{textDecoration:"none"}}>
                <div style={{display:"flex",alignItems:"center",gap:"0.75rem",
                  background:"rgba(0,0,0,0.4)",borderRadius:"0.625rem",padding:"0.75rem",
                  marginBottom:"0.5rem",cursor:"pointer",transition:"border-color 0.2s",
                  border:"1px solid rgba(255,255,255,0.04)"}}>
                  <div style={{width:34,height:34,background:"rgba(245,200,66,0.12)",borderRadius:"0.4rem",
                    display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1rem",flexShrink:0}}>
                    {a.icon}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:"0.82rem",fontWeight:600,...cs}}>{a.title}</div>
                    <div style={{fontSize:"0.68rem",color:"rgba(225,224,204,0.4)"}}>{a.desc}</div>
                  </div>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="rgba(225,224,204,0.3)" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
                </div>
              </Link>
            ))}

            {/* AI tip */}
            <div style={{marginTop:"0.5rem",padding:"0.75rem",background:"rgba(245,200,66,0.04)",
              border:"1px solid rgba(245,200,66,0.12)",borderRadius:"0.625rem"}}>
              <div style={{fontSize:"0.6rem",color:"#F5C842",fontWeight:700,letterSpacing:"0.08em",marginBottom:4}}>AI TIP</div>
              <div style={{fontSize:"0.72rem",color:"rgba(225,224,204,0.6)",lineHeight:1.5}}>
                Shift your AC to 11 PM tonight — saves <span style={{color:"#F5C842"}}>₹22</span> vs running at 7 PM.
              </div>
            </div>
          </div>
        </div>

        {/* ROW 3 — Appliances + Anomalies */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0.875rem"}}>

          {/* Appliances */}
          <div style={CARD}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.75rem"}}>
              <div style={{fontWeight:600,...cs}}>My Appliances</div>
              <Link href="/dashboard/appliances" style={{fontSize:"0.72rem",color:"#F5C842",textDecoration:"none",fontWeight:600}}>Manage</Link>
            </div>
            {APPLIANCES.map((a,i)=>(
              <div key={a.name} style={{display:"flex",alignItems:"center",justifyContent:"space-between",
                padding:"0.65rem 0",borderBottom:i<APPLIANCES.length-1?"1px solid rgba(255,255,255,0.04)":"none"}}>
                <div style={{display:"flex",alignItems:"center",gap:"0.6rem"}}>
                  <span style={{fontSize:"1.1rem"}}>{a.icon}</span>
                  <div>
                    <div style={{fontSize:"0.82rem",fontWeight:500,...cs}}>{a.name}</div>
                    <div style={{fontSize:"0.65rem",color:"rgba(225,224,204,0.3)"}}>{a.watts}</div>
                  </div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:"0.6rem"}}>
                  <div style={{fontSize:"0.8rem",color:"rgba(225,224,204,0.6)"}}>{a.cost}</div>
                  <Badge label={a.status} type={statusType(a.status)}/>
                </div>
              </div>
            ))}
          </div>

          {/* Anomalies */}
          <div style={CARD}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.75rem"}}>
              <div style={{display:"flex",alignItems:"center",gap:"0.5rem"}}>
                <div style={{fontWeight:600,...cs}}>Recent Alerts</div>
                <span style={{background:"rgba(245,200,66,0.15)",border:"1px solid rgba(245,200,66,0.3)",
                  color:"#F5C842",borderRadius:999,fontSize:"0.6rem",padding:"1px 7px",fontWeight:700}}>
                  {anomalies.length}
                </span>
              </div>
              <Link href="/dashboard/anomalies" style={{fontSize:"0.72rem",color:"#F5C842",textDecoration:"none",fontWeight:600}}>View All</Link>
            </div>
            {anomalies.map((a,i)=>(
              <div key={i} style={{display:"flex",alignItems:"flex-start",gap:"0.65rem",
                padding:"0.65rem 0",borderBottom:i<anomalies.length-1?"1px solid rgba(255,255,255,0.04)":"none"}}>
                <svg style={{marginTop:1,flexShrink:0}} width={14} height={14} viewBox="0 0 24 24" fill="none"
                  stroke={sevColor[a.severity]} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                  <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                <div style={{flex:1}}>
                  <div style={{fontSize:"0.82rem",fontWeight:600,...cs}}>{a.title}</div>
                  <div style={{fontSize:"0.68rem",color:"rgba(225,224,204,0.4)",marginTop:2}}>{a.desc}</div>
                  <div style={{fontSize:"0.6rem",color:"rgba(225,224,204,0.2)",marginTop:2}}>{a.time}</div>
                </div>
                <Link href="/dashboard/anomalies" style={{fontSize:"0.7rem",color:"#F5C842",textDecoration:"none",fontWeight:600,flexShrink:0}}>View</Link>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
