"use client";
import { useState, useEffect } from "react";
import Link from "next/link";

// ── Types ─────────────────────────────────────────────────────────────────────
interface Appliance {
  id: string; name: string; icon: string; category: string;
  wattage_watts: number; avg_daily_usage_hours: number;
  is_schedulable: boolean; preferred_start_hour: number;
  preferred_end_hour: number; status: "Running"|"Scheduled"|"Idle";
}

// ── Constants ─────────────────────────────────────────────────────────────────
const CATS=["All","Cooling","Heating","Washing","Lighting","Entertainment","Other"];
const ICONS:{[k:string]:string}={cooling:"❄️",heating:"🚿",washing:"🫧",lighting:"💡",entertainment:"📺",other:"🔌"};

const DEMO:Appliance[]=[
  {id:"a1",name:"AC 1.5T",icon:"❄️",category:"cooling",wattage_watts:1500,avg_daily_usage_hours:6,is_schedulable:true,preferred_start_hour:22,preferred_end_hour:6,status:"Running"},
  {id:"a2",name:"Geyser",icon:"🚿",category:"heating",wattage_watts:2000,avg_daily_usage_hours:0.5,is_schedulable:true,preferred_start_hour:5,preferred_end_hour:7,status:"Scheduled"},
  {id:"a3",name:"Washing Machine",icon:"🫧",category:"washing",wattage_watts:800,avg_daily_usage_hours:0.75,is_schedulable:true,preferred_start_hour:11,preferred_end_hour:13,status:"Idle"},
  {id:"a4",name:"Refrigerator",icon:"🧊",category:"other",wattage_watts:150,avg_daily_usage_hours:24,is_schedulable:false,preferred_start_hour:0,preferred_end_hour:23,status:"Running"},
  {id:"a5",name:"Television",icon:"📺",category:"entertainment",wattage_watts:100,avg_daily_usage_hours:4,is_schedulable:true,preferred_start_hour:19,preferred_end_hour:23,status:"Running"},
  {id:"a6",name:"Lights",icon:"💡",category:"lighting",wattage_watts:200,avg_daily_usage_hours:6,is_schedulable:false,preferred_start_hour:18,preferred_end_hour:23,status:"Running"},
];

// ── Styles ────────────────────────────────────────────────────────────────────
const NOISE=`url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E")`;
const CARD:React.CSSProperties={background:`${NOISE}, #1A1A1A`,border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.875rem",padding:"1.25rem"};
const MUTED:React.CSSProperties={color:"rgba(225,224,204,0.4)",fontSize:"0.72rem"};
const INPUT_S:React.CSSProperties={background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:"0.5rem",padding:"0.45rem 0.75rem",color:"#E1E0CC",fontSize:"0.8rem",outline:"none",fontFamily:"'Almarai',sans-serif"};

const STATUS_STYLE:{[k:string]:React.CSSProperties}={
  Running:{background:"rgba(52,211,153,0.1)",border:"1px solid rgba(52,211,153,0.25)",color:"#34d399"},
  Scheduled:{background:"rgba(245,200,66,0.1)",border:"1px solid rgba(245,200,66,0.25)",color:"#F5C842"},
  Idle:{background:"rgba(255,255,255,0.04)",border:"1px solid transparent",color:"rgba(225,224,204,0.3)"},
};

function fmt(h:number){return h===0?"12 AM":h<12?`${h} AM`:h===12?"12 PM":`${h-12} PM`;}

// ── Add appliance modal ───────────────────────────────────────────────────────
function AddModal({onClose,onAdd}:{onClose:()=>void;onAdd:(a:Appliance)=>void}){
  const [name,setName]=useState("");
  const [cat,setCat]=useState("cooling");
  const [watts,setWatts]=useState(1000);
  const [hours,setHours]=useState(4);
  const [sched,setSched]=useState(true);
  const [startH,setStartH]=useState(22);
  const [endH,setEndH]=useState(6);

  function add(){
    if(!name.trim())return;
    onAdd({id:"u"+Date.now(),name,icon:ICONS[cat]??"🔌",category:cat,
      wattage_watts:watts,avg_daily_usage_hours:hours,is_schedulable:sched,
      preferred_start_hour:startH,preferred_end_hour:endH,status:"Idle"});
    onClose();
  }

  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.8)",backdropFilter:"blur(4px)",
      zIndex:50,display:"flex",alignItems:"center",justifyContent:"center",padding:"1rem"}}>
      <div style={{...CARD,width:"100%",maxWidth:420,animation:"fadeUp 0.25s ease"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1.25rem"}}>
          <div style={{fontSize:"0.92rem",fontWeight:600,color:"#E1E0CC"}}>Add Appliance</div>
          <button onClick={onClose}
            style={{background:"none",border:"none",color:"rgba(225,224,204,0.4)",cursor:"pointer",
              fontSize:"1.2rem",lineHeight:1}}>×</button>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:"0.75rem"}}>
          <div>
            <label style={{...MUTED,display:"block",marginBottom:4}}>Name</label>
            <input value={name} onChange={e=>setName(e.target.value)}
              placeholder="e.g. Bedroom AC" style={{...INPUT_S,width:"100%",boxSizing:"border-box"}}/>
          </div>
          <div>
            <label style={{...MUTED,display:"block",marginBottom:4}}>Category</label>
            <select value={cat} onChange={e=>setCat(e.target.value)}
              style={{...INPUT_S,width:"100%",boxSizing:"border-box",appearance:"none"}}>
              {["cooling","heating","washing","lighting","entertainment","other"].map(c=>(
                <option key={c} style={{background:"#111"}}>{c}</option>
              ))}
            </select>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div>
              <label style={{...MUTED,display:"block",marginBottom:4}}>Wattage (W)</label>
              <input type="number" value={watts} onChange={e=>setWatts(parseInt(e.target.value)||0)}
                style={{...INPUT_S,width:"100%",boxSizing:"border-box"}}/>
            </div>
            <div>
              <label style={{...MUTED,display:"block",marginBottom:4}}>Daily hours</label>
              <input type="number" step={0.5} value={hours} onChange={e=>setHours(parseFloat(e.target.value)||0)}
                style={{...INPUT_S,width:"100%",boxSizing:"border-box"}}/>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div onClick={()=>setSched(v=>!v)}
              style={{width:34,height:18,borderRadius:9,background:sched?"#F5C842":"rgba(255,255,255,0.1)",
                position:"relative",cursor:"pointer",transition:"background 0.2s",flexShrink:0}}>
              <div style={{position:"absolute",top:2,left:sched?16:2,width:14,height:14,borderRadius:"50%",
                background:sched?"#000":"rgba(255,255,255,0.5)",transition:"left 0.2s"}}/>
            </div>
            <span style={{fontSize:"0.8rem",color:"rgba(225,224,204,0.7)"}}>Schedulable</span>
          </div>
          {sched&&(
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <div>
                <label style={{...MUTED,display:"block",marginBottom:4}}>Preferred start</label>
                <select value={startH} onChange={e=>setStartH(parseInt(e.target.value))}
                  style={{...INPUT_S,width:"100%",boxSizing:"border-box",appearance:"none"}}>
                  {Array.from({length:24},(_,h)=><option key={h} value={h} style={{background:"#111"}}>{fmt(h)}</option>)}
                </select>
              </div>
              <div>
                <label style={{...MUTED,display:"block",marginBottom:4}}>Preferred end</label>
                <select value={endH} onChange={e=>setEndH(parseInt(e.target.value))}
                  style={{...INPUT_S,width:"100%",boxSizing:"border-box",appearance:"none"}}>
                  {Array.from({length:24},(_,h)=><option key={h} value={h} style={{background:"#111"}}>{fmt(h)}</option>)}
                </select>
              </div>
            </div>
          )}
        </div>
        <div style={{display:"flex",gap:8,marginTop:"1.25rem"}}>
          <button onClick={onClose}
            style={{flex:1,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.06)",
              borderRadius:"0.5rem",padding:"0.65rem",color:"rgba(225,224,204,0.5)",
              cursor:"pointer",fontSize:"0.82rem",fontFamily:"'Almarai',sans-serif"}}>Cancel</button>
          <button onClick={add}
            style={{flex:1,background:"#F5C842",border:"none",borderRadius:"0.5rem",
              padding:"0.65rem",color:"#000",fontWeight:700,
              cursor:"pointer",fontSize:"0.82rem",fontFamily:"'Almarai',sans-serif"}}>Add</button>
        </div>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function AppliancesPage(){
  const [items,setItems]=useState<Appliance[]>(DEMO);
  const [catFilter,setCatFilter]=useState("All");
  const [showAdd,setShowAdd]=useState(false);
  const [deleting,setDeleting]=useState<string|null>(null);

  useEffect(()=>{
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    fetch("/api/v1/appliances",{headers:token?{Authorization:`Bearer ${token}`}:{}})
      .then(r=>r.ok?r.json():null)
      .then(d=>{if(d?.appliances?.length)setItems(d.appliances);})
      .catch(()=>{});
  },[]);

  async function deleteAppl(id:string){
    setDeleting(id);
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    try{
      await fetch(`/api/v1/appliances/${id}`,{
        method:"DELETE",headers:token?{Authorization:`Bearer ${token}`}:{},
      });
    }catch{}
    setItems(a=>a.filter(x=>x.id!==id));
    setDeleting(null);
  }

  async function addAppl(a:Appliance){
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    try{
      await fetch("/api/v1/appliances",{
        method:"POST",
        headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},
        body:JSON.stringify(a),
      });
    }catch{}
    setItems(prev=>[...prev,a]);
  }

  const filtered=catFilter==="All"?items:items.filter(a=>a.category===catFilter.toLowerCase());

  const totalKwh=items.reduce((s,a)=>s+(a.wattage_watts/1000)*a.avg_daily_usage_hours,0);
  const estMonthly=totalKwh*30;
  const schedulable=items.filter(a=>a.is_schedulable).length;

  return(
    <div style={{background:"#000",minHeight:"100vh",color:"#E1E0CC",
      fontFamily:"'Almarai',sans-serif",padding:"1.5rem"}}>
      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        select option{background:#111}input,select{font-family:'Almarai',sans-serif}
        .del-btn:hover{color:#f87171!important}
      `}</style>
      {showAdd&&<AddModal onClose={()=>setShowAdd(false)} onAdd={addAppl}/>}

      {/* Header */}
      <div style={{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.875rem"}}>
        <Link href="/dashboard" style={{...MUTED,textDecoration:"none"}}>Dashboard</Link>
        <span style={{color:"rgba(225,224,204,0.2)"}}>›</span>
        <span style={{...MUTED,color:"rgba(225,224,204,0.6)"}}>Appliances</span>
      </div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"1.25rem"}}>
        <div>
          <h1 style={{fontSize:"1.5rem",fontWeight:700,color:"#E1E0CC",margin:0}}>My Appliances</h1>
          <p style={{...MUTED,marginTop:3}}>{items.length} appliances tracked · {schedulable} schedulable</p>
        </div>
        <button onClick={()=>setShowAdd(true)}
          style={{background:"#F5C842",color:"#000",border:"none",borderRadius:"0.625rem",
            padding:"0.6rem 1.25rem",fontWeight:700,fontSize:"0.82rem",cursor:"pointer",
            fontFamily:"'Almarai',sans-serif",boxShadow:"0 0 20px rgba(245,200,66,0.2)"}}>
          + Add Appliance
        </button>
      </div>

      {/* Summary stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"0.875rem",marginBottom:"1.25rem"}}>
        {[
          {label:"Daily Usage",value:`${totalKwh.toFixed(1)} kWh`,sub:"Combined all appliances",col:"#F5C842"},
          {label:"Monthly kWh",value:`${estMonthly.toFixed(0)} kWh`,sub:"Estimated consumption",col:"#E1E0CC"},
          {label:"Schedulable",value:`${schedulable}/${items.length}`,sub:"Can be optimized by AI",col:"#34d399"},
        ].map(s=>(
          <div key={s.label} style={CARD}>
            <div style={{...MUTED,marginBottom:4}}>{s.label}</div>
            <div style={{fontSize:"1.7rem",fontWeight:700,color:s.col,lineHeight:1,
              textShadow:s.col==="#F5C842"?"0 0 20px rgba(245,200,66,0.4)":
                s.col==="#34d399"?"0 0 20px rgba(52,211,153,0.35)":"none"}}>
              {s.value}
            </div>
            <div style={{...MUTED,marginTop:3}}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Category filter */}
      <div style={{display:"flex",gap:6,marginBottom:"1rem",flexWrap:"wrap"}}>
        {CATS.map(c=>(
          <button key={c} onClick={()=>setCatFilter(c)}
            style={{padding:"5px 14px",borderRadius:999,fontSize:"0.72rem",border:"1px solid",
              cursor:"pointer",fontFamily:"'Almarai',sans-serif",transition:"all 0.15s",
              background:catFilter===c?"rgba(245,200,66,0.1)":"rgba(255,255,255,0.03)",
              borderColor:catFilter===c?"rgba(245,200,66,0.35)":"rgba(255,255,255,0.06)",
              color:catFilter===c?"#F5C842":"rgba(225,224,204,0.4)"}}>
            {c}
          </button>
        ))}
      </div>

      {/* Appliance grid */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:"0.875rem"}}>
        {filtered.map((a,i)=>{
          const dailyKwh=(a.wattage_watts/1000)*a.avg_daily_usage_hours;
          const dailyCost=dailyKwh*5.5;
          return(
            <div key={a.id}
              style={{...CARD,animation:`fadeUp 0.3s ease ${i*0.05}s both`,margin:0,
                borderLeft:`3px solid ${a.is_schedulable?"rgba(245,200,66,0.4)":"rgba(255,255,255,0.1)"}`}}>
              {/* Header row */}
              <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:"0.875rem"}}>
                <div style={{display:"flex",alignItems:"center",gap:"0.625rem"}}>
                  <div style={{width:38,height:38,borderRadius:"0.5rem",
                    background:"rgba(255,255,255,0.04)",display:"flex",
                    alignItems:"center",justifyContent:"center",fontSize:"1.25rem",flexShrink:0}}>
                    {a.icon}
                  </div>
                  <div>
                    <div style={{fontSize:"0.88rem",fontWeight:600,color:"#E1E0CC"}}>{a.name}</div>
                    <div style={{fontSize:"0.65rem",color:"rgba(225,224,204,0.35)",textTransform:"capitalize"}}>
                      {a.category}
                    </div>
                  </div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <span style={{...STATUS_STYLE[a.status],fontSize:"0.6rem",fontWeight:700,
                    padding:"2px 8px",borderRadius:999,letterSpacing:"0.05em"}}>
                    {a.status}
                  </span>
                  <button className="del-btn"
                    onClick={()=>deleteAppl(a.id)}
                    disabled={deleting===a.id}
                    style={{background:"none",border:"none",cursor:"pointer",
                      color:"rgba(225,224,204,0.2)",fontSize:"1rem",lineHeight:1,
                      transition:"color 0.15s"}}>
                    {deleting===a.id?"…":"×"}
                  </button>
                </div>
              </div>

              {/* Stats row */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:4,marginBottom:"0.875rem"}}>
                {[
                  {l:"Wattage",v:`${a.wattage_watts}W`},
                  {l:"Daily",v:`${a.avg_daily_usage_hours}h`},
                  {l:"Cost/day",v:`₹${dailyCost.toFixed(1)}`},
                ].map(s=>(
                  <div key={s.l} style={{background:"rgba(0,0,0,0.4)",borderRadius:"0.4rem",
                    padding:"0.4rem 0.5rem",border:"1px solid rgba(255,255,255,0.04)"}}>
                    <div style={{fontSize:"0.55rem",color:"rgba(225,224,204,0.3)",marginBottom:2}}>{s.l}</div>
                    <div style={{fontSize:"0.8rem",fontWeight:600,color:"#F5C842"}}>{s.v}</div>
                  </div>
                ))}
              </div>

              {/* Schedule info */}
              {a.is_schedulable?(
                <div style={{background:"rgba(245,200,66,0.04)",border:"1px solid rgba(245,200,66,0.1)",
                  borderRadius:"0.4rem",padding:"0.45rem 0.625rem",
                  fontSize:"0.7rem",color:"rgba(225,224,204,0.5)"}}>
                  ⏰ Preferred: {fmt(a.preferred_start_hour)} → {fmt(a.preferred_end_hour)}
                </div>
              ):(
                <div style={{fontSize:"0.7rem",color:"rgba(225,224,204,0.25)"}}>
                  Always-on · not schedulable
                </div>
              )}
            </div>
          );
        })}

        {/* Add card CTA */}
        <div onClick={()=>setShowAdd(true)}
          style={{...CARD,margin:0,border:"1px dashed rgba(255,255,255,0.08)",
            display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
            cursor:"pointer",minHeight:160,gap:"0.5rem",transition:"border-color 0.2s"}}
          onMouseEnter={e=>(e.currentTarget.style.borderColor="rgba(245,200,66,0.25)")}
          onMouseLeave={e=>(e.currentTarget.style.borderColor="rgba(255,255,255,0.08)")}>
          <div style={{width:36,height:36,borderRadius:"50%",
            background:"rgba(245,200,66,0.08)",border:"1px solid rgba(245,200,66,0.2)",
            display:"flex",alignItems:"center",justifyContent:"center",
            fontSize:"1.25rem",color:"#F5C842"}}>+</div>
          <div style={{fontSize:"0.8rem",color:"rgba(225,224,204,0.35)"}}>Add Appliance</div>
        </div>
      </div>

      {filtered.length===0&&(
        <div style={{textAlign:"center",padding:"3rem",color:"rgba(225,224,204,0.2)",fontSize:"0.85rem"}}>
          No {catFilter!=="All"?catFilter+" ":""}appliances found
        </div>
      )}
    </div>
  );
}
