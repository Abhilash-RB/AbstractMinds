"use client";
import { useState, useRef, useEffect, useCallback } from "react";
import Link from "next/link";

// ── Types ─────────────────────────────────────────────────────────────────────
type Role = "user" | "ai";
interface Msg { id: string; role: Role; text: string; streaming?: boolean; }

// ── Constants ─────────────────────────────────────────────────────────────────
const WELCOME: Msg = {
  id:"welcome", role:"ai",
  text:"Hi! I'm your ThunderVolts AI advisor. I can see you're in Bangalore on BESCOM tariffs.\n\nYour estimated bill this month is ₹1,240. Peak hours today are 6–10 AM and 6–10 PM, where rates jump to ₹7.50/unit.\n\nHow can I help you save more? 💡",
};

const QUICK_QS = [
  "Why is my bill high?",
  "Best time to run AC?",
  "How do I save ₹500/month?",
  "Explain my peak hours",
  "Plan my week's schedule",
];

const CONTEXT_PILLS = [
  {icon:"📍", text:"Bangalore, BESCOM"},
  {icon:"⚡", text:"Peak: 6–10 AM, 6–10 PM"},
  {icon:"💰", text:"This month: ₹1,240 est."},
  {icon:"🏠", text:"4 appliances tracked"},
];

const DEMO_RESPONSES: Record<string, string> = {
  default: "Based on your BESCOM tariff profile, your Air Conditioner is your biggest cost driver — accounting for around 48% of your monthly bill. Running it during peak hours (6–10 AM and 6–10 PM) costs ₹7.50/unit instead of ₹3.50/unit during off-peak hours.\n\nHere are 3 quick wins:\n\n1. **Shift AC to 11 PM–5 AM** — saves approximately ₹140/month\n2. **Run your geyser at 5 AM** instead of 7 AM — saves ₹45/month\n3. **Washing machine at 11 AM** (shoulder rate) instead of 9 AM — saves ₹22/month\n\nTotal estimated saving: **₹207/month** 🎯",
  "Why is my bill high?": "Your bill is high primarily because of two factors:\n\n**1. Peak hour usage** — Your AC runs during 6–9 PM when BESCOM charges ₹7.50/unit. That's 2.1× the off-peak rate of ₹3.50/unit.\n\n**2. AC dominance** — At 1500W running 6+ hours/day, your AC alone accounts for ₹680 of your ₹1,240 estimated bill.\n\nThe good news: shifting your AC to run after 10 PM could cut your bill by ₹180–220 this month without any change in comfort. Want me to create an optimized schedule?",
  "Best time to run AC?": "The cheapest window for your AC on BESCOM is **10 PM to 6 AM** — off-peak rate of ₹3.50/unit vs ₹7.50/unit during peak hours.\n\n**Cost comparison for 6 hours of AC:**\n• Peak hours (6–10 PM): 1.5 kW × 6h × ₹7.50 = **₹67.50**\n• Off-peak (10 PM–4 AM): 1.5 kW × 6h × ₹3.50 = **₹31.50**\n\nThat's a **₹36 saving per day**, or **₹1,080/month** 📊\n\nIf you need daytime cooling, 10 AM–6 PM (shoulder rate ₹5.50) is the next best option.",
  "How do I save ₹500/month?": "Saving ₹500/month on your BESCOM bill is very achievable! Here's a plan:\n\n**High Impact (₹340 savings)**\n• Shift AC to 11 PM–5 AM daily → ₹180/month\n• Move geyser to 5 AM (pre-peak) → ₹90/month\n• Washing machine to 11 AM → ₹70/month\n\n**Medium Impact (₹160 savings)**\n• Enable Eco mode on AC (24°C instead of 20°C) → ₹80/month\n• Switch remaining incandescent bulbs to LED → ₹45/month\n• Reduce standby power (TV/set-top box) → ₹35/month\n\n**Total: ₹500/month** ✅\n\nShall I create an automated daily schedule to lock these in?",
  "Explain my peak hours": "**BESCOM Peak Hours** (₹7.50/unit):\n• **Morning Peak**: 6:00 AM – 10:00 AM\n• **Evening Peak**: 6:00 PM – 10:00 PM\n\n**Shoulder Hours** (₹5.50/unit):\n• 10:00 AM – 6:00 PM\n\n**Off-Peak** (₹3.50/unit):\n• 10:00 PM – 6:00 AM\n\nDuring peak hours, BESCOM charges more because grid demand is highest — morning showers/cooking and evening AC/lighting all coincide.\n\nThe **golden window** for heavy appliances (AC, EV charger, washing machine) is **10 PM to 6 AM** — you pay less than half the peak rate. 🌙",
  "Plan my week's schedule": "Here's your optimized 7-day energy schedule:\n\n**Every Night (10 PM – 6 AM)**\n• ❄️ AC: Run freely at ₹3.50/unit\n• 🔌 EV Charger: 11 PM – 5 AM (if applicable)\n\n**Every Morning (5–6 AM)**\n• 🚿 Geyser: 30–45 min at ₹3.50/unit (pre-peak)\n\n**Weekdays (11 AM – 1 PM)**\n• 🫧 Washing Machine: shoulder rate ₹5.50/unit\n\n**Weekends**\n• Best day for laundry: Saturday 11 AM\n• Avoid running heavy loads on Sunday evenings\n\n**Estimated weekly savings vs default schedule: ₹175–₹210**\n\nWant me to push this to your Scheduler automatically?",
};

// ── Helpers ───────────────────────────────────────────────────────────────────
function uuid(){ return Math.random().toString(36).slice(2)+Date.now().toString(36); }

const NOISE=`url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E")`;
const CARD:React.CSSProperties={background:`${NOISE}, #1A1A1A`,border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.875rem"};
const MUTED:React.CSSProperties={color:"rgba(225,224,204,0.4)",fontSize:"0.72rem"};
const SEC_LBL:React.CSSProperties={fontSize:"0.6rem",letterSpacing:"0.1em",textTransform:"uppercase",color:"rgba(245,200,66,0.6)",fontWeight:700,display:"block",marginBottom:"0.5rem"};

// Render markdown-ish bold
function RenderText({text}:{text:string}){
  const parts=text.split(/(\*\*[^*]+\*\*)/g);
  return(
    <>
      {parts.map((p,i)=>
        p.startsWith("**")&&p.endsWith("**")
          ?<strong key={i} style={{color:"#E1E0CC",fontWeight:700}}>{p.slice(2,-2)}</strong>
          :<span key={i}>{p}</span>
      )}
    </>
  );
}

function MsgBubble({msg}:{msg:Msg}){
  const isAI=msg.role==="ai";
  const lines=msg.text.split("\n");
  return(
    <div style={{display:"flex",justifyContent:isAI?"flex-start":"flex-end",marginBottom:"0.875rem",
      animation:"fadeUp 0.25s ease"}}>
      {isAI&&(
        <div style={{width:26,height:26,borderRadius:"50%",background:"rgba(245,200,66,0.12)",
          border:"1px solid rgba(245,200,66,0.2)",display:"flex",alignItems:"center",
          justifyContent:"center",flexShrink:0,marginRight:"0.5rem",marginTop:2}}>
          <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#F5C842"
            strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
            <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
          </svg>
        </div>
      )}
      <div style={{
        maxWidth:isAI?"80%":"70%",
        background:isAI?"rgba(0,0,0,0.6)":
          "linear-gradient(135deg,rgba(245,200,66,0.08),rgba(245,200,66,0.04))",
        border:isAI?"1px solid rgba(255,255,255,0.04)":"1px solid rgba(245,200,66,0.15)",
        borderRadius:isAI?"1rem 1rem 1rem 0.25rem":"1rem 0.25rem 1rem 1rem",
        padding:"0.75rem 1rem",
        fontSize:"0.82rem",color:isAI?"rgba(225,224,204,0.8)":"rgba(225,224,204,0.95)",
        lineHeight:1.7,
      }}>
        {lines.map((line,i)=>(
          <div key={i} style={{marginBottom:line===""?"0.5rem":0}}>
            {line===""?null:<RenderText text={line}/>}
          </div>
        ))}
        {msg.streaming&&(
          <span style={{display:"inline-block",width:2,height:"1em",
            background:"#F5C842",marginLeft:2,verticalAlign:"text-bottom",
            animation:"blink 0.9s steps(1) infinite"}}/>
        )}
      </div>
    </div>
  );
}

function TypingDots(){
  return(
    <div style={{display:"flex",marginBottom:"0.875rem"}}>
      <div style={{width:26,height:26,borderRadius:"50%",background:"rgba(245,200,66,0.12)",
        border:"1px solid rgba(245,200,66,0.2)",display:"flex",alignItems:"center",
        justifyContent:"center",flexShrink:0,marginRight:"0.5rem"}}>
        <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#F5C842"
          strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
        </svg>
      </div>
      <div style={{background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.04)",
        borderRadius:"1rem 1rem 1rem 0.25rem",padding:"0.75rem 1rem",
        display:"flex",gap:5,alignItems:"center"}}>
        {[0,1,2].map(i=>(
          <div key={i} style={{width:6,height:6,borderRadius:"50%",background:"#F5C842",
            animation:`pulse 1.2s ease-in-out ${i*0.2}s infinite`}}/>
        ))}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function ChatPage(){
  const [msgs,setMsgs]=useState<Msg[]>([WELCOME]);
  const [input,setInput]=useState("");
  const [streaming,setStreaming]=useState(false);
  const [typing,setTyping]=useState(false);
  const [toast,setToast]=useState<{text:string;type:"error"|"warn"}|null>(null);
  const [sessionId]=useState(()=>uuid());
  const bottomRef=useRef<HTMLDivElement>(null);
  const textareaRef=useRef<HTMLTextAreaElement>(null);
  const abortRef=useRef<AbortController|null>(null);

  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[msgs,typing]);

  function showToast(text:string,type:"error"|"warn"){
    setToast({text,type});
    setTimeout(()=>setToast(null),4000);
  }

  // Demo streaming fallback
  function demoStream(msgId:string,question:string){
    const response=DEMO_RESPONSES[question]??DEMO_RESPONSES.default;
    let i=0;
    const iv=setInterval(()=>{
      i+=3;
      setMsgs(m=>m.map(x=>x.id===msgId?{...x,text:response.slice(0,i),streaming:i<response.length}:x));
      if(i>=response.length){
        clearInterval(iv);
        setStreaming(false);
        setTyping(false);
      }
    },18);
  }

  const sendMessage=useCallback(async(text:string)=>{
    const trimmed=text.trim();
    if(!trimmed||streaming)return;
    setInput("");
    if(textareaRef.current){textareaRef.current.style.height="auto";}

    const userMsg:Msg={id:uuid(),role:"user",text:trimmed};
    const aiId=uuid();
    const aiMsg:Msg={id:aiId,role:"ai",text:"",streaming:true};

    setMsgs(m=>[...m,userMsg]);
    setTyping(true);
    setStreaming(true);

    await new Promise(r=>setTimeout(r,600));
    setTyping(false);
    setMsgs(m=>[...m,aiMsg]);

    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";

    try{
      abortRef.current=new AbortController();
      const res=await fetch("/api/v1/ai/chat",{
        method:"POST",
        headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},
        body:JSON.stringify({message:trimmed,session_id:sessionId}),
        signal:abortRef.current.signal,
      });

      if(res.status===429){
        showToast("20 messages per hour limit reached. Please wait.","warn");
        setMsgs(m=>m.filter(x=>x.id!==aiId));
        setStreaming(false);return;
      }
      if(!res.ok||!res.body)throw new Error("API unavailable");

      const reader=res.body.getReader();
      const decoder=new TextDecoder();
      let buf="";

      while(true){
        const {done,value}=await reader.read();
        if(done)break;
        const chunk=decoder.decode(value,{stream:true});
        const lines=chunk.split("\n");
        for(const line of lines){
          if(line.startsWith("data:")){
            const data=line.slice(5).trim();
            if(data==="[DONE]"){break;}
            try{
              const parsed=JSON.parse(data);
              const token=parsed.token??parsed.text??parsed.content??"";
              buf+=token;
              const snap=buf;
              setMsgs(m=>m.map(x=>x.id===aiId?{...x,text:snap}:x));
            }catch{
              // raw text fallback
              buf+=data;
              const snap=buf;
              setMsgs(m=>m.map(x=>x.id===aiId?{...x,text:snap}:x));
            }
          }
        }
      }
      setMsgs(m=>m.map(x=>x.id===aiId?{...x,streaming:false}:x));
      setStreaming(false);

    }catch(e:unknown){
      const isAbort=(e instanceof DOMException&&e.name==="AbortError");
      if(!isAbort){
        // Demo fallback
        demoStream(aiId,trimmed);
      }
    }
  },[sessionId,streaming]);

  function handleKey(e:React.KeyboardEvent<HTMLTextAreaElement>){
    if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage(input);}
  }

  function autoResize(e:React.ChangeEvent<HTMLTextAreaElement>){
    const el=e.target;
    el.style.height="auto";
    el.style.height=Math.min(el.scrollHeight,120)+"px";
    setInput(el.value);
  }

  return(
    <div style={{background:"#000",minHeight:"100vh",color:"#E1E0CC",
      fontFamily:"'Almarai',sans-serif",padding:"1.25rem",display:"flex",flexDirection:"column"}}>

      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
        @keyframes pulse{0%,80%,100%{transform:scale(0.6);opacity:0.4}40%{transform:scale(1);opacity:1}}
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        .chat-scroll::-webkit-scrollbar{width:4px}
        .chat-scroll::-webkit-scrollbar-track{background:transparent}
        .chat-scroll::-webkit-scrollbar-thumb{background:rgba(245,200,66,0.25);border-radius:2px}
        .qpill:hover{border-color:rgba(245,200,66,0.35)!important;color:rgba(225,224,204,0.85)!important;}
      `}</style>

      {/* Breadcrumb */}
      <div style={{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"1rem"}}>
        <Link href="/dashboard" style={{...MUTED,textDecoration:"none"}}>Dashboard</Link>
        <span style={{color:"rgba(225,224,204,0.2)"}}>›</span>
        <span style={{...MUTED,color:"rgba(225,224,204,0.6)"}}>AI Advisor</span>
      </div>

      {/* Toast */}
      {toast&&(
        <div style={{position:"fixed",top:24,right:24,zIndex:100,
          background:toast.type==="error"?"rgba(248,113,113,0.15)":"rgba(245,200,66,0.12)",
          border:`1px solid ${toast.type==="error"?"rgba(248,113,113,0.4)":"rgba(245,200,66,0.35)"}`,
          borderRadius:"0.625rem",padding:"0.75rem 1.25rem",
          color:toast.type==="error"?"#f87171":"#F5C842",fontSize:"0.8rem",
          boxShadow:"0 4px 24px rgba(0,0,0,0.4)",animation:"fadeUp 0.3s ease"}}>
          {toast.text}
        </div>
      )}

      {/* Two-column layout */}
      <div style={{display:"grid",gridTemplateColumns:"240px 1fr",gap:"1rem",flex:1,minHeight:0}}>

        {/* ── LEFT SIDEBAR ── */}
        <div style={{...CARD,padding:"1.25rem",display:"flex",flexDirection:"column",gap:"1.25rem",
          height:"calc(100vh - 8rem)",overflowY:"auto"}}>

          {/* AI avatar */}
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:"0.5rem",
            paddingBottom:"1rem",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
            <div style={{width:48,height:48,borderRadius:"0.75rem",
              background:"rgba(245,200,66,0.1)",border:"1px solid rgba(245,200,66,0.2)",
              display:"flex",alignItems:"center",justifyContent:"center"}}>
              <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#F5C842"
                strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
              </svg>
            </div>
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:"0.85rem",fontWeight:600,color:"#E1E0CC"}}>ThunderVolts AI</div>
              <div style={{fontSize:"0.62rem",color:"rgba(225,224,204,0.3)"}}>Powered by Claude</div>
            </div>
          </div>

          {/* Context pills */}
          <div>
            <span style={SEC_LBL}>Your Context</span>
            {CONTEXT_PILLS.map(p=>(
              <div key={p.text} style={{background:"rgba(0,0,0,0.4)",borderRadius:"0.5rem",
                padding:"0.45rem 0.75rem",marginBottom:"0.375rem",
                fontSize:"0.72rem",color:"rgba(225,224,204,0.6)",
                display:"flex",alignItems:"center",gap:"0.5rem",
                border:"1px solid rgba(255,255,255,0.03)"}}>
                <span>{p.icon}</span>
                <span>{p.text}</span>
              </div>
            ))}
          </div>

          {/* Quick questions */}
          <div>
            <span style={SEC_LBL}>Ask me about:</span>
            <div style={{display:"flex",flexDirection:"column",gap:"0.375rem"}}>
              {QUICK_QS.map(q=>(
                <button key={q} className="qpill"
                  onClick={()=>sendMessage(q)}
                  disabled={streaming}
                  style={{background:"rgba(255,255,255,0.03)",
                    border:"1px solid rgba(255,255,255,0.06)",
                    borderRadius:999,padding:"0.4rem 0.75rem",
                    fontSize:"0.7rem",color:"rgba(225,224,204,0.5)",
                    cursor:streaming?"not-allowed":"pointer",textAlign:"left",
                    transition:"border-color 0.2s,color 0.2s",
                    opacity:streaming?0.5:1}}>
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Session info */}
          <div style={{marginTop:"auto",paddingTop:"0.75rem",borderTop:"1px solid rgba(255,255,255,0.06)"}}>
            <div style={{fontSize:"0.6rem",color:"rgba(225,224,204,0.2)",lineHeight:1.6}}>
              Session: {sessionId.slice(0,8)}…
            </div>
            <div style={{fontSize:"0.6rem",color:"rgba(225,224,204,0.2)"}}>
              {msgs.length-1} message{msgs.length!==2?"s":""} this session
            </div>
            <button onClick={()=>{setMsgs([WELCOME]);setInput("");}}
              style={{marginTop:"0.5rem",background:"none",border:"1px solid rgba(255,255,255,0.06)",
                borderRadius:"0.4rem",padding:"0.3rem 0.75rem",fontSize:"0.65rem",
                color:"rgba(225,224,204,0.35)",cursor:"pointer",width:"100%"}}>
              Clear chat
            </button>
          </div>
        </div>

        {/* ── RIGHT CHAT ── */}
        <div style={{...CARD,display:"flex",flexDirection:"column",
          height:"calc(100vh - 8rem)",overflow:"hidden"}}>

          {/* Chat header */}
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",
            padding:"0.875rem 1.25rem",borderBottom:"1px solid rgba(255,255,255,0.06)",flexShrink:0}}>
            <div style={{display:"flex",alignItems:"center",gap:"0.75rem"}}>
              <div style={{width:34,height:34,borderRadius:"50%",
                background:"rgba(245,200,66,0.12)",border:"1px solid rgba(245,200,66,0.2)",
                display:"flex",alignItems:"center",justifyContent:"center"}}>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#F5C842"
                  strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
                </svg>
              </div>
              <div>
                <div style={{fontSize:"0.85rem",fontWeight:600,color:"#E1E0CC"}}>AI Energy Advisor</div>
                <div style={{fontSize:"0.65rem",color:"rgba(225,224,204,0.35)"}}>Personalized energy insights</div>
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:"0.5rem"}}>
              <div style={{width:7,height:7,borderRadius:"50%",background:"#34d399",
                boxShadow:"0 0 8px rgba(52,211,153,0.6)",animation:"pulse 2s ease infinite"}}/>
              <span style={{fontSize:"0.7rem",color:"#34d399"}}>Online</span>
            </div>
          </div>

          {/* Messages */}
          <div className="chat-scroll"
            style={{flex:1,overflowY:"auto",padding:"1.25rem",display:"flex",flexDirection:"column"}}>
            {msgs.map(m=><MsgBubble key={m.id} msg={m}/>)}
            {typing&&<TypingDots/>}
            <div ref={bottomRef}/>
          </div>

          {/* Input area */}
          <div style={{borderTop:"1px solid rgba(255,255,255,0.06)",
            padding:"0.875rem 1.25rem",display:"flex",alignItems:"flex-end",gap:"0.75rem",flexShrink:0}}>
            <textarea
              ref={textareaRef}
              rows={1}
              value={input}
              onChange={autoResize}
              onKeyDown={handleKey}
              disabled={streaming}
              placeholder="Ask about your energy usage..."
              style={{flex:1,background:"rgba(0,0,0,0.6)",
                border:`1px solid ${input?"rgba(245,200,66,0.25)":"rgba(255,255,255,0.08)"}`,
                borderRadius:"0.875rem",padding:"0.7rem 1rem",
                color:"#E1E0CC",fontSize:"0.85rem",lineHeight:1.6,
                outline:"none",resize:"none",fontFamily:"'Almarai',sans-serif",
                transition:"border-color 0.2s",
                opacity:streaming?0.7:1,
                minHeight:42,maxHeight:120,overflowY:"auto"}}/>
            <button
              onClick={()=>sendMessage(input)}
              disabled={!input.trim()||streaming}
              style={{width:42,height:42,borderRadius:"0.625rem",
                background:input.trim()&&!streaming?"#F5C842":"rgba(245,200,66,0.2)",
                border:"none",display:"flex",alignItems:"center",justifyContent:"center",
                cursor:input.trim()&&!streaming?"pointer":"not-allowed",
                flexShrink:0,transition:"background 0.2s",
                opacity:!input.trim()||streaming?0.5:1}}>
              {streaming?(
                <svg style={{animation:"spin 1s linear infinite"}} width={16} height={16}
                  viewBox="0 0 24 24" fill="none"
                  stroke={input.trim()?"#000":"rgba(245,200,66,0.6)"}
                  strokeWidth={2.5} strokeLinecap="round">
                  <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
                </svg>
              ):(
                <svg width={16} height={16} viewBox="0 0 24 24" fill="none"
                  stroke={input.trim()?"#000":"rgba(245,200,66,0.5)"}
                  strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"/>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
              )}
            </button>
          </div>

          {/* Hint */}
          <div style={{textAlign:"center",paddingBottom:"0.5rem",
            fontSize:"0.6rem",color:"rgba(225,224,204,0.15)"}}>
            Enter to send · Shift+Enter for new line · Responses stream in real-time
          </div>
        </div>
      </div>
    </div>
  );
}
