"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// ── Types ─────────────────────────────────────────────────────────────────────
type Severity = "high" | "medium" | "low";
interface Anomaly {
  id: string; severity: Severity; icon: string; appliance: string;
  description: string; timestamp: string; unread: boolean;
  extra_cost_inr: number; usage_data: number[];
}

// ── Demo data ─────────────────────────────────────────────────────────────────
const DEMO: Anomaly[] = [
  { id:"a1", severity:"high",   icon:"🚿", appliance:"Geyser",
    description:"Running 3× longer than usual — 87 minutes vs normal 28 minutes at 6:42 AM",
    timestamp:"Today, 6:42 AM", unread:true, extra_cost_inr:185,
    usage_data:[28,30,26,29,27,31,87] },
  { id:"a2", severity:"medium", icon:"❄️", appliance:"Air Conditioner",
    description:"Running outside scheduled hours — activated at 2:15 AM, ran for 3.5 hours",
    timestamp:"Yesterday, 2:15 AM", unread:true, extra_cost_inr:132,
    usage_data:[120,115,118,122,119,116,210] },
  { id:"a3", severity:"medium", icon:"🫧", appliance:"Washing Machine",
    description:"Used during peak hours (7:30 PM) — cost ₹12.80 vs ₹5.97 off-peak",
    timestamp:"2 days ago, 7:30 PM", unread:false, extra_cost_inr:68,
    usage_data:[0,1,0,0,1,0,1] },
  { id:"a4", severity:"low",    icon:"💡", appliance:"Lights",
    description:"Left on for 18 hours straight — no motion detected after 11 PM",
    timestamp:"3 days ago", unread:false, extra_cost_inr:35,
    usage_data:[5,6,5,6,5,6,18] },
];

// ── Styles ────────────────────────────────────────────────────────────────────
const NOISE=`url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E")`;
const CARD:React.CSSProperties={background:`${NOISE}, #1A1A1A`,border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.875rem",padding:"1.25rem"};
const MUTED:React.CSSProperties={color:"rgba(225,224,204,0.4)",fontSize:"0.72rem"};

const SEV:{[k in Severity]:{badge:React.CSSProperties;border:string;label:string;dot:string}} = {
  high:  { badge:{background:"rgba(248,113,113,0.1)",color:"#f87171"}, border:"#f87171", label:"HIGH",   dot:"#f87171" },
  medium:{ badge:{background:"rgba(245,200,66,0.1)", color:"#F5C842"}, border:"#F5C842", label:"MEDIUM", dot:"#F5C842" },
  low:   { badge:{background:"rgba(255,255,255,0.05)",color:"rgba(225,224,204,0.4)"}, border:"rgba(255,255,255,0.18)", label:"LOW", dot:"rgba(225,224,204,0.3)" },
};

// ── Mini sparkline ────────────────────────────────────────────────────────────
function Sparkline({data,severity}:{data:number[];severity:Severity}){
  const W=64,H=24;
  const max=Math.max(...data,1);
  const pts=data.map((v,i)=>({x:(i/(data.length-1))*W,y:H-2-((v/max)*(H-4))}));
  const d=pts.map((p,i)=>`${i===0?"M":"L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const lastPt=pts[pts.length-1];
  return(
    <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{display:"block",flexShrink:0}}>
      <path d={d} fill="none" stroke="rgba(245,200,66,0.35)" strokeWidth={1.5}
        strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={lastPt.x} cy={lastPt.y} r={2.5}
        fill={severity==="high"?"#f87171":severity==="medium"?"#F5C842":"rgba(225,224,204,0.4)"}/>
    </svg>
  );
}

// ── Anomaly card ──────────────────────────────────────────────────────────────
function AnomalyCard({a,onRead}:{a:Anomaly;onRead:(id:string)=>void}){
  const router=useRouter();
  const s=SEV[a.severity];

  function askAI(){
    const q=`I have an anomaly: ${a.appliance} — ${a.description}. What should I do?`;
    router.push(`/dashboard/chat?q=${encodeURIComponent(q)}`);
  }

  return(
    <div onClick={()=>a.unread&&onRead(a.id)}
      style={{...CARD,padding:0,overflow:"hidden",
        borderLeft:`4px solid ${s.border}`,cursor:"default",
        transition:"box-shadow 0.2s"}}>
      <div style={{padding:"1.1rem 1.25rem"}}>
        {/* Row 1: badge + appliance + timestamp */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.5rem"}}>
          <div style={{display:"flex",alignItems:"center",gap:"0.5rem"}}>
            <span style={{...s.badge,fontSize:"0.55rem",fontWeight:700,letterSpacing:"0.08em",
              textTransform:"uppercase",borderRadius:999,padding:"2px 8px",
              border:`1px solid ${s.dot}33`}}>
              {s.label}
            </span>
            <span style={{fontSize:"0.88rem",fontWeight:600,color:"#E1E0CC"}}>
              {a.icon} {a.appliance}
            </span>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:"0.5rem"}}>
            <span style={{...MUTED,fontSize:"0.65rem"}}>{a.timestamp}</span>
            {a.unread&&(
              <div style={{width:7,height:7,borderRadius:"50%",background:"#F5C842",
                boxShadow:"0 0 6px rgba(245,200,66,0.5)",flexShrink:0}}/>
            )}
          </div>
        </div>

        {/* Row 2: description */}
        <p style={{fontSize:"0.8rem",color:"rgba(225,224,204,0.6)",
          lineHeight:1.55,margin:"0 0 0.75rem 0"}}>
          {a.description}
        </p>

        {/* Row 3: sparkline + extra cost + actions */}
        <div style={{display:"flex",alignItems:"center",gap:"1rem"}}>
          <Sparkline data={a.usage_data} severity={a.severity}/>
          <div style={{flex:1,fontSize:"0.65rem",color:"rgba(225,224,204,0.3)"}}>
            7-day pattern
          </div>
          <div style={{display:"flex",alignItems:"center",gap:4,...MUTED,fontSize:"0.65rem"}}>
            Extra cost:
            <span style={{color:a.severity==="high"?"#f87171":a.severity==="medium"?"#F5C842":"rgba(225,224,204,0.5)",
              fontWeight:700}}>₹{a.extra_cost_inr}</span>
          </div>
          <div style={{display:"flex",gap:"0.875rem",alignItems:"center"}}>
            <Link href={`/dashboard/anomalies/${a.id}`}
              style={{fontSize:"0.72rem",color:"rgba(225,224,204,0.4)",textDecoration:"none",
                transition:"color 0.15s"}}
              onMouseEnter={e=>(e.currentTarget.style.color="rgba(225,224,204,0.75)")}
              onMouseLeave={e=>(e.currentTarget.style.color="rgba(225,224,204,0.4)")}>
              View Details
            </Link>
            <button onClick={askAI}
              style={{fontSize:"0.72rem",color:"#F5C842",background:"none",border:"none",
                cursor:"pointer",fontFamily:"inherit",padding:0,
                transition:"opacity 0.15s"}}
              onMouseEnter={e=>(e.currentTarget.style.opacity="0.7")}
              onMouseLeave={e=>(e.currentTarget.style.opacity="1")}>
              Ask AI ⚡
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function AnomaliesPage(){
  const [filter,setFilter]=useState<"All"|Severity>("All");
  const [items,setItems]=useState<Anomaly[]>(DEMO);
  const [loading,setLoading]=useState(true);

  useEffect(()=>{
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    fetch("/api/v1/predictions/anomalies",{
      headers:token?{Authorization:`Bearer ${token}`}:{},
    }).then(r=>r.ok?r.json():null)
      .then(d=>{if(d?.anomalies?.length)setItems(d.anomalies);})
      .catch(()=>{})
      .finally(()=>setLoading(false));
  },[]);

  async function markRead(id:string){
    setItems(a=>a.map(x=>x.id===id?{...x,unread:false}:x));
    const token=typeof window!=="undefined"?localStorage.getItem("tv_token"):"";
    try{
      await fetch(`/api/v1/alerts/${id}/read`,{
        method:"PUT",headers:token?{Authorization:`Bearer ${token}`}:{},
      });
    }catch{}
  }

  const filtered=filter==="All"?items:items.filter(a=>a.severity===filter.toLowerCase());
  const unreadCount=items.filter(a=>a.unread).length;
  const totalWaste=items.reduce((s,a)=>s+a.extra_cost_inr,0);
  const resolved=2;

  const FILTER_PILLS:(("All"|Severity)[])=["All","high","medium","low"];
  const FILTER_LABELS:{[k:string]:string}={All:"All",high:"High",medium:"Medium",low:"Low"};

  return(
    <div style={{background:"#000",minHeight:"100vh",color:"#E1E0CC",
      fontFamily:"'Almarai',sans-serif",padding:"1.5rem"}}>

      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`}</style>

      {/* Breadcrumb */}
      <div style={{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.875rem"}}>
        <Link href="/dashboard" style={{...MUTED,textDecoration:"none"}}>Dashboard</Link>
        <span style={{color:"rgba(225,224,204,0.2)"}}>›</span>
        <span style={{...MUTED,color:"rgba(225,224,204,0.6)"}}>Anomalies</span>
      </div>

      {/* Page header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"1.25rem"}}>
        <div>
          <h1 style={{fontSize:"1.5rem",fontWeight:700,color:"#E1E0CC",margin:0}}>Energy Anomalies</h1>
          <p style={{...MUTED,marginTop:3}}>AI-detected unusual patterns in your appliance usage</p>
        </div>
        {/* Filter pills */}
        <div style={{display:"flex",gap:6}}>
          {FILTER_PILLS.map(f=>{
            const active=filter===f;
            const col=f==="high"?"#f87171":f==="medium"?"#F5C842":f==="low"?"rgba(225,224,204,0.5)":"#F5C842";
            return(
              <button key={f} onClick={()=>setFilter(f)}
                style={{padding:"5px 14px",borderRadius:999,fontSize:"0.72rem",
                  fontWeight:active?600:400,cursor:"pointer",border:"1px solid",
                  background:active?`rgba(${f==="high"?"248,113,113":f==="medium"?"245,200,66":f==="low"?"255,255,255":"245,200,66"},0.08)`:"rgba(255,255,255,0.03)",
                  borderColor:active?`${col}50`:"rgba(255,255,255,0.06)",
                  color:active?col:"rgba(225,224,204,0.35)"}}>
                {FILTER_LABELS[f]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Stats row */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"0.875rem",marginBottom:"1.25rem"}}>
        {/* Card 1 */}
        <div style={CARD}>
          <div style={{display:"flex",alignItems:"center",gap:"0.625rem",marginBottom:"0.5rem"}}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#F5C842"
              strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
            <span style={{...MUTED,fontSize:"0.65rem"}}>Active Alerts</span>
          </div>
          <div style={{fontSize:"2rem",fontWeight:700,color:"#F5C842",
            textShadow:"0 0 20px rgba(245,200,66,0.4)",lineHeight:1}}>{unreadCount}</div>
          <div style={{...MUTED,fontSize:"0.65rem",marginTop:3}}>Require your attention</div>
        </div>

        {/* Card 2 */}
        <div style={CARD}>
          <div style={{display:"flex",alignItems:"center",gap:"0.625rem",marginBottom:"0.5rem"}}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#34d399"
              strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
              <polyline points="22 4 12 14.01 9 11.01"/>
            </svg>
            <span style={{...MUTED,fontSize:"0.65rem"}}>Resolved This Week</span>
          </div>
          <div style={{fontSize:"2rem",fontWeight:700,color:"#34d399",
            textShadow:"0 0 20px rgba(52,211,153,0.4)",lineHeight:1}}>{resolved}</div>
          <div style={{...MUTED,fontSize:"0.65rem",marginTop:3}}>Issues fixed</div>
        </div>

        {/* Card 3 */}
        <div style={CARD}>
          <div style={{display:"flex",alignItems:"center",gap:"0.625rem",marginBottom:"0.5rem"}}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#f87171"
              strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/>
              <polyline points="17 6 23 6 23 12"/>
            </svg>
            <span style={{...MUTED,fontSize:"0.65rem"}}>Potential Waste</span>
          </div>
          <div style={{fontSize:"2rem",fontWeight:700,color:"#f87171",
            textShadow:"0 0 20px rgba(248,113,113,0.35)",lineHeight:1}}>₹{totalWaste}</div>
          <div style={{...MUTED,fontSize:"0.65rem",marginTop:3}}>Detected this month</div>
        </div>
      </div>

      {/* Anomaly list */}
      {loading?(
        <div style={{display:"flex",justifyContent:"center",padding:"3rem",
          color:"rgba(225,224,204,0.2)",fontSize:"0.85rem"}}>Loading anomalies…</div>
      ):filtered.length===0?(
        <div style={{...CARD,textAlign:"center",padding:"3rem",color:"rgba(225,224,204,0.2)"}}>
          <div style={{fontSize:"2rem",marginBottom:"0.5rem"}}>✅</div>
          <div style={{fontSize:"0.875rem"}}>No {filter!=="All"?filter+" ":""}anomalies detected</div>
        </div>
      ):(
        <div style={{display:"flex",flexDirection:"column",gap:"0.75rem",marginBottom:"1.25rem"}}>
          {filtered.map((a,i)=>(
            <div key={a.id} style={{animation:`fadeUp 0.3s ease ${i*0.07}s both`}}>
              <AnomalyCard a={a} onRead={markRead}/>
            </div>
          ))}
        </div>
      )}

      {/* AI Summary Card */}
      <div style={{...CARD,
        background:`radial-gradient(ellipse at top right, rgba(245,200,66,0.04) 0%, transparent 60%), ${NOISE}, #1A1A1A`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.875rem"}}>
          <div style={{display:"flex",alignItems:"center",gap:"0.625rem"}}>
            <div style={{width:28,height:28,borderRadius:"0.5rem",
              background:"rgba(245,200,66,0.1)",border:"1px solid rgba(245,200,66,0.2)",
              display:"flex",alignItems:"center",justifyContent:"center"}}>
              <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="#F5C842"
                strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
              </svg>
            </div>
            <span style={{fontSize:"0.88rem",fontWeight:600,color:"#E1E0CC"}}>AI Anomaly Summary</span>
          </div>
          <span style={{fontSize:"0.62rem",color:"rgba(225,224,204,0.2)"}}>Generated 10 min ago</span>
        </div>

        <p style={{fontSize:"0.82rem",color:"rgba(225,224,204,0.6)",lineHeight:1.75,
          margin:"0 0 1rem 0",maxWidth:720}}>
          Your <strong style={{color:"rgba(225,224,204,0.8)"}}>geyser</strong> is your biggest concern this week — it's running significantly longer than your established baseline of 28 minutes. This could indicate a faulty thermostat or sediment buildup reducing heating efficiency. Your <strong style={{color:"rgba(225,224,204,0.8)"}}>AC</strong> triggered an unusual late-night activation at 2:15 AM, possibly from a manual override or schedule conflict — check your scheduling app. The <strong style={{color:"rgba(225,224,204,0.8)"}}>washing machine</strong> ran during peak hours, costing 2.1× more than necessary. Overall, these anomalies could be costing you an extra{" "}
          <strong style={{color:"#F5C842"}}>₹{totalWaste} this month</strong> — entirely preventable with schedule optimization.
        </p>

        <div style={{display:"flex",gap:"0.75rem",flexWrap:"wrap"}}>
          <button style={{background:"rgba(245,200,66,0.08)",border:"1px solid rgba(245,200,66,0.2)",
            borderRadius:"0.625rem",padding:"0.55rem 1.1rem",color:"#F5C842",
            fontSize:"0.8rem",cursor:"pointer",fontFamily:"inherit",fontWeight:600,
            transition:"background 0.2s"}}
            onMouseEnter={e=>(e.currentTarget.style.background="rgba(245,200,66,0.15)")}
            onMouseLeave={e=>(e.currentTarget.style.background="rgba(245,200,66,0.08)")}>
            Get Detailed Report
          </button>
          <Link href="/dashboard/schedule"
            style={{background:"rgba(52,211,153,0.07)",border:"1px solid rgba(52,211,153,0.2)",
              borderRadius:"0.625rem",padding:"0.55rem 1.1rem",color:"#34d399",
              fontSize:"0.8rem",textDecoration:"none",fontWeight:600,display:"inline-flex",
              alignItems:"center",gap:6}}>
            Fix with Scheduler →
          </Link>
          <Link href="/dashboard/chat"
            style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.06)",
              borderRadius:"0.625rem",padding:"0.55rem 1.1rem",color:"rgba(225,224,204,0.5)",
              fontSize:"0.8rem",textDecoration:"none",display:"inline-flex",alignItems:"center",gap:6}}>
            Ask AI Advisor
          </Link>
        </div>
      </div>
    </div>
  );
}
