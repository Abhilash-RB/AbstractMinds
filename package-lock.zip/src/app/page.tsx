"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

const STATS = [
  { value: "₹320", label: "Average Monthly Savings" },
  { value: "62%", label: "Peak Hour Avoidance" },
  { value: "3s", label: "Bill Prediction Time" },
  { value: "10k+", label: "Households Optimized" },
];

const FEATURES = [
  { icon:"📊", title:"AI Bill Predictor", desc:"XGBoost-powered monthly bill estimation tailored to your DISCOM tariff slabs and appliance profile." },
  { icon:"🗓", title:"Schedule Optimizer", desc:"Automatically shifts your schedulable appliances to off-peak hours, minimizing cost without disrupting your routine." },
  { icon:"🤖", title:"Claude AI Advisor", desc:"Conversational energy intelligence — ask anything about your usage, get personalized savings recommendations instantly." },
  { icon:"⚠️", title:"Anomaly Detection", desc:"LSTM-powered anomaly detection catches unusual usage patterns before they inflate your bill." },
];

export default function LandingPage() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <div style={{ background:"var(--void)", minHeight:"100vh", position:"relative", overflow:"hidden" }}>
      {/* Noise bg */}
      <div style={{ position:"fixed", inset:0, backgroundImage:"url(\"data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E)", pointerEvents:"none", zIndex:0 }}/>

      {/* Nav */}
      <nav style={{ position:"fixed", top:0, left:0, right:0, zIndex:100, padding:"1.25rem 3rem", display:"flex", alignItems:"center", justifyContent:"space-between", borderBottom:"1px solid var(--outline)", backdropFilter:"blur(12px)", background:"rgba(0,0,0,0.7)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"0.6rem" }}>
          <span style={{ fontSize:"1.5rem", filter:"drop-shadow(0 0 10px rgba(245,200,66,0.8))" }}>⚡</span>
          <span className="font-display" style={{ fontSize:"1.1rem", letterSpacing:"0.12em" }}>
            THUNDER<span style={{ color:"var(--amber)" }}>VOLTS</span>
          </span>
        </div>
        <div style={{ display:"flex", gap:"1rem", alignItems:"center" }}>
          <Link href="/auth" className="btn btn-secondary btn-sm">Login</Link>
          <Link href="/auth" className="btn btn-primary btn-sm">Get Started</Link>
        </div>
      </nav>

      {/* Hero */}
      <section style={{ position:"relative", width:"100vw", height:"100vh", overflow:"hidden", margin:0, padding:0 }}>
        {/* Hero background video — fills 100vw × 100vh */}
        <video
          src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260405_170732_8a9ccda6-5cff-4628-b164-059c500a2b41.mp4"
          autoPlay
          loop
          muted
          playsInline
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            zIndex: 0,
            filter: 'saturate(0.7) brightness(0.85)'
          }}
        />
        {/* Amber glow overlay */}
        <div style={{ position:"absolute", top:"40%", left:"50%", transform:"translate(-50%,-50%)", width:800, height:400, background:"radial-gradient(ellipse, rgba(245,200,66,0.06) 0%, transparent 70%)", pointerEvents:"none", zIndex:1 }}/>
        {/* Bottom gradient fade */}
        <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)", pointerEvents:"none", zIndex:2 }}/>

        {/* Hero text content — pinned to bottom */}
        <div style={{ position:"absolute", bottom:0, left:0, right:0, zIndex:40, textAlign:"center", padding:"0 2rem 5rem" }}>
          <div className="label-caps badge badge-outline" style={{ display:"inline-flex", marginBottom:"1.5rem" }}>
            ⚡ AI-Powered Energy Intelligence
          </div>

          <h1 className="font-display fade-in" style={{ fontSize:"clamp(3rem,7vw,5rem)", lineHeight:1.05, color:"var(--cream)", marginBottom:"1rem" }}>
            Stop Overpaying<br/>
            <span style={{ color:"var(--amber)", textShadow:"0 0 40px rgba(245,200,66,0.4)", position:"relative", display:"inline-block" }}>
              Your Electricity Bill
              <svg style={{ position:"absolute", bottom:-8, left:0, width:"100%" }} viewBox="0 0 300 8" fill="none">
                <path d="M0 4 Q75 0 150 4 Q225 8 300 4" stroke="var(--amber)" strokeWidth="2" strokeLinecap="round" opacity={mounted?1:0} style={{ transition:"opacity 1s ease 0.5s" }}/>
              </svg>
            </span>
          </h1>
          <p className="font-serif fade-in" style={{ fontSize:"1.35rem", color:"var(--cream-dim)", maxWidth:600, margin:"1.5rem auto 2.5rem", lineHeight:1.65 }}>
            ThunderVolts uses Claude AI and machine learning to predict your monthly bill,
            optimize appliance schedules, and detect energy anomalies — saving Indian households up to ₹320/month.
          </p>
          <div style={{ display:"flex", gap:"1rem", justifyContent:"center", flexWrap:"wrap" }}>
            <Link href="/auth" className="btn btn-primary" style={{ padding:"1rem 2rem", fontSize:"1rem", boxShadow:"var(--amber-glow)" }}>
              ⚡ Start Saving Now
            </Link>
            <Link href="/dashboard" className="btn btn-secondary" style={{ padding:"1rem 2rem", fontSize:"1rem" }}>
              View Demo Dashboard →
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section style={{ maxWidth:1280, margin:"0 auto", padding:"2rem", position:"relative", zIndex:1 }}>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:"1rem" }}>
          {STATS.map(({ value, label }) => (
            <div key={label} className="card noise" style={{ textAlign:"center", padding:"2rem 1rem" }}>
              <div className="text-glow-amber font-display" style={{ fontSize:"2.5rem", marginBottom:"0.5rem" }}>{value}</div>
              <div className="label-caps" style={{ color:"var(--cream-muted)" }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section style={{ maxWidth:1280, margin:"6rem auto 0", padding:"2rem", position:"relative", zIndex:1 }}>
        <div style={{ textAlign:"center", marginBottom:"3rem" }}>
          <div className="label-caps" style={{ color:"var(--amber)", marginBottom:"0.75rem" }}>Capabilities</div>
          <h2 className="font-display" style={{ fontSize:"2.5rem", color:"var(--cream)" }}>Everything You Need</h2>
          <p className="font-serif" style={{ color:"var(--cream-dim)", fontSize:"1.1rem", marginTop:"0.75rem" }}>
            Built for Indian households and DISCOM tariff structures
          </p>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))", gap:"1.25rem" }}>
          {FEATURES.map(({ icon, title, desc }, index) => (
            <div key={title} className="card-dark noise" style={{ position:"relative", overflow:"hidden", padding:"2rem", border:"1px solid var(--outline)", borderRadius:"var(--radius-lg)", transition:"border-color var(--transition)" }}
              onMouseEnter={e=>(e.currentTarget.style.borderColor="var(--outline-hover)")}
              onMouseLeave={e=>(e.currentTarget.style.borderColor="var(--outline)")}>
              {/* Card 1 background video */}
              {index === 0 && (
                <video
                  src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260406_133058_0504132a-0cf3-4450-a370-8ea3b05c95d4.mp4"
                  autoPlay
                  loop
                  muted
                  playsInline
                  style={{
                    position: 'absolute',
                    inset: 0,
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    zIndex: 0,
                    filter: 'saturate(0.6) brightness(0.75)'
                  }}
                />
              )}
              {/* Gradient overlay (card 1 only) */}
              {index === 0 && (
                <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)", zIndex:10, pointerEvents:"none" }}/>
              )}
              <div style={{ position:"relative", zIndex:30 }}>
                <div style={{ fontSize:"2rem", marginBottom:"1rem" }}>{icon}</div>
                <h3 style={{ fontWeight:700, color:"var(--cream)", marginBottom:"0.5rem" }}>{title}</h3>
                <p style={{ color:"var(--cream-muted)", fontSize:"0.9rem", lineHeight:1.65 }}>{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section style={{ maxWidth:800, margin:"8rem auto 6rem", padding:"3rem 2rem", textAlign:"center", position:"relative", zIndex:1 }}>
        <div className="card noise card-amber-border" style={{ padding:"3rem" }}>
          <h2 className="font-display" style={{ fontSize:"2.5rem", color:"var(--cream)", marginBottom:"1rem" }}>
            Ready to take control of your energy?
          </h2>
          <p className="font-serif" style={{ color:"var(--cream-dim)", fontSize:"1.1rem", marginBottom:"2rem" }}>
            Join thousands of Indian households already saving with ThunderVolts
          </p>
          <Link href="/auth" className="btn btn-primary" style={{ padding:"1rem 2.5rem", fontSize:"1rem", boxShadow:"var(--amber-glow)" }}>
            ⚡ Get Started Free
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ borderTop:"1px solid var(--outline)", padding:"1.5rem 3rem", display:"flex", justifyContent:"space-between", alignItems:"center", position:"relative", zIndex:1 }}>
        <div className="font-display" style={{ fontSize:"0.9rem", letterSpacing:"0.1em", color:"var(--cream-muted)" }}>
          ⚡ THUNDERVOLTS
        </div>
        <div style={{ fontSize:"0.8rem", color:"var(--cream-muted)" }}>
          AI-Powered Energy Intelligence for India
        </div>
      </footer>
    </div>
  );
}
