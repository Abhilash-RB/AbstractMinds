import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ThunderVolts — AI Energy Optimizer",
  description:
    "AI-powered home energy optimizer for Indian households. Predict bills, optimize appliance schedules, and detect anomalies with Claude AI.",
  keywords: ["energy optimizer", "electricity bill predictor", "AI energy", "India DISCOM"],
  openGraph: {
    title: "ThunderVolts",
    description: "AI-powered home energy intelligence for Indian households",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&family=Instrument+Serif:ital@0;1&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
