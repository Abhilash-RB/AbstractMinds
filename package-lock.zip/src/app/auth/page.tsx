"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

// ── Constants ─────────────────────────────────────────────────────────────────
const STATES = ["Karnataka","Maharashtra","Delhi","Tamil Nadu","Telangana","Andhra Pradesh",
  "Gujarat","West Bengal","Uttar Pradesh","Rajasthan","Punjab","Haryana","Kerala",
  "Madhya Pradesh","Bihar","Odisha","Assam","Jharkhand","Uttarakhand","Himachal Pradesh"];

const DISCOM_OPTS: {state:string;options:string[]}[] = [
  {state:"Karnataka",    options:["BESCOM","HESCOM","MESCOM","GESCOM","CESC Karnataka"]},
  {state:"Maharashtra",  options:["MSEDCL","Tata Power Mumbai","Adani Electricity"]},
  {state:"Delhi",        options:["BSES Rajdhani","BSES Yamuna","TPDDL"]},
  {state:"Tamil Nadu",   options:["TANGEDCO"]},
  {state:"Telangana",    options:["TSSPDCL","TSNPDCL"]},
  {state:"Andhra Pradesh",options:["APEPDCL","APSPDCL"]},
  {state:"Gujarat",      options:["MGVCL","DGVCL","PGVCL","UGVCL"]},
  {state:"West Bengal",  options:["CESC","WBSEDCL"]},
  {state:"Uttar Pradesh",options:["UPPCL","Torrent Power Agra"]},
  {state:"Rajasthan",    options:["JVVNL","JdVVNL","AVVNL"]},
  {state:"Kerala",       options:["KSEB"]},
  {state:"Punjab",       options:["PSPCL"]},
  {state:"Haryana",      options:["DHBVN","UHBVN"]},
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const NOISE=`url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E")`;
const MUTED:React.CSSProperties={color:"rgba(225,224,204,0.4)",fontSize:"0.72rem"};
const INPUT_S=(focused:boolean,err?:boolean):React.CSSProperties=>({
  width:"100%",background:"rgba(0,0,0,0.6)",
  border:`1px solid ${err?"rgba(248,113,113,0.5)":focused?"rgba(245,200,66,0.4)":"rgba(255,255,255,0.08)"}`,
  borderRadius:"0.625rem",padding:"0.7rem 2.75rem 0.7rem 1rem",
  color:"#E1E0CC",fontSize:"0.85rem",outline:"none",boxSizing:"border-box" as const,
  transition:"border-color 0.2s",fontFamily:"'Almarai',sans-serif",
});
const SEL_S=(focused:boolean):React.CSSProperties=>({
  ...INPUT_S(focused),padding:"0.7rem 1rem",appearance:"none" as const,cursor:"pointer",
});
const LBL:React.CSSProperties={...MUTED,display:"block",marginBottom:5};

function pwStrength(p:string){
  let s=0;
  if(p.length>=8)s++;
  if(/[A-Z]/.test(p))s++;
  if(/[0-9]/.test(p))s++;
  if(/[^A-Za-z0-9]/.test(p))s++;
  return s;
}
const STR_LABEL=["","Weak","Fair","Strong","Very Strong"];
const STR_COL=["","#f87171","#F5C842","#F5C842","#34d399"];

// ── Field wrapper with icon ────────────────────────────────────────────────────
function Field({label,icon,children}:{label:string;icon:React.ReactNode;children:React.ReactNode}){
  return(
    <div style={{marginBottom:"0.875rem"}}>
      <label style={LBL}>{label}</label>
      <div style={{position:"relative"}}>
        {children}
        <span style={{position:"absolute",right:"0.875rem",top:"50%",transform:"translateY(-50%)",
          color:"rgba(225,224,204,0.2)",pointerEvents:"none"}}>
          {icon}
        </span>
      </div>
    </div>
  );
}

// ── Icons ─────────────────────────────────────────────────────────────────────
const IcoMail=()=><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>;
const IcoUser=()=><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
const IcoEye=(open:boolean)=><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">{open?<><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>:<><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></>}</svg>;
const IcoZap=({size=16,col="#F5C842"}:{size?:number;col?:string})=><svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={col} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>;
const IcoSpin=()=><svg style={{animation:"spin 1s linear infinite"}} width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;
const IcoCheck=()=><svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>;
const IcoPlay=()=><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>;
const IcoArrow=()=><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>;

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AuthPage(){
  const router=useRouter();
  const [tab,setTab]=useState<"login"|"register">("login");
  const [showPw,setShowPw]=useState(false);
  const [loading,setLoading]=useState(false);
  const [shake,setShake]=useState(false);
  const [success,setSuccess]=useState(false);
  const [error,setError]=useState("");
  const [showDiscHelper,setShowDiscHelper]=useState(false);
  const [areaType,setAreaType]=useState<"Urban"|"Rural"|"Semi-Urban">("Urban");

  // Login fields
  const [loginEmail,setLoginEmail]=useState("");
  const [loginPw,setLoginPw]=useState("");

  // Register fields
  const [rName,setRName]=useState("");
  const [rEmail,setREmail]=useState("");
  const [rPw,setRPw]=useState("");
  const [rCity,setRCity]=useState("");
  const [rState,setRState]=useState("Karnataka");
  const [rDiscom,setRDiscom]=useState("BESCOM");

  // Auth guard
  useEffect(()=>{
    if(typeof window!=="undefined"&&localStorage.getItem("tv_token"))
      router.replace("/dashboard");
  },[router]);

  // Update DISCOM options when state changes
  useEffect(()=>{
    const opts=DISCOM_OPTS.find(d=>d.state===rState)?.options??[];
    setRDiscom(opts[0]??"");
  },[rState]);

  function doShake(){
    setShake(true);setTimeout(()=>setShake(false),500);
  }

  async function handleLogin(email:string,pw:string){
    setLoading(true);setError("");
    try{
      const r=await fetch("/api/v1/auth/login",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({email,password:pw}),
      });
      if(r.status===429){setError("Too many attempts. Please wait.");doShake();setLoading(false);return;}
      const d=await r.json();
      if(!r.ok){setError(d.detail??"Invalid email or password");doShake();setLoading(false);return;}
      if(typeof window!=="undefined"){
        localStorage.setItem("tv_token",d.access_token);
        localStorage.setItem("tv_user",JSON.stringify(d.user));
      }
      router.replace("/dashboard");
    }catch{
      // Demo fallback
      if(email==="demo@thundervolts.in"&&pw==="Thunder@2025"){
        if(typeof window!=="undefined"){
          localStorage.setItem("tv_token","demo_token_"+Date.now());
          localStorage.setItem("tv_user",JSON.stringify({id:"demo",email,full_name:"Arjun Sharma",city:"Bangalore",discom_name:"BESCOM"}));
        }
        router.replace("/dashboard");
      } else {
        setError("Invalid email or password");doShake();
      }
    }
    setLoading(false);
  }

  async function handleRegister(){
    setLoading(true);setError("");
    try{
      const body={email:rEmail,password:rPw,full_name:rName,city:rCity,
        state:rState,discom_name:rDiscom,is_rural:areaType==="Rural"};
      const r=await fetch("/api/v1/auth/register",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify(body),
      });
      const d=await r.json();
      if(r.status===409){setError("Email already registered");doShake();setLoading(false);return;}
      if(!r.ok){setError(d.detail??"Registration failed");doShake();setLoading(false);return;}
      if(typeof window!=="undefined"){
        localStorage.setItem("tv_token",d.access_token);
        localStorage.setItem("tv_user",JSON.stringify(d.user));
      }
      setSuccess(true);
      setTimeout(()=>router.replace("/dashboard"),1200);
    }catch{
      // Demo fallback
      setSuccess(true);
      if(typeof window!=="undefined"){
        localStorage.setItem("tv_token","demo_token_"+Date.now());
        localStorage.setItem("tv_user",JSON.stringify({id:"demo",email:rEmail,full_name:rName,city:rCity,discom_name:rDiscom}));
      }
      setTimeout(()=>router.replace("/dashboard"),1200);
    }
    setLoading(false);
  }

  const pwStr=pwStrength(rPw);
  const discOptions=DISCOM_OPTS.find(d=>d.state===rState)?.options??[""];

  return(
    <div style={{background:"#000",minHeight:"100vh",display:"flex",alignItems:"center",
      justifyContent:"center",fontFamily:"'Almarai',sans-serif",position:"relative",overflow:"hidden",
      padding:"1rem"}}>

      <style>{`
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
        @keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}40%{transform:translateX(8px)}60%{transform:translateX(-8px)}80%{transform:translateX(8px)}}
        @keyframes greenFlash{0%{background:#F5C842}50%{background:#34d399}100%{background:#34d399}}
        input::placeholder,select::placeholder,textarea::placeholder{color:rgba(225,224,204,0.2)}
        input,select{font-family:'Almarai',sans-serif}
        .hover-bright:hover{filter:brightness(1.12);box-shadow:0 0 30px rgba(245,200,66,0.3)}
        .demo-btn:hover{color:rgba(225,224,204,0.7)!important}
        .disc-link:hover{color:rgba(245,200,66,0.8)!important}
        select option{background:#111}
      `}</style>

      {/* Ambient glows */}
      <div style={{position:"fixed",width:500,height:500,borderRadius:"50%",
        background:"radial-gradient(circle,rgba(245,200,66,0.05) 0%,transparent 60%)",
        left:"-12rem",top:"25%",pointerEvents:"none"}}/>
      <div style={{position:"fixed",width:360,height:360,borderRadius:"50%",
        background:"radial-gradient(circle,rgba(245,200,66,0.03) 0%,transparent 60%)",
        right:"-6rem",bottom:"10%",pointerEvents:"none"}}/>

      {/* Card */}
      <div style={{
        background:`${NOISE}, #1A1A1A`,border:"1px solid rgba(255,255,255,0.06)",
        borderRadius:"1.25rem",padding:"2rem",width:"100%",maxWidth:440,
        animation:shake?"shake 0.45s ease":"fadeUp 0.45s ease both",
        position:"relative",zIndex:1,
      }}>

        {/* Logo */}
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:7,marginBottom:"1.75rem"}}>
          <IcoZap size={18}/>
          <span style={{fontSize:"1.1rem",color:"#E1E0CC",letterSpacing:"-0.02em"}}>
            <strong>THUNDER</strong><span style={{fontWeight:300}}>VOLTS</span>
          </span>
        </div>

        {/* Tab switcher */}
        <div style={{background:"rgba(0,0,0,0.6)",borderRadius:"0.875rem",padding:4,
          display:"flex",marginBottom:"1.75rem"}}>
          {(["login","register"] as const).map(t=>(
            <button key={t} onClick={()=>{setTab(t);setError("");setSuccess(false);}}
              style={{flex:1,padding:"0.55rem",borderRadius:"0.625rem",fontSize:"0.82rem",
                fontWeight:tab===t?600:400,cursor:"pointer",border:"none",transition:"all 0.2s",
                background:tab===t?"#1A1A1A":"transparent",
                color:tab===t?"#E1E0CC":"rgba(225,224,204,0.3)",
                boxShadow:tab===t?"0 1px 6px rgba(0,0,0,0.4)":"none"}}>
              {t==="login"?"Login":"Create Account"}
            </button>
          ))}
        </div>

        {/* ── LOGIN ── */}
        {tab==="login"&&(
          <div style={{animation:"fadeUp 0.25s ease"}}>
            <Field label="Email" icon={<IcoMail/>}>
              <input type="email" value={loginEmail} onChange={e=>setLoginEmail(e.target.value)}
                placeholder="arjun@example.com" style={INPUT_S(false,!!error)}/>
            </Field>
            <Field label="Password" icon={
              <button type="button" onClick={()=>setShowPw(v=>!v)}
                style={{background:"none",border:"none",cursor:"pointer",color:"rgba(225,224,204,0.25)",
                  display:"flex",alignItems:"center",pointerEvents:"all"}}>
                {IcoEye(showPw)}
              </button>
            }>
              <input type={showPw?"text":"password"} value={loginPw}
                onChange={e=>setLoginPw(e.target.value)}
                placeholder="••••••••" style={INPUT_S(false,!!error)}
                onKeyDown={e=>e.key==="Enter"&&handleLogin(loginEmail,loginPw)}/>
            </Field>
            <div style={{textAlign:"right",marginTop:"-0.5rem",marginBottom:"1.25rem"}}>
              <span className="disc-link"
                style={{fontSize:"0.7rem",color:"rgba(245,200,66,0.55)",cursor:"pointer",transition:"color 0.15s"}}>
                Forgot password?
              </span>
            </div>
            {error&&<div style={{fontSize:"0.72rem",color:"#f87171",marginBottom:"0.75rem",textAlign:"center"}}>{error}</div>}
            <button className="hover-bright"
              onClick={()=>handleLogin(loginEmail,loginPw)}
              disabled={loading}
              style={{width:"100%",background:"#F5C842",color:"#000",border:"none",
                borderRadius:"0.625rem",padding:"0.875rem",fontSize:"0.88rem",fontWeight:700,
                cursor:loading?"not-allowed":"pointer",transition:"all 0.2s",
                display:"flex",alignItems:"center",justifyContent:"center",gap:7,
                opacity:loading?0.85:1}}>
              {loading?<><IcoSpin/>Signing in...</>:<><IcoZap size={15} col="#000"/>Login</>}
            </button>
          </div>
        )}

        {/* ── REGISTER ── */}
        {tab==="register"&&(
          <div style={{animation:"fadeUp 0.25s ease"}}>
            <Field label="Full Name" icon={<IcoUser/>}>
              <input type="text" value={rName} onChange={e=>setRName(e.target.value)}
                placeholder="Arjun Sharma" style={INPUT_S(false)}/>
            </Field>
            <Field label="Email" icon={<IcoMail/>}>
              <input type="email" value={rEmail} onChange={e=>setREmail(e.target.value)}
                placeholder="arjun@example.com" style={INPUT_S(false,error.includes("Email"))}/>
            </Field>
            {/* Password + strength */}
            <div style={{marginBottom:"0.875rem"}}>
              <label style={LBL}>Password</label>
              <div style={{position:"relative"}}>
                <input type={showPw?"text":"password"} value={rPw}
                  onChange={e=>setRPw(e.target.value)}
                  placeholder="Create a password" style={INPUT_S(false)}/>
                <button type="button" onClick={()=>setShowPw(v=>!v)}
                  style={{position:"absolute",right:"0.875rem",top:"50%",transform:"translateY(-50%)",
                    background:"none",border:"none",cursor:"pointer",
                    color:"rgba(225,224,204,0.25)",display:"flex",alignItems:"center"}}>
                  {IcoEye(showPw)}
                </button>
              </div>
              {rPw&&(
                <div style={{marginTop:6}}>
                  <div style={{display:"flex",gap:3,marginBottom:3}}>
                    {[1,2,3,4].map(i=>(
                      <div key={i} style={{flex:1,height:3,borderRadius:2,
                        background:i<=pwStr?STR_COL[pwStr]:"rgba(255,255,255,0.08)",
                        transition:"background 0.3s"}}/>
                    ))}
                  </div>
                  <span style={{fontSize:"0.62rem",color:STR_COL[pwStr]}}>{STR_LABEL[pwStr]}</span>
                </div>
              )}
            </div>
            {/* City + State */}
            <div style={{marginBottom:"0.875rem"}}>
              <label style={LBL}>City & State</label>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                <input type="text" value={rCity} onChange={e=>setRCity(e.target.value)}
                  placeholder="Bangalore" style={INPUT_S(false)}/>
                <select value={rState} onChange={e=>setRState(e.target.value)} style={SEL_S(false)}>
                  {STATES.map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            {/* DISCOM */}
            <div style={{marginBottom:"0.875rem"}}>
              <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:5}}>
                <label style={{...LBL,marginBottom:0}}>Electricity Provider (DISCOM)</label>
                <span style={{fontSize:"0.6rem",color:"rgba(245,200,66,0.4)",cursor:"help"}}
                  title="Your electricity distribution company — select based on your city">ⓘ</span>
              </div>
              <select value={rDiscom} onChange={e=>setRDiscom(e.target.value)} style={SEL_S(false)}>
                {discOptions.map(o=><option key={o}>{o}</option>)}
              </select>
              <div style={{marginTop:4}}>
                <span className="disc-link" onClick={()=>setShowDiscHelper(v=>!v)}
                  style={{fontSize:"0.62rem",color:"rgba(245,200,66,0.45)",cursor:"pointer",transition:"color 0.15s"}}>
                  Don't know your DISCOM?
                </span>
                {showDiscHelper&&(
                  <div style={{fontSize:"0.62rem",color:"rgba(225,224,204,0.35)",marginTop:3,
                    padding:"4px 8px",background:"rgba(255,255,255,0.03)",borderRadius:6}}>
                    Check the header of your electricity bill — the DISCOM name is printed at the top.
                  </div>
                )}
              </div>
            </div>
            {/* Area type */}
            <div style={{marginBottom:"1.25rem"}}>
              <label style={LBL}>Area Type</label>
              <div style={{background:"rgba(0,0,0,0.5)",borderRadius:"0.625rem",padding:3,
                display:"flex",gap:0}}>
                {(["Urban","Semi-Urban","Rural"] as const).map(a=>(
                  <button key={a} onClick={()=>setAreaType(a)}
                    style={{flex:1,padding:"0.4rem 0.5rem",borderRadius:"0.45rem",fontSize:"0.72rem",
                      border:"none",cursor:"pointer",transition:"all 0.2s",
                      background:areaType===a?"#1A1A1A":"transparent",
                      color:areaType===a?"#E1E0CC":"rgba(225,224,204,0.3)",fontFamily:"'Almarai',sans-serif",
                      boxShadow:areaType===a?"0 1px 4px rgba(0,0,0,0.4)":"none"}}>
                    {a}
                  </button>
                ))}
              </div>
              {areaType==="Rural"&&(
                <div style={{fontSize:"0.62rem",color:"rgba(225,224,204,0.3)",marginTop:5}}>
                  Rural flat-rate pricing — we'll estimate your optimal usage times
                </div>
              )}
            </div>
            {error&&<div style={{fontSize:"0.72rem",color:"#f87171",marginBottom:"0.75rem",textAlign:"center"}}>{error}</div>}
            <button className="hover-bright"
              onClick={handleRegister} disabled={loading||success}
              style={{width:"100%",border:"none",borderRadius:"0.625rem",padding:"0.875rem",
                fontSize:"0.88rem",fontWeight:700,cursor:loading||success?"not-allowed":"pointer",
                transition:"all 0.3s",display:"flex",alignItems:"center",justifyContent:"center",gap:7,
                background:success?"#34d399":"#F5C842",
                color:"#000",animation:success?"greenFlash 0.4s ease":"none"}}>
              {loading?<><IcoSpin/>Setting up your account...</>
                :success?<><IcoCheck/>Account created! Redirecting...</>
                :<><span>Create Account</span><IcoArrow/></>}
            </button>
          </div>
        )}

        {/* Divider */}
        <div style={{display:"flex",alignItems:"center",gap:10,margin:"1.25rem 0"}}>
          <div style={{flex:1,height:1,background:"rgba(255,255,255,0.06)"}}/>
          <span style={{fontSize:"0.7rem",color:"rgba(225,224,204,0.2)"}}>or</span>
          <div style={{flex:1,height:1,background:"rgba(255,255,255,0.06)"}}/>
        </div>

        {/* Demo button */}
        <button className="demo-btn"
          onClick={()=>{
            setTab("login");
            setLoginEmail("demo@thundervolts.in");
            setLoginPw("Thunder@2025");
            setTimeout(()=>handleLogin("demo@thundervolts.in","Thunder@2025"),150);
          }}
          style={{width:"100%",background:"rgba(255,255,255,0.02)",
            border:"1px solid rgba(255,255,255,0.06)",borderRadius:"0.625rem",
            padding:"0.75rem",fontSize:"0.82rem",color:"rgba(225,224,204,0.4)",
            cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",
            gap:7,transition:"color 0.2s",fontFamily:"'Almarai',sans-serif"}}>
          <IcoPlay/>Try Demo Account
        </button>

        <p style={{fontSize:"0.6rem",color:"rgba(225,224,204,0.18)",textAlign:"center",
          marginTop:"1rem",lineHeight:1.6}}>
          By continuing you agree to our Terms &amp; Privacy Policy
        </p>
      </div>
    </div>
  );
}
